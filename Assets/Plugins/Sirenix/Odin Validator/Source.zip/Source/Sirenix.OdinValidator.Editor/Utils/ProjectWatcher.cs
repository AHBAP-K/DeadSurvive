//-----------------------------------------------------------------------
// <copyright file="ProjectWatcher.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
using Sirenix.OdinInspector;
using Sirenix.OdinInspector.Editor;
using Sirenix.OdinInspector.Editor.Validation;
using Sirenix.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using Debug = UnityEngine.Debug;

namespace Sirenix.OdinValidator.Editor
{
    public static class ProjectWatcher
    {
        private static bool isInitialized;
        private static int hierarchyWindowChangedCount;
        private static List<string> importedAssetsBuffer = new List<string>();
        private static List<string> deletedAssetsBuffer = new List<string>();
        private static List<(string, string)> movedAssetsBuffer = new List<(string, string)>();
        private static List<BackgroundTaskHandle> taskHandles = new List<BackgroundTaskHandle>();
        private static Action<ProjectEvent[]> onProjectEvent;

        public static event Action<ProjectEvent[]> OnProjectEvent
        {
            add
            {
                if (!isInitialized)
                {
                    onProjectEvent += value;
                    isInitialized = true;


                    EditorApplication.hierarchyChanged += () =>
                    {
                        hierarchyWindowChangedCount++;
                    };

                    EditorApplication.update += MonitorAssetProcessorChanges;
                    UndoTracker.OnRedoPerformed += OnUndoOrRedoPerformed;
                    UndoTracker.OnUndoPerformed += OnUndoOrRedoPerformed;
                    UndoTracker.OnObjectValueModified += UndoTracker_OnObjectValueModified;
                    ValidationEvents.OnValidationStateChanged += OnValidationStateChanged;

                    RestartWatching(false);
                }
                else
                {
                    if (onProjectEvent == null || onProjectEvent.GetInvocationList().Length == 0)
                    {
                        foreach (var item in taskHandles)
                            item.Continue();
                    }

                    onProjectEvent += value;
                }
            }
            remove
            {
                onProjectEvent -= value;

                if (onProjectEvent == null || onProjectEvent.GetInvocationList().Length == 0)
                    foreach (var item in taskHandles)
                        item.Pause();
            }
        }

        internal static void RestartWatching(bool skipLoadEvents)
        {
            foreach (var item in taskHandles)
            {
                if (item.IsAlive)
                {
                    item.Kill();
                }
            }
            taskHandles.Clear();

            taskHandles.Add(BackgroundTaskRunner.StartTask("Monitor loaded scenes", MonitorAllLoadedScenes(skipLoadEvents)));
        }

        internal static CircularBuffer<ProjectEvent> latestEvents = new CircularBuffer<ProjectEvent>(10);

        private static void OnValidationStateChanged(ValidationStateChangeInfo obj)
        {
            if (obj.ValidationResult.Setup.Root as UnityEngine.Object == null)
                return;

            var uObj = obj.ValidationResult.Setup.Root as UnityEngine.Object;
            var assetPath = (string)null;
            var guid = (string)null;
            var eventType = ProjectEventType.SceneObjectModified;

            if (AssetDatabase.Contains(uObj))
            {
                assetPath = AssetDatabase.GetAssetPath(uObj);
                guid = AssetDatabase.AssetPathToGUID(assetPath);
                eventType = ProjectEventType.AssetModified;
            }

            var arr = new ProjectEvent[1]
            {
                new ProjectEvent()
                {
                    Path = assetPath,
                    AssetGuid = guid,
                    InstanceID = uObj.GetInstanceID(),
                    Source = ProjectEventSource.OdinValidationEvents,
                    Type = eventType,
                }
            };

            InvokeProjectEvent(arr);
        }

        private static void OnUndoOrRedoPerformed(List<UnityEngine.Object> objects)
        {
            InvokeChangeEventsForUnityObjects(objects, ProjectEventSource.UndoOrRedo);
        }

        private static void InvokeChangeEventsForUnityObjects(IEnumerable<UnityEngine.Object> objects, ProjectEventSource source)
        {
            if (onProjectEvent == null)
                return;

            var events = new List<ProjectEvent>();

            foreach (var obj in objects)
            {
                if (!obj) continue;

                GameObject go = obj as GameObject;

                if (obj is Component)
                {
                    go = (obj as Component).gameObject;
                }
                else if (obj is GameObject)
                {
                    go = obj as GameObject;
                }

                bool isAsset = AssetDatabase.Contains(obj);
                bool isInValidScene = false;

                if (go != null)
                {
                    isInValidScene = go.scene.IsValid();
                }

                if (isAsset && isInValidScene)
                {
#if SIRENIX_INTERNAL
                    Debug.LogError("Undo event was both a scene and an asset!? What modification was just made? Perhaps it was rename?");
#endif
                }
                else if (isAsset && !isInValidScene)
                {
                    var path = AssetDatabase.GetAssetPath(obj);
                    var guid = AssetDatabase.AssetPathToGUID(path);
                    events.Add(new ProjectEvent()
                    {
                        Type = ProjectEventType.AssetModified,
                        Path = path,
                        AssetGuid = guid,
                        InstanceID = obj != null ? obj.GetInstanceID() : 0,
                        Source = source
                    });
                }
                else if (isInValidScene && !isAsset)
                {
                    if (obj)
                    {
                        events.Add(new ProjectEvent()
                        {
                            Type = ProjectEventType.SceneObjectModified,
                            Path = null,
                            Source = source,
                            InstanceID = obj != null ? obj.GetInstanceID() : 0,
                        });
                    }
                    else
                    {
#if SIRENIX_INTERNAL
                        Debug.LogError("What is this?");
#endif
                    }
                }
            }

            if (events.Count > 0)
            {
                InvokeProjectEvent(events.ToArray());
            }
        }

        private static void UndoTracker_OnObjectValueModified(UndoTracker.UndoPropertyModificationGroup[] obj)
        {
            InvokeChangeEventsForUnityObjects(obj.Select(x => x.Target), ProjectEventSource.UndoOrRedoModification);
        }

        private static void MonitorAssetProcessorChanges()
        {
            /*
             * Unit's AssetPostprocessor & AssetModificationProcessor has several issues.
             * 
             * 1) In some version of Unity, it executes the same event multiple times.
             * 2) Multiple changes that should get reported in one event is sometimes reported in several events instead of one.
             * 
             * We fix these issues by accumulating all events in "toTrigger". Each editor tick we then handle everthing that has
             * been queue up and create the final ProjectEvent[]
             */

            if (importedAssetsBuffer.Count == 0
                && deletedAssetsBuffer.Count == 0
                && movedAssetsBuffer.Count == 0)
            {
                return;
            }

            if (EditorApplication.isCompiling)
            {
                return;
            }

            var events = new List<ProjectEvent>();
            var source = ProjectEventSource.MonitorAssetProcessorChanges;

            foreach (var path in importedAssetsBuffer)
            {
                var guid = AssetDatabase.AssetPathToGUID(path);
                if (!string.IsNullOrEmpty(guid))
                    events.Add(new ProjectEvent() { Type = ProjectEventType.AssetImported, Path = path, AssetGuid = guid, Source = source });
            }

            foreach (var path in deletedAssetsBuffer)
            {
                var guid = AssetDatabase.AssetPathToGUID(path);
                if (!string.IsNullOrEmpty(guid))
                    events.Add(new ProjectEvent() { Type = ProjectEventType.AssetRemoved, Path = path, AssetGuid = guid, Source = source });
            }

            foreach (var p in movedAssetsBuffer)
            {
                var pathTo = p.Item2;
                var guid = AssetDatabase.AssetPathToGUID(pathTo);
                if (!string.IsNullOrEmpty(guid))
                    events.Add(new ProjectEvent()
                    {
                        Type = ProjectEventType.AssetMoved,
                        Path = pathTo,
                        AssetGuid = guid,
                        Source = source
                    });
            }

            var eventArr = events.Distinct().ToArray();

            if (eventArr.Length > 0)
            {
                InvokeProjectEvent(eventArr);
            }

            importedAssetsBuffer.Clear();
            deletedAssetsBuffer.Clear();
            movedAssetsBuffer.Clear();
        }

        private static void InvokeProjectEvent(ProjectEvent[] eventArr)
        {
            foreach (var item in eventArr)
                latestEvents.Add(item);

            if (onProjectEvent != null)
            {
                if (onProjectEvent is MulticastDelegate)
                {
                    var delegates = onProjectEvent.GetInvocationList();
                    foreach (var del in delegates)
                    {
                        try
                        {
                            ((Action<ProjectEvent[]>)del)(eventArr);
                        }
                        catch (Exception ex)
                        {
                            Debug.LogException(ex);
                        }
                    }
                }
                else
                {
                    try
                    {
                        onProjectEvent(eventArr);
                    }
                    catch (Exception ex)
                    {
                        Debug.LogException(ex);
                    }
                }
            }
        }

        private class SceneMonitorEnumerator
        {
            public HashSet<int> AllLoadedObjectIds;
            public bool WasPaused;
            public BackgroundTaskHandle Task;
        }

        private static IEnumerator MonitorAllLoadedScenes(bool skipLoadEventsForCurrentLoadedScenes)
        {
            var openScenes = new Dictionary<SceneReference, SceneMonitorEnumerator>();
            var toRemove = new List<SceneReference>();
            while (true)
            {
                var sceneCount = SceneManager.sceneCount;
                for (int i = 0; i < sceneCount; i++)
                {
                    var scene = new SceneReference(SceneManager.GetSceneAt(i));
                    if (scene.IsLoaded)
                    {
                        if (!openScenes.ContainsKey(scene))
                        {
                            var e = new SceneMonitorEnumerator();
                            e.AllLoadedObjectIds = new HashSet<int>();
                            e.Task = BackgroundTaskRunner.StartTask("Monitor changes in " + scene.Name, MonitorSceneChangesFor(scene, e.AllLoadedObjectIds, skipLoadEventsForCurrentLoadedScenes));
                            taskHandles.Add(e.Task);

                            // Scene loaded
                            if (!skipLoadEventsForCurrentLoadedScenes)
                            {
                                InvokeProjectEvent(new ProjectEvent[]
                                {
                                    new ProjectEvent()
                                    {
                                        AssetGuid = scene.GUID,
                                        Type = ProjectEventType.SceneLoaded,
                                        Source = ProjectEventSource.SceneMonitor,
                                    }
                                });
                            }

                            openScenes.Add(scene, e);
                        }
                    }
                }

                skipLoadEventsForCurrentLoadedScenes = false;

                foreach (var scene in openScenes.Keys)
                {
                    if (!scene.IsLoaded)
                    {
                        // Scene unloaded.
                        InvokeProjectEvent(new ProjectEvent[]
                        {
                            new ProjectEvent()
                            {
                                AssetGuid = scene.GUID,
                                Type = ProjectEventType.SceneUnloaded,
                                Source = ProjectEventSource.SceneMonitor,
                            }
                        });
                        toRemove.Add(scene);
                    }
                }

                if (toRemove.Count > 0)
                {
                    foreach (var item in openScenes)
                    {
                        item.Value.WasPaused = item.Value.Task.IsPaused;
                        item.Value.Task.Pause();
                    }

                    foreach (var item in toRemove)
                    {
                        var e = openScenes[item];
                        taskHandles.Remove(e.Task);
                        e.Task.Kill();

                        var chunkSize = 100;
                        var idx = 0;
                        var chunkBuffer = new ProjectEvent[Math.Min(e.AllLoadedObjectIds.Count, chunkSize)];

                        foreach (var id in e.AllLoadedObjectIds)
                        {
                            chunkBuffer[idx++] = new ProjectEvent()
                            {
                                Type = ProjectEventType.SceneObjectUnloaded,
                                Source = ProjectEventSource.SceneMonitor,
                                InstanceID = id,
                            };

                            if (idx >= chunkBuffer.Length || idx == e.AllLoadedObjectIds.Count)
                            {
                                if (chunkBuffer.Length != idx)
                                    Array.Resize(ref chunkBuffer, idx);

                                InvokeProjectEvent(chunkBuffer);
                                idx = 0;
                            }
                        }

                        yield return null;

                        openScenes.Remove(item);
                    }

                    foreach (var item in openScenes)
                    {
                        if (!item.Value.WasPaused)
                        {
                            item.Value.Task.Continue();
                        }
                    }

                    toRemove.Clear();
                }

                yield return BackgroundTaskRunner.Relax;
            }
        }

        private static IEnumerator MonitorSceneChangesFor(SceneReference scene, HashSet<int> allLoadedObjectIdsBuffer, bool skipLoadEvents)
        {
            var changeDetected = false;
            var lastKnownHierarchyIds = new HashSet<int>();
            var lastHierarchyChangeCount = -1;
            var setNext = false;

            // Instance id buffers
            var a = new List<int>(300);
            var b = new List<int>(300);
            var currIds = a;

            while (true)
            {
                // If nothing is listening, wait until something is.
                // This could also be achieved by having custom getterns and setters to start and stop the task accordingly.
                if (onProjectEvent == null || onProjectEvent.GetInvocationList().Length == 0)
                {
                    yield return BackgroundTaskRunner.Relax;
                    continue;
                }

                var transformQueue = new Queue<Transform>();

                // Find and queue all scene roots
                {
                    Scene tmpScene;
                    if (scene.TryGetScene(out tmpScene))
                    {
                        var roots = SceneUtilities.GetSceneRoots(tmpScene);
                        foreach (var root in roots)
                            transformQueue.Enqueue(root.transform);
                    }
                }

                // Populate hiearchy structure
                {
                    while (transformQueue.Count > 0)
                    {
                        var transform = transformQueue.Dequeue();
                        if (transform)
                        {
                            currIds.Add(transform.gameObject.GetInstanceID());
                            foreach (var cmp in transform.gameObject.GetComponents<UnityEngine.Component>())
                            {
                                if ((object)cmp == null)
                                {
                                    // Do we want to do anything here?
                                    // There are cases where this happen!
                                }
                                else
                                {
                                    currIds.Add(cmp.GetInstanceID());
                                }
                            }

                            var childCount = transform.childCount;
                            for (int i = 0; i < childCount; i++)
                            {
                                transformQueue.Enqueue(transform.GetChild(i));
                            }
                        }

                        if (changeDetected || lastHierarchyChangeCount != hierarchyWindowChangedCount)
                        {
                            yield return null;
                        }
                        else
                        {
                            yield return BackgroundTaskRunner.Relax;
                        }
                    }
                }

                var other = currIds == a ? b : a;
                var hasDiff = currIds.Count != other.Count || !currIds.SequenceEqual(other);

                if (hasDiff)
                {
                    /*
                     * The hiearchy was changed, but since this is background task running over 
                     * time we can't be sure we have the full picture yet. In order to make sure we 
                     * have the full picture, we wait until we don't detect any further changes.
                     */

                    // Debug.Log("Change detected! not sure what change it is yet, it might be nothing! We'll find out once we have a stable overview of the hiearchy. Looked at " + (curr.Count) + " gameObjects:");
                    changeDetected = true;
                    yield return null;
                }
                else
                {
                    if (changeDetected)
                    {
                        /*
                         * We've now looked through the project hiearchy twice! And it 
                         * remained unchanged since the first change was discovered. 
                         * This means that we now have a stable picture of what is currently in the hiearchy, 
                         * and we can now compare that against the previous stable picture we had.
                         */

                        var eventBuffer = new ProjectEvent[1];
                        foreach (var id in currIds)
                        {
                            if (!lastKnownHierarchyIds.Remove(id))
                            {
                                var type = lastHierarchyChangeCount == -1 ? ProjectEventType.SceneObjectLoaded : ProjectEventType.SceneObjectCreated;
                                var skip = skipLoadEvents && type == ProjectEventType.SceneObjectLoaded;

                                if (!skip)
                                {
                                    eventBuffer[0] = (new ProjectEvent()
                                    {
                                        Type = (lastHierarchyChangeCount == -1) ? ProjectEventType.SceneObjectLoaded : ProjectEventType.SceneObjectCreated,
                                        Source = ProjectEventSource.SceneMonitor,
                                        InstanceID = id,
                                    });
                                    InvokeProjectEvent(eventBuffer);
                                }
                                allLoadedObjectIdsBuffer.Add(id);
                                yield return null;
                            }
                        }

                        var removedCount = 0;
                        foreach (var id in lastKnownHierarchyIds)
                        {
                            eventBuffer[0] = (new ProjectEvent()
                            {
                                Type = ProjectEventType.SceneObjectDeleted,
                                Source = ProjectEventSource.SceneMonitor,
                                InstanceID = id,
                            });

                            // TODO: Find all components in WorkDone which gameobject id was this, and remove them.
                            removedCount++;
                            InvokeProjectEvent(eventBuffer);
                            allLoadedObjectIdsBuffer.Remove(id);
                            yield return null;
                        }

                        changeDetected = false;
                        lastKnownHierarchyIds.Clear();

                        foreach (var item in currIds)
                        {
                            lastKnownHierarchyIds.Add(item);
                        }

                        lastHierarchyChangeCount = hierarchyWindowChangedCount;
                        setNext = false;
                    }
                    else
                    {
                        if (setNext)
                        {
                            lastHierarchyChangeCount = hierarchyWindowChangedCount;
                        }
                        else
                        {
                            setNext = true;
                        }
                    }
                }

                other.Clear();
                currIds = other;

                yield return BackgroundTaskRunner.Relax;
            }
        }

        private class AssetModificationWatcher_AssetPostprocessor : AssetPostprocessor
        {
            static void OnPostprocessAllAssets(string[] importedAssets, string[] deletedAssets, string[] movedAssets, string[] movedFromAssetPaths)
            {
                if (deletedAssets.Length > 0)
                    deletedAssets = deletedAssets.Where(x => !x.StartsWith("Assets/__DELETED_GUID_Trash/")).ToArray();

                foreach (var path in importedAssets) importedAssetsBuffer.Add(path);
                foreach (var path in deletedAssets) deletedAssetsBuffer.Add(path);

                Debug.Assert(movedAssets.Length == movedFromAssetPaths.Length);

                for (int i = 0; i < movedAssets.Length; i++)
                {
                    var from = movedFromAssetPaths[i];
                    var to = movedAssets[i];
                    movedAssetsBuffer.Add((from, to));
                }
            }
        }
    }

    // TODO: Rethink this guy
    public enum ProjectEventSource
    {
        Unknown,
        TransformModification,
        SceneMonitor,
        MonitorAssetProcessorChanges,
        UndoOrRedo,
        UndoOrRedoModification,
        OdinValidationEvents,
        Other,
    }

    public struct ProjectEvent : IEquatable<ProjectEvent>
    {
        public ProjectEventType Type;
        public string Path;
        public string AssetGuid;
        public int InstanceID;
        public ProjectEventSource Source;

        public UnityEngine.Object UnityObject => EditorUtility.InstanceIDToObject(this.InstanceID);

        private string Info
        {
            get
            {
                if (InstanceID != 0)
                {
                    var uObj = EditorUtility.InstanceIDToObject(this.InstanceID);
                    if (uObj)
                    {
                        if (uObj is GameObject)
                        {
                            var go = uObj as GameObject;
                            return go.name;
                        }
                        else if (uObj is Component)
                        {
                            var component = uObj as Component;
                            return component.gameObject.name + "/" + component.GetType().Name;
                        }

                        return uObj.name;
                    }
                    else
                    {
                        return "Destroyed Instance Id: " + InstanceID;
                    }
                }

                if (Path != null)
                    return Path;

                return "Unkonwn Event Info";
            }
        }

        public bool Equals(ProjectEvent other)
        {
            return other.Path == this.Path &&
                   other.AssetGuid == this.AssetGuid &&
                   other.InstanceID == this.InstanceID &&
                   other.Type == this.Type;
        }

        public override string ToString()
        {
            return Info;
        }
    }

    public enum ProjectEventType
    {
        AssetImported,
        AssetModified,
        AssetRemoved,
        AssetMoved,
        SceneObjectCreated,
        SceneObjectModified,
        SceneObjectDeleted,
        SceneObjectLoaded,
        SceneObjectUnloaded,
        ValidationStateChanged,
        SceneLoaded,
        SceneUnloaded,
    }

    internal class CircularBuffer<T>
    {
        public T[] Buffer;
        public int Position;

        public CircularBuffer(int capacity)
        {
            this.Buffer = new T[capacity];
        }

        public int Length => Math.Min(Buffer.Length, this.Position);

        public T this[int index]
        {
            get
            {
                var p = (this.Position - index - 1) % this.Buffer.Length;

                if (p < 0)
                {
                    p += this.Buffer.Length;
                    Debug.Log("ASD");
                }

                return Buffer[p];
            }
        }

        public void Add(T item)
        {
            this.Buffer[this.Position++ % this.Buffer.Length] = item;
        }
    }
}
#endif