//-----------------------------------------------------------------------
// <copyright file="AverageSampler.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    internal class AverageSampler
    {
        private static int globalSampleIndexCounter;

        public double SampleSum;
        public double LatestSample;
        public int SampleCount;
        public double SampleAverage => SampleSum / SampleCount;
        public int GlobalSampleIndex;

        public void Add(double sample)
        {
            this.LatestSample = sample;
            this.SampleSum += sample;
            this.SampleCount++;
            GlobalSampleIndex = globalSampleIndexCounter++;
        }

        public void Reset()
        {
            this.LatestSample = 0;
            this.SampleCount = 0;
            this.SampleSum = 0;
        }
    }
}
#endif