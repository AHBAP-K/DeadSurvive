//-----------------------------------------------------------------------
// <copyright file="BackgroundTaskRunner.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#pragma warning disable

namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector;
    using Sirenix.OdinInspector.Editor;
    using Sirenix.OdinInspector.Editor.Validation;
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using UnityEditor;
    using UnityEngine;

    public static class BackgroundTaskRunner
    {
        private static int updateCount = 0;
        private static DateTime time = DateTime.Now;
        internal static float dt = 0.02f;
        internal static float TotalWorkLastTickMs = 0;

        public static List<BackgroundTaskHandle> AllTasks = new List<BackgroundTaskHandle>();

        [HideInInspector]
        public static readonly object Relax = new object();
        public static EditorPrefFloat MaxBackgroundTaskMSPerFrame = new EditorPrefFloat("ODIN_VALIDATOR_MaxBackgroundTaskMSPerFrame", 2);

        [OnInspectorGUI]
        static void Refresh()
        {
            GUIHelper.RequestRepaint();
        }

        static BackgroundTaskRunner()
        {
            var mainRunner = TaskEnumerator();

            EditorApplication.update += () =>
            {
                dt = (float)(DateTime.Now - time).TotalSeconds;
                time = DateTime.Now;
                mainRunner.MoveNext();
            };
        }

        [HideInInspector]
        private static IEnumerator TaskEnumerator()
        {
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();
            var taskBuffer = new List<BackgroundTaskHandle>();

            while (true)
            {
                if (Application.isPlaying)
                    yield return null;


                taskBuffer.Clear();
                taskBuffer.AddRange(AllTasks);

                foreach (var item in taskBuffer)
                {
                    item.FrameTimeMs = 0;
                    item.FrameTickCount = 0;
                    item.AverageFrameTickMs = 0;
                }

                var totalWorkMs = 0f;
                var maxMs = MaxBackgroundTaskMSPerFrame.Value;
                var skipWhileSceneViewIsBeingInteractedWith = GlobalValidationConfig.PauseValidationWhileWorkingInSceneView.Value;
                while (sw.Elapsed.TotalMilliseconds < maxMs && taskBuffer.Count > 0)
                {
                    for (int i = 0; i < taskBuffer.Count; i++)
                    {
                        var task = taskBuffer[i];
                        var t1 = (float)sw.Elapsed.TotalMilliseconds;
                        var skip = false;

                        if (skipWhileSceneViewIsBeingInteractedWith && SceneViewUtility.lastSceneViewInteraction + 0.2 > EditorApplication.timeSinceStartup)
                        {
                            // Do not work while the designer is working.
                            skip = true;
                        }
                        else
                        {
                            task.MoveNext();
                        }
                        var t2 = (float)sw.Elapsed.TotalMilliseconds;
                        var delta = t2 - t1;
                        task.FrameTimeMs += delta;
                        task.AverageFrameTickMs += delta;
                        task.TotalMsWorked += delta;
                        task.FrameTickCount++;
                        totalWorkMs += delta;

                        if (!task.IsAlive || task.IsPaused || task.Relaxed || skip)
                        {
                            task.AverageFrameTickMs = task.AverageFrameTickMs / task.FrameTickCount;
                            taskBuffer.RemoveAt(i);
                            i--;

                            if (!task.IsAlive)
                            {
                                AllTasks.Remove(task);
                            }
                        }
                    }
                }

                foreach (var item in taskBuffer)
                {
                    item.AverageFrameTickMs = item.AverageFrameTickMs / item.FrameTickCount;
                }

                //var friction = 4f;
                //var decay = 1f / (1f + (dt * friction));

                if (totalWorkMs > 0)
                {
                    foreach (var item in AllTasks)
                    {
                        var weight = item.FrameTimeMs / totalWorkMs;
                        //item.WorkWeight *= decay;
                        item.WorkWeight = weight;
                    }
                }

                //totalWorkLastTickMs *= decay;
                TotalWorkLastTickMs = totalWorkMs;

                yield return null;
                sw.Reset();
                sw.Start();
            }
        }

        // TODO: Add ability to provide an execution order int.

        public static BackgroundTaskHandle StartTask(string taskName, IEnumerator task)
        {
            var currTask = AllTasks.FirstOrDefault(x => x.Task == task);
            if (currTask != null)
            {
                throw new InvalidOperationException("Task is already running");
            }

            var handle = new BackgroundTaskHandle(taskName, task);
            AllTasks.Add(handle);
            return handle;
        }
    }

    [HideReferenceObjectPicker]
    public class BackgroundTaskHandle
    {
        [DisplayAsString] public string Name;
        [DisplayAsString] public bool IsPaused;
        [DisplayAsString] public int TickCount;
        [DisplayAsString] public int FrameTickCount;
        [DisplayAsString] public double AverageFrameTickMs;
        [DisplayAsString] public double FrameTimeMs;
        [DisplayAsString] public double TotalMsWorked;
        [DisplayAsString] public double WorkWeight;
        [DisplayAsString] public bool IsAlive;
        [HideInInspector] public readonly IEnumerator Task;
        [DisplayAsString] public bool Relaxed;

        public State CurrentState
        {
            get
            {
                if (this.IsPaused) return State.Paused;
                if (this.Relaxed) return State.Relaxed;
                if (this.IsAlive) return State.Running;

                return State.Killed;
            }
        }

        internal BackgroundTaskHandle(string taskName, IEnumerator task)
        {
            this.Name = taskName;
            this.Task = task;
            this.IsAlive = true;
        }

        public void Kill()
        {
            if (this.IsAlive)
            {
                this.IsAlive = false;
            }
            //else
            //{
            //    throw new InvalidOperationException("Cannot kill a task that is not alive.");
            //}
        }

        public void CompleteNow()
        {
            if (!this.IsAlive)
            {
                throw new InvalidOperationException("Cannot complete a task that is not alive.");
            }

            this.IsPaused = false;

            try
            {
                while (this.Task.MoveNext())
                {
                    this.TickCount++;
                }
            }
            finally
            {
                this.IsAlive = false;
            }
        }

        public void Pause()
        {
            this.IsPaused = true;
        }

        public void Continue()
        {
            this.IsPaused = false;
        }

        internal void MoveNext()
        {
            try
            {
                if (this.IsPaused)
                    return;

                if (!this.IsAlive)
                    return;

                if (this.Task.MoveNext())
                    this.Relaxed = this.Task.Current == BackgroundTaskRunner.Relax;
                else
                    this.IsAlive = false;

                this.TickCount++;
            }
            catch (Exception ex)
            {
                this.IsAlive = false;
                ex = ExceptionExtensions.UnwrapException(ex);
                Debug.LogException(ex);
            }
        }

        public enum State
        {
            Running,
            Paused,
            Relaxed,
            Killed,
        }
    }
}
#endif