//-----------------------------------------------------------------------
// <copyright file="SceneViewUtility.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor;
    using UnityEditor;
    using UnityEngine;

    internal static class SceneViewUtility
    {
        public static double lastSceneViewInteraction;

        [InitializeOnLoadMethod]
        private static void Init()
        {
            // 
            UnityEditorEventUtility.DuringSceneGUI += (sceneView) =>
            {
                if (Event.current.isKey || Event.current.isScrollWheel)
                {
                    lastSceneViewInteraction = EditorApplication.timeSinceStartup;
                }
                else if (Event.current.isMouse && Event.current.rawType != EventType.MouseMove)
                {
                    lastSceneViewInteraction = EditorApplication.timeSinceStartup;
                }
                else if (Event.current.rawType == EventType.Used)
                {
                    lastSceneViewInteraction = EditorApplication.timeSinceStartup;
                }
            };

            // Repaint sceneviews when validation has changed.
            ValidationSessionResultCollector.OnAnyResultsChanged += (session) =>
            {
                foreach (var item in ValidationSessionEditor.ActiveEditors)
                {
                    if (item.ValidationSession == session)
                    {
                        item.Window.Repaint();
                    }
                }

                if (!GlobalValidationConfig.ShowWidget)
                    return;

                foreach (var view in SceneView.sceneViews)
                    if (view is SceneView sceneView && sceneView != null)
                        sceneView.Repaint();
            };

            // Detect scene view camera movements:
            Vector3[] positions = new Vector3[0];
            Quaternion[] rotations = new Quaternion[0];
            EditorApplication.update += () =>
            {
                var sceneViews = SceneView.GetAllSceneCameras();

                if (sceneViews.Length != positions.Length)
                {
                    positions = new Vector3[sceneViews.Length];
                    rotations = new Quaternion[sceneViews.Length];
                }
                var isDirty = false;
                for (int i = 0; i < sceneViews.Length; i++)
                {
                    var trs = sceneViews[i].transform;

                    ref var p1 = ref positions[i];
                    ref var r1 = ref rotations[i];

                    var p2 = trs.position;
                    var r2 = trs.rotation;

                    isDirty = isDirty || p1 != p2 || r1 != r2;

                    p1 = p2;
                    r1 = r2;
                }

                if (isDirty)
                {
                    lastSceneViewInteraction = EditorApplication.timeSinceStartup;
                }
            };
        }
    }
}
#endif