//-----------------------------------------------------------------------
// <copyright file="OdinValidatorConfigAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.Utilities;

    internal class OdinValidatorConfigAttribute : GlobalConfigAttribute
    {
        public OdinValidatorConfigAttribute() : base(SirenixAssetPaths.SirenixPluginPath + "Odin Validator/Editor/Config/") { }
    }
}
#endif