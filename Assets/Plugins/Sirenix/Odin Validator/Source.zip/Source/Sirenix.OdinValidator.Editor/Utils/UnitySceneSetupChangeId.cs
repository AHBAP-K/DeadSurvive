//-----------------------------------------------------------------------
// <copyright file="UnitySceneSetupChangeId.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#pragma warning disable

namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector;
    using Sirenix.OdinInspector.Editor;
    using Sirenix.OdinInspector.Editor.Validation;
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Threading;
    using System.Threading.Tasks;
    using UnityEditor;
    using UnityEditor.SceneManagement;
    using UnityEngine;
    using UnityEngine.Events;
    using UnityEngine.SceneManagement;
    using static SceneValidationWidget;
    using static Sirenix.OdinValidator.Editor.ValidationSession;

    internal static class UnitySceneSetupChangeId
    {
        public static int SceneSetupChangeId { get; private set; }

        static UnitySceneSetupChangeId()
        {
            EditorSceneManager.sceneClosed += (a) => { Increment(); };
            EditorSceneManager.activeSceneChanged += (a, b) => { Increment(); };
            EditorSceneManager.sceneLoaded += (a, b) => { Increment(); };
            EditorSceneManager.activeSceneChangedInEditMode += (a, b) => { Increment(); };
            EditorSceneManager.sceneOpened += (a, b) => { Increment(); }; ;
            EditorSceneManager.newSceneCreated += (a, b, c) => { Increment(); };
            EditorSceneManager.sceneOpening += (a, b) => { Increment(); };
            EditorSceneManager.sceneClosing += (a, b) => { Increment(); };
            EditorSceneManager.sceneSaving += (a, b) => { Increment(); };
            EditorSceneManager.sceneSaved += (a) => { Increment(); };
        }

        private static void Increment()
        {
            SceneSetupChangeId++;
            EditorApplication.delayCall += () =>
            {
                SceneSetupChangeId++;
            };
        }
    }
}
#endif