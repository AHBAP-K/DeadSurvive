//-----------------------------------------------------------------------
// <copyright file="StringExtensions.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    internal static class StringExtensions
    {
        internal static string GetObjectNameFromAssetPath(this string path)
        {
            if (path == null)
            {
                return null;
            }

            var dot = path.LastIndexOf('.');

            if (dot >= 0)
            {
                path = path.Substring(0, dot);

                var dash = path.LastIndexOf('/');
                if (dash >= 0)
                {
                    path = path.Substring(dash + 1);
                }
            }
            else
            {
                var dash = path.LastIndexOf('/');
                if (dash >= 0)
                {
                    path = path.Substring(dash + 1);
                }
            }

            return path;
        }
    }
}


//public class ValidationFilter
//{

//}


////public class WatchedAsset
////{
////    public string Path;
////    public 
////}

//public class ValidationRunner
//{
//    public object ValidateTheThing() { throw new NotImplementedException(); }
//}

//public struct ThingToDo
//{
//    public string Path;
//    public UnityEngine.Object Object;
//    public ThingToDoType Type;

//    public enum ThingToDoType
//    {
//        Added,
//        Removed
//    }
//}

//public class ValidationSession
//{
//    public ValidationRunConfig Config;
//    public Action OnSomeStuffHappened;
//    public ValidationRunner Runner;

//    private HashQueue<ThingToDo> thingsToDo;

//    public void Start(bool startWithFullScan = true, bool watchForChanges)
//    {
//        if (startWithFullScan)
//        {
//            this.thingsToDo = new Queue<ThingToDo>(this.Config.GetPathsToValidate());
//        }
//        else
//        {
//            this.thingsToDo = new Queue<ThingToDo>();
//        }

//        if (watchForChanges)
//        {
//            // Subscribe to all the events etc
//        }
//    }

//    public void Stop()
//    {
//        // Desubscribe from all the events etc
//    }

//    public void ProcessQueueStep(int millisecondsToProcess)
//    {
//        bool thereIsTime = true;

//        while (thereIsTime && this.thingsToDo.Count > 0)
//        {
//            this.Process(this.thingsToDo.Dequeue());
//        }
//    }

//    public void ProcessEntireQueue()
//    {
//        while (this.thingsToDo.Count > 0)
//        {
//            this.Process(this.thingsToDo.Dequeue());
//        }
//    }

//    private void Process(ThingToDo thing)
//    {
//        // Validate (or revalidate) the thing   
//        // Push events and stuff, this code is wrong but this is where it happens
//    }
//}

//public static class ValidationDoer
//{
//    public static IEnumerable<ValidationResultSet> Validate(ValidationRunConfig config) { throw new NotImplementedException(); }
//}

//public class ValidationResultSet
//{
//    public string Path;
//    public List<ValidationResult> Results;
//    public object TargetRecoveryData; // Stuff to go get the thing again, scene or asset or whatever
//}
#endif