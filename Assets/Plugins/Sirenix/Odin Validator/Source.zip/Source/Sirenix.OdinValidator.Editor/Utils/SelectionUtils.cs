//-----------------------------------------------------------------------
// <copyright file="SelectionUtils.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#pragma warning disable

namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector;
    using Sirenix.OdinInspector.Editor;
    using Sirenix.OdinInspector.Editor.Validation;
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Threading;
    using System.Threading.Tasks;
    using UnityEditor;
    using UnityEditor.SceneManagement;
    using UnityEngine;
    using UnityEngine.Events;
    using UnityEngine.SceneManagement;
    using static SceneValidationWidget;
    using static Sirenix.OdinValidator.Editor.ValidationSession;

    internal static class SelectionUtils
    {
        public static int SelectionChangedId { get; private set; }

        private static int selectionRequestedId = -1;

        private static HashSet<int> selection = new HashSet<int>();

        public static HashSet<int> Selection
        {
            get
            {
                if (SelectionChangedId != selectionRequestedId)
                {
                    selection.Clear();

                    foreach (var item in UnityEditor.Selection.objects)
                    {
                        if (item)
                        {
                            var go = item as GameObject;
                            if (go)
                            {
                                foreach (var cmp in go.GetComponents<UnityEngine.Component>())
                                {
                                    if (cmp)
                                    {
                                        selection.Add(cmp.GetInstanceID());
                                    }
                                }
                            }

                            selection.Add(item.GetInstanceID());
                        }
                    }

                    selectionRequestedId = SelectionChangedId;
                }

                return selection;
            }
        }

        [InitializeOnLoadMethod]
        static void Init()
        {
            UnityEditor.Selection.selectionChanged += () =>
            {
                SelectionChangedId++;
            };
        }

        public static void AddToSelection(IEnumerable<DynamicObjectAddress> objAddress)
        {
            var ids = new List<int>();
            var toExpand = new HashSet<Component>();
            var toCollapse = new HashSet<Component>();

            foreach (var item in objAddress)
            {
                if (item == null || item.IsUnloaded) continue;

                if (item.TryGetObjectReference(false, false, out var result, out var error) && result)
                {
                    if (result is Component)
                    {
                        var cmp = (Component)result;

                        if (cmp.gameObject)
                        {
                            var cmps = cmp.gameObject.GetComponents<Component>();

                            foreach (var c in cmps)
                            {
                                toCollapse.Add(c);
                            }

                            toExpand.Add(cmp);
                            ids.Add(cmp.gameObject.GetInstanceID());
                        }
                    }
                    else
                    {
                        ids.Add(result.GetInstanceID());
                    }
                }
            }

            UnityEditor.Selection.instanceIDs = UnityEditor.Selection.instanceIDs.Concat(ids).Distinct().ToArray();

            if (GlobalValidationConfig.OpenComponentInInspectorAndCloseOthers)
            {
                foreach (var item in toCollapse)
                    UnityEditorInternal.InternalEditorUtility.SetIsInspectorExpanded(item, false);

                foreach (var item in toExpand)
                    UnityEditorInternal.InternalEditorUtility.SetIsInspectorExpanded(item, true);
            }

            ActiveEditorTracker.sharedTracker.ForceRebuild();

            if (GlobalValidationConfig.FrameSelection)
            {
                var bounds = UnityEditorInternal.InternalEditorUtility.CalculateSelectionBounds(false, false);
                SceneView.lastActiveSceneView.Frame(bounds, false);
            }
        }

        public static void SelectInInspector(DynamicObjectAddress objAddress, bool allowOpenScene, bool ping)
        {
            if (objAddress == null) return;

            var success = objAddress.TryGetObjectReference(allowOpenScene, false, out var result, out var error, out var closest);

            if (!success)
            {
                if (closest != null)
                {
                    // We found a closest object
                    result = closest;
                    success = true;
                }
                else if (objAddress.IsBroken && objAddress.LatestAddress.SubAsset.Index > 0 && objAddress.LatestAddress.Type == ObjectAddress.AddressType.Asset)
                {
                    // Select main asset instead of broken sub asset.
                    if (!string.IsNullOrEmpty(objAddress.LatestAddress.AssetPath))
                    {
                        result = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(objAddress.LatestAddress.AssetPath);
                        success = result;
                    }
                }
            }

            if (success)
            {
                Transform trs = null;

                if (result is Component cmp && cmp)
                {
                    if (cmp.gameObject)
                    {
                        trs = cmp.transform;

                        UnityEditor.Selection.instanceIDs = new int[] { cmp.gameObject.GetInstanceID() };

                        if (GlobalValidationConfig.OpenComponentInInspectorAndCloseOthers)
                        {
                            foreach (var item in cmp.GetComponents<Component>())
                                UnityEditorInternal.InternalEditorUtility.SetIsInspectorExpanded(item, false);
                            UnityEditorInternal.InternalEditorUtility.SetIsInspectorExpanded(result, true);
                        }

                        ActiveEditorTracker.sharedTracker.ForceRebuild();
                    }
                    else
                    {
                        // The inspector will barf if the component is not attached to a gameobject. 
                    }
                }
                else
                {
                    UnityEditor.Selection.instanceIDs = new int[] { result.GetInstanceID() };
                }

                if (ping)
                {
                    if (GlobalValidationConfig.PingOnDoubleClick)
                        EditorGUIUtility.PingObject(result);

                    if (trs && GlobalValidationConfig.FocusObjectOnDoubleClick)
                    {
                        var bounds = UnityEditorInternal.InternalEditorUtility.CalculateSelectionBounds(false, false);
                        bounds.extents += Vector3.one * 2;
                        SceneView.lastActiveSceneView.Frame(bounds, false);
                    }
                }
            }
            else if (ping)
            {
                // We can't ping broken objects, so instead we ping the folder.
                var assetPath = objAddress.LatestAddress?.AssetPath;
                if (!string.IsNullOrEmpty(assetPath))
                {
                    var dir = PathUtilities.GetDirectoryName(assetPath);
                    var folder = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(dir);
                    if (folder)
                        EditorGUIUtility.PingObject(folder);
                }
            }
        }
    }
}
#endif