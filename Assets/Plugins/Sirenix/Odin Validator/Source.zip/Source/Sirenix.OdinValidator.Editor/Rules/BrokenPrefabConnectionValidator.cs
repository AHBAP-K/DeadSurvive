//-----------------------------------------------------------------------
// <copyright file="BrokenPrefabConnectionValidator.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
using Sirenix.OdinInspector.Editor.Validation;
using Sirenix.OdinValidator.Editor.Validators;
using UnityEditor;
using UnityEngine;
using Sirenix.Utilities;
using System;
using Sirenix.OdinInspector.Editor;
using Sirenix.OdinInspector;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

[assembly: RegisterValidationRule(typeof(BrokenPrefabConnectionValidator))]
[assembly: RegisterValidationRule(typeof(InvalidLayerValidator))]
[assembly: RegisterValidationRule(typeof(MissingScriptValidator))]
[assembly: RegisterValidationRule(typeof(HugeTransformPositionsValidator))]
[assembly: RegisterValidationRule(typeof(DuplicateComponentsValidator))]
[assembly: RegisterValidationRule(typeof(DuplicateComponentsValidator))]
[assembly: RegisterValidationRule(typeof(ShaderCompilerErrorsValidator))]
[assembly: RegisterValidationRule(typeof(MustBeAPrefabValidator), enabledByDefault: false)]
[assembly: RegisterValidationRule(typeof(MeshRendererValidator))]

[assembly: RegisterValidator(typeof(DetectComponentsNotAttachedToGameobject<>))]
[assembly: RegisterValidator(typeof(ObsoleteAttributeValidator<>))]

namespace Sirenix.OdinValidator.Editor.Validators
{
    public class BrokenPrefabConnectionValidator : RootObjectValidator<GameObject>
    {
        protected override void Validate(ValidationResult result)
        {
            var go = this.ValueEntry.SmartValue;
            var status = PrefabUtility.GetPrefabInstanceStatus(go);

            if (status == PrefabInstanceStatus.MissingAsset)
            {
                if (go == PrefabUtility.GetOutermostPrefabInstanceRoot(go))
                {
                    result.ResultType = ValidationResultType.Error;
                    result.Message = "The source Prefab or Model has been deleted";
                }
            }
        }
    }

    [IncludeMyAttributes]
    [ValueDropdown("@LayerSelectorAttribute.GetLayers()")]
    internal class LayerSelectorAttribute : Attribute
    {
        private static IEnumerable<ValueDropdownItem> GetLayers()
        {
            for (int i = 0; i < 32; i++)
            {
                var layer = LayerMask.LayerToName(i);

                if (!string.IsNullOrEmpty(layer))
                {
                    yield return new ValueDropdownItem(layer, i);
                }
            }
        }
    }

    public class HugeTransformPositionsValidator : RootObjectValidator<Transform>
    {
        public float SizeLimit = 100_000;

        public ValidatorSeverity Severity = ValidatorSeverity.Warning;

        protected override void Validate(ValidationResult result)
        {
            var p = this.Object.position;

            if (Math.Abs(p.x) > this.SizeLimit || Math.Abs(p.y) > this.SizeLimit || Math.Abs(p.z) > this.SizeLimit)
            {
                var msg = "Due to floating-point precision limitations, it is recommended to bring the world coordinates of the GameObject within a smaller range.";
                if (this.Severity == ValidatorSeverity.Error)
                {
                    result.AddError(msg);
                }
                else
                {
                    result.AddWarning(msg);
                }
            }
        }
    }

    public class MeshRendererValidator : RootObjectValidator<MeshRenderer>
    {
        [EnumToggleButtons]
        public ValidatorSeverity PrefabModificationsSeverity = ValidatorSeverity.Ignore;

        [EnumToggleButtons]
        public ValidatorSeverity MissingMaterialSeverity = ValidatorSeverity.Error;

        [EnumToggleButtons]
        public ValidatorSeverity BrokenMaterialSeverity = ValidatorSeverity.Error;

        protected override void Validate(ValidationResult result)
        {
            var obj = this.Object;

            if (PrefabModificationsSeverity != ValidatorSeverity.Ignore)
            {
                if (!string.IsNullOrEmpty(obj.gameObject.scene.path))
                {
                    var mods = PrefabUtility.GetPropertyModifications(obj);

                    if (mods != null)
                    {
                        var correspondingObj = PrefabUtility.GetCorrespondingObjectFromSource(obj);

                        if (!string.IsNullOrEmpty(this.Object.gameObject.scene.path))
                        {
                            for (int i = 0; i < mods.Length; i++)
                            {
                                if (mods[i].target == correspondingObj)
                                {
                                    result.Add(PrefabModificationsSeverity, "Mesh Renderer contains prefab modifications which is " +
                                        "not allowed in this project. ", Fix.Create("Clear prefab modification", RemovePrefabMods));
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            var materials = this.Object.sharedMaterials;
            if (materials.Length == 0)
            {
                result.Add(MissingMaterialSeverity, "Mesh Renderer is missing a material", Fix.Create<FixArgs>(args =>
                {
                    this.Object.sharedMaterial = args.Material;
                }));
            }
            else
            {
                for (int i = 0; i < materials.Length; i++)
                {
                    var localI = i;
                    var sharedMat = materials[i];
                    if (sharedMat == null)
                    {
                        result.Add(MissingMaterialSeverity, "Mesh Renderer is missing a material", Fix.Create<FixArgs>(args =>
                        {
                            this.Object.sharedMaterials[localI] = args.Material;
                        }));
                    }
                    else
                    {
                        if (sharedMat.shader == null)
                        {
                            result.Add(this.BrokenMaterialSeverity, "Mesh Renderer contains material with missing shader");
                        }
                        else if (sharedMat.shader.name == "")
                        {
                            result.Add(this.BrokenMaterialSeverity, "Mesh Renderer contains material with missing shader");
                        }
                        else if (OdinShaderUtil.ShaderHasErrorIsSupported && OdinShaderUtil.ShaderHasError(sharedMat.shader))
                        {
                            result.Add(this.BrokenMaterialSeverity, "Mesh Renderer contains material with shader errors", new MetaData()
                        {
                            { "Material", sharedMat  },
                            { "Shader", sharedMat.shader  },
                        });
                        }
                    }
                }
            }
        }

        internal class OdinShaderUtil
        {
            static OdinShaderUtil()
            {
                var shaderHasErrorMethod = typeof(ShaderUtil).GetMethod("ShaderHasError", new Type[] { typeof(Shader) });
                if (shaderHasErrorMethod != null)
                {
                    ShaderHasErrorIsSupported = true;
                    ShaderHasError = (Func<Shader, bool>)shaderHasErrorMethod.CreateDelegate(typeof(Func<Shader, bool>));
                }
            }

            public static readonly bool ShaderHasErrorIsSupported;
            public static readonly Func<Shader, bool> ShaderHasError;
        }

        [ShowOdinSerializedPropertiesInInspector]
        internal class FixArgs
        {
            [Required]
            public Material Material;
        }

        private void RemovePrefabMods()
        {
            var obj = this.Object;
            var mods = PrefabUtility.GetPropertyModifications(obj);
            var correspondingObj = PrefabUtility.GetCorrespondingObjectFromSource(obj);
            var isDirty = false;
            for (int i = mods.Length - 1; i >= 0; i--)
            {
                if (mods[i].target == correspondingObj)
                {
                    mods = ArrayUtilities.CreateNewArrayWithRemovedElement(mods, i);
                    isDirty = true;
                }
            }

            if (isDirty)
            {
                PrefabUtility.SetPropertyModifications(obj, mods);
            }
        }
    }

    public class MissingScriptValidator : RootObjectValidator<GameObject>
    {
        protected override void Validate(ValidationResult result)
        {
            var cmps = this.Object.GetComponents(typeof(Component));
            for (int i = 0; i < cmps.Length; i++)
            {
                var cmp = cmps[i];
                if (!cmp)
                {
                    result.AddWarning("Missing Component, the associated script can not be loaded.", Fix.Create<FixArgs>("Remove Missing Components", (arg) =>
                   {
                       var x = GameObjectUtility.RemoveMonoBehavioursWithMissingScript(this.Object);

                       //var assetPath = AssetDatabase.GetAssetPath(s);
                       //var go = PrefabUtility.LoadPrefabContents(assetPath);
                       //GameObjectUtility.RemoveMonoBehavioursWithMissingScript(go);
                       //PrefabUtility.SaveAsPrefabAsset(go, assetPath);
                       //PrefabUtility.UnloadPrefabContents(go);
                   }));
                    return;
                }
            }
        }

        private class FixArgs
        {
            [OnInspectorGUI]
            [InfoBox(
                "Automatically removing components is only as good as Unity's " +
                "GameObjectUtility.RemoveMonoBehavioursWithMissingScript(go) which does not work in all cases.")]
            private void OnGUI()
            {

            }
        }
    }

    public class DuplicateComponentsValidator : RootObjectValidator<GameObject>
    {
        static HashSet<Type> buffer = new HashSet<Type>();

        public Type[] Exceptions = new Type[0];

        protected override void Validate(ValidationResult result)
        {
            var cmps = this.Object.GetComponents(typeof(Component));
            buffer.Clear();
            for (int i = 0; i < cmps.Length; i++)
            {
                var cmp = cmps[i];
                if (cmp)
                {
                    if (!buffer.Add(cmp.GetType()) && !this.Exceptions.Contains(cmp.GetType()))
                    {
                        result.AddWarning("GameObject contains duplicate components.");
                        return;
                    }
                }
            }
        }
    }

    public class MustBeAPrefabValidator : RootObjectValidator<GameObject>
    {
        [ValueDropdown(nameof(GetAllCmpTypes), IsUniqueList = true)]
        public Type[] ComponentTypes = new Type[0];

        public string MakePrefabAssetLocation = "Assets/";

        IEnumerable<ValueDropdownItem> GetAllCmpTypes()
        {
            foreach (var item in UnityTypeCacheUtility.GetTypesDerivedFrom(typeof(Component)))
            {
                yield return new ValueDropdownItem(item.GetNiceName(), item);
            }
        }

        protected override void Validate(ValidationResult result)
        {
            if (this.ComponentTypes.Length == 0)
            {
                return;
            }

            var obj = this.Object;
            foreach (var cmp in obj.GetComponents(typeof(Component)))
            {
                if (cmp && this.ComponentTypes.Contains(cmp.GetType()))
                {
                    if (!PrefabUtility.IsPartOfPrefabInstance(obj) && obj.gameObject.scene.IsValid())
                    {
                        result.AddError("GameObject must be a prefab", Fix.Create("Convert to prefab", () =>
                        {
                            var path = this.MakePrefabAssetLocation + obj.gameObject.name + ".prefab";
                            path = AssetDatabase.GenerateUniqueAssetPath(path);
                            var status = PrefabUtility.GetPrefabInstanceStatus(obj);

                            if (status == PrefabInstanceStatus.Disconnected)
                            {
                                // TODO: Connect it again..
                                //PrefabUtility.GetPrefabInstanceHandle(PrefabUtility)
                                //PrefabUtility.ConnectGameObjectToPrefab(obj, );
                                return;
                            }
                            else if (status == PrefabInstanceStatus.MissingAsset)
                            {
                                PrefabUtility.UnpackPrefabInstance(obj, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
                            }

                            PrefabUtility.SaveAsPrefabAsset(obj.gameObject, path);
                        }));
                        return;
                    }
                }
            }
        }
    }

    public class ShaderCompilerErrorsValidator : RootObjectValidator<Shader>
    {
        static MethodInfo getMessages;

        [ShowInInspector]
        public bool IsSupported => getMessages != null;

        [EnableIf("IsSupported")]
        public bool LogWarnings = false;

        static ShaderCompilerErrorsValidator()
        {
            getMessages = typeof(ShaderUtil).GetMethod("GetShaderMessages", new Type[] { typeof(Shader) });
        }

        protected override bool CanValidateObject(Shader obj)
        {
            return getMessages != null && base.CanValidateObject(obj);
        }

        protected override void Validate(ValidationResult result)
        {
            var shader = this.Object;

            var arr = getMessages.Invoke(null, new object[] { shader }) as IList;

            if (arr != null)
            {
                for (int i = 0; i < arr.Count; i++)
                {
                    var m = arr[i];
                    var mType = m.GetType();

                    try
                    {
                        var message = mType.GetProperty("message").GetMethod.Invoke(m, null) as string;
                        var messageDetails = mType.GetProperty("messageDetails").GetMethod.Invoke(m, null) as string;
                        var platform = mType.GetProperty("platform").GetMethod.Invoke(m, null);
                        var line = mType.GetProperty("line").GetMethod.Invoke(m, null);
                        var severity = Convert.ToInt32(mType.GetProperty("severity").GetMethod.Invoke(m, null));

                        var metaData = new MetaData()
                    {
                        { "Platform", platform },
                        { "Line", line },
                        { "Message Details", messageDetails },
                    };
                        if (severity == 0)
                            result.AddError(message, metaData);
                        else if (this.LogWarnings)
                            result.AddWarning(message, metaData);
                    }
                    catch
                    {
                        // TODO...
                    }

                }
            }

            //var messages = ShaderUtil.GetShaderMessages(s);
            //foreach (var item in messages)
            //{
            //    item.message;
            //    item.platform;
            //    item.line;
            //    item.file;
            //    item.severity == UnityEditor.Rendering.ShaderCompilerMessageSeverity.Error; 0;
            //    item.severity == UnityEditor.Rendering.ShaderCompilerMessageSeverity.Warning; 1;
            //}
        }
    }

    public class InvalidLayerValidator : RootObjectValidator<GameObject>
    {
        protected override void Validate(ValidationResult result)
        {
            if (string.IsNullOrEmpty(LayerMask.LayerToName(this.Object.layer)))
            {
                var msg = "Invalid Layer " + this.Object.layer;
                result.AddError(msg, Fix.Create((LayerFix args) =>
                {
                    this.Object.layer = args.Layer;
                }));
            }
        }

        private class LayerFix
        {
            [LayerSelector]
            public int Layer;
        }
    }

    public class ObsoleteAttributeValidator<T> : RootObjectValidator<T>
        where T : UnityEngine.Object
    {
        protected override bool CanValidateObject(T obj)
        {
            return typeof(T).IsDefined<ObsoleteAttribute>();
        }

        protected override bool CanValidateRootProperty(InspectorProperty rootProperty)
        {
            return typeof(T).IsDefined<ObsoleteAttribute>();
        }

        protected override void Validate(ValidationResult result)
        {
            var attr = this.Property.GetAttribute<ObsoleteAttribute>();
            var error = attr.IsError;

            result.Message = typeof(T).GetNiceFullName() + " is marked obsolete.";

            if (!string.IsNullOrEmpty(attr.Message))
            {
                result.Message += " " + attr.Message;
            }

            result.ResultType = error ? ValidationResultType.Error : ValidationResultType.Warning;
        }
    }

    public class DetectComponentsNotAttachedToGameobject<T> : RootObjectValidator<T>
        where T : UnityEngine.Component
    {
        protected override void Validate(ValidationResult result)
        {
            if (!this.Object.gameObject)
            {
                result.AddError("Component is not attached to gameobject. This can happen when a component changed from being a Component/MonoBehaviour to ScriptableObejct.");
            }
        }
    }
}
#endif