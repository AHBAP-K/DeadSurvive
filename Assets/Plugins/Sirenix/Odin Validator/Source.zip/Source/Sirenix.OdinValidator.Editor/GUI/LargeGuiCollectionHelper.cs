//-----------------------------------------------------------------------
// <copyright file="LargeGuiCollectionHelper.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.Utilities.Editor;
    using UnityEngine;

    internal struct LargeGuiCollectionHelper
    {
        public int ElementHeight;
        public Rect TotalRect;
        public Rect VisisbleRect;
        public int StartIndex;
        public int EndIndex;

        public Rect GetRect(int index)
        {
            return new Rect(this.TotalRect.x, this.TotalRect.y + index * this.ElementHeight, this.TotalRect.width, this.ElementHeight);
        }

        internal void AllocateLayout(int elementHeight, int elementCount)
        {
            this.ElementHeight = elementHeight;
            var totalHeight = elementHeight * elementCount;

            var r = GUILayoutUtility.GetRect(0, totalHeight);

            if (Event.current.type == EventType.Repaint)
            {
                this.TotalRect = r;
                this.VisisbleRect = GUIClipInfo.VisibleRect;
            }

            var yOffset = this.VisisbleRect.y - this.TotalRect.y;

            StartIndex = (int)(yOffset / this.ElementHeight) - 2;
            EndIndex = StartIndex + (int)((this.VisisbleRect.height - this.TotalRect.y) / this.ElementHeight) + 6;

            StartIndex = Mathf.Clamp(StartIndex, 0, elementCount);
            EndIndex = Mathf.Clamp(EndIndex, 0, elementCount);
        }

        internal void ScrollTo(int selectedIndex, ref Vector2 scrollPos, float padding = 0)
        {
            var rect = this.GetRect(selectedIndex);
            var visibleRect = this.VisisbleRect;

            if (visibleRect.y > rect.y - padding)
            {
                scrollPos.y = rect.y - padding;
            }

            if (visibleRect.yMax < rect.yMax + padding)
            {
                scrollPos.y = rect.yMax + padding - visibleRect.height;
            }
        }
    }
}
#endif