//-----------------------------------------------------------------------
// <copyright file="ValidatorScriptTemplates.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor;
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor.Expressions;
    using System.IO;
    using UnityEditor;
    using UnityEngine;

    public static class ValidatorScriptTemplates
    {
        public static readonly string Rule_RootObjectValidatorFileTemplate =
@"#if UNITY_EDITOR
using Sirenix.OdinInspector.Editor.Validation;
using UnityEngine;
using UnityEditor;

[assembly: RegisterValidationRule(typeof({name}), Name = ""{name}"", Description = ""Some description text."")]

public class {name} : RootObjectValidator<{target}>
{
    // Introduce serialized fields here to make your validator
    // configurable from the validator window under rules.
    public int SerializedConfig;

    protected override void Validate(ValidationResult result)
    {
        // var obj = this.Object;
        // if (obj has something wrong with it)
        // {
        //     result.AddError(""Something is wrong"");
        // }
    }
}
" + "#endif" + @"
";

        public static readonly string Standard_RootObjectValidatorFileTemplate =
@"#if UNITY_EDITOR
using Sirenix.OdinInspector.Editor.Validation;
using UnityEngine;
using UnityEditor;

[assembly: RegisterValidator(typeof({name}<>))]

public class {name}<T> : RootObjectValidator<T>
{
    protected override void Validate(ValidationResult result)
    {
        // var obj = this.Object;
        // if (obj has something wrong with it)
        // {
        //     result.AddError(""Something is wrong"");
        // }
    }
}
" + "#endif" + @"
";

        public static readonly string Rule_ValueValidatorFileTemplate_Class =
@"#if UNITY_EDITOR
using Sirenix.OdinInspector.Editor.Validation;
using UnityEngine;
using UnityEditor;

[assembly: RegisterValidationRule(typeof({name}), Name = ""{name}"", Description = ""Some description text."")]

public class {name} : ValueValidator<{target}>
{
    // Introduce serialized fields here to make your validator
    // configurable from the validator window under rules.
    public int SerializedConfig;

    protected override void Validate(ValidationResult result)
    {
        //var val = this.ValueEntry.SmartValue;
        
        //if (val has something wrong with it)
        //{
        //    result.AddError(""Something is wrong"");
        //}
    }
}
" + "#endif" + @"
";

        public static readonly string Standard_ValueValidatorFileTemplate_Class =
@"#if UNITY_EDITOR
using Sirenix.OdinInspector.Editor.Validation;
using UnityEngine;
using UnityEditor;

[assembly: RegisterValidator(typeof({name}<>))]

public class {name}<T> : ValueValidator<T>
    where T : {target}
{
    protected override void Validate(ValidationResult result)
    {
        //var val = this.ValueEntry.SmartValue;
        
        //if (val has something wrong with it)
        //{
        //    result.AddError(""Something is wrong"");
        //}
    }
}
" + "#endif" + @"
";

        public static readonly string Rule_ValueValidatorFileTemplate_Struct =
@"#if UNITY_EDITOR
using Sirenix.OdinInspector.Editor.Validation;
using UnityEngine;
using UnityEditor;

[assembly: RegisterValidationRule(typeof({name}), Name = ""{name}"", Description = ""Some description text."")]

public class {name} : ValueValidator<{target}>
{
    // Introduce serialized fields here to make your validator
    // configurable from the validator window under rules.
    public int SerializedConfig;

    protected override void Validate(ValidationResult result)
    {
        //var val = this.ValueEntry.SmartValue;
        
        //if (val has something wrong with it)
        //{
        //    result.AddError(""Something is wrong"");
        //}
    }
}
" + "#endif" + @"
";

        public static readonly string Standard_ValueValidatorFileTemplate_Struct =
@"#if UNITY_EDITOR
using Sirenix.OdinInspector.Editor.Validation;
using UnityEngine;
using UnityEditor;

[assembly: RegisterValidator(typeof({name}))]

public class {name} : ValueValidator<{target}>
{
    protected override void Validate(ValidationResult result)
    {
        //var val = this.ValueEntry.SmartValue;
        
        //if (val has something wrong with it)
        //{
        //    result.AddError(""Something is wrong"");
        //}
    }
}
" + "#endif" + @"
";

        public static readonly string Rule_AttributeValidatorFileTemplate =
@"#if UNITY_EDITOR
using Sirenix.OdinInspector.Editor.Validation;
using UnityEngine;
using UnityEditor;

[assembly: RegisterValidationRule(typeof({name}), Name = ""{name}"", Description = ""Some description text."")]

public class {name} : AttributeValidator<{target}, TargetValueType>
{
    // Introduce serialized fields here to make your validator
    // configurable from the validator window under rules.
    public int SerializedConfig;

    protected override void Validate(ValidationResult result)
    {
        //var attr = this.Attribute;
        //var val = this.ValueEntry.SmartValue;

        //if (val has something wrong with it)
        //{
        //    result.AddError(""Something is wrong"");
        //}
    }
}

// Alternative version that does not target a specific type of value (above must be deleted or commented out for the below to work)

//[assembly: RegisterValidator(typeof({name}))]

//public class {name} : AttributeValidator<{target}>
//{
//    // Introduce serialized fields here to make your validator
//    // configurable from the validator window under rules.
//    public int SerializedConfig;
//
//    protected override void Validate(ValidationResult result)
//    {
//        //var attr = this.Attribute;
//
//        //if (if something is wrong)
//        //{
//        //    result.AddError(""Something is wrong"");
//        //}
//    }
//}
" + "#endif" + @"
";

        public static readonly string Standard_AttributeValidatorFileTemplate =
@"#if UNITY_EDITOR
using Sirenix.OdinInspector.Editor.Validation;
using UnityEngine;
using UnityEditor;

[assembly: RegisterValidator(typeof({name}<>))]

public class {name}<T> : AttributeValidator<{target}, T>
    where T : TargetValueType
{
    protected override void Validate(ValidationResult result)
    {
        //var attr = this.Attribute;
        //var val = this.ValueEntry.SmartValue;

        //if (val has something wrong with it)
        //{
        //    result.AddError(""Something is wrong"");
        //}
    }
}

// Alternative version that does not target a specific type of value (above must be deleted or commented out for the below to work)

//[assembly: RegisterValidator(typeof({name}))]

//public class {name} : AttributeValidator<{target}>
//{
//    protected override void Validate(ValidationResult result)
//    {
//        //var attr = this.Attribute;
//
//        //if (if something is wrong)
//        //{
//        //    result.AddError(""Something is wrong"");
//        //}
//    }
//}
" + "#endif" + @"
";

        public static readonly EditorPrefString LastTemplateFolderPath = new EditorPrefString("SIRENIX_ODINVALIDATOR_LASTTEMPLATEPATH", "Assets");

        public static void CreateTemplateScriptFile(string filePath, string template, string defaultTargetName)
        {
            var validatorName = Path.GetFileNameWithoutExtension(filePath);
            string targetName;

            if (validatorName.FastEndsWith("Validator"))
            {
                targetName = validatorName.Substring(0, validatorName.Length - "Validator".Length);
            }
            else
            {
                targetName = defaultTargetName;
            }

            File.WriteAllText(filePath, template.Replace("{name}", validatorName).Replace("{target}", targetName));
            AssetDatabase.Refresh();

            var fullFolderPath = new DirectoryInfo(Path.GetDirectoryName(filePath)).FullName;

            if (PathUtilities.TryMakeRelative(Directory.GetCurrentDirectory(), fullFolderPath, out var relativePath))
            {
                LastTemplateFolderPath.Value = relativePath;
            }
            else
            {
                LastTemplateFolderPath.Value = fullFolderPath;
            }
        }

        public static void AddTemplateScriptCreationToGenericMenu(GenericMenu menu, string prependMenuPath = null)
        {
            if (prependMenuPath != null && !prependMenuPath.EndsWith("/"))
            {
                prependMenuPath += "/";
            }

            menu.AddItem(new GUIContent($"{prependMenuPath}Create Rule/Root Object Validator"), false, () =>
            {
                CreateRuleRootObjectValidator(LastTemplateFolderPath);
            });

            menu.AddItem(new GUIContent($"{prependMenuPath}Create Rule/Value Validator"), false, () =>
            {
                CreateRuleValueValidator(LastTemplateFolderPath);
            });

            menu.AddItem(new GUIContent($"{prependMenuPath}Create Rule/Attribute Validator"), false, () =>
            {
                CreateRuleAttributeValidator(LastTemplateFolderPath);
            });

            menu.AddItem(new GUIContent($"{prependMenuPath}Create Validator/Root Object Validator"), false, () =>
            {
                CreateStandardRootObjectValidator(LastTemplateFolderPath);
            });

            menu.AddItem(new GUIContent($"{prependMenuPath}Create Validator/Value Validator"), false, () =>
            {
                CreateStandardValueValidator(LastTemplateFolderPath);
            });

            menu.AddItem(new GUIContent($"{prependMenuPath}Create Validator/Attribute Validator"), false, () =>
            {
                CreateStandardAttributeValidator(LastTemplateFolderPath);
            });
        }

        public static void CreateStandardAttributeValidator(string saveFilePanelFolderPath)
        {
            var filePath = EditorUtility.SaveFilePanelInProject("Create Attribute Validator Script", "MyAttributeValidator.cs", "cs", "Choose a file path to create an attribute validator script file at.", saveFilePanelFolderPath);

            if (!string.IsNullOrEmpty(filePath))
            {
                CreateTemplateScriptFile(filePath, Standard_AttributeValidatorFileTemplate, "MyAttributeType");
            }
        }

        public static void CreateStandardValueValidator(string saveFilePanelFolderPath)
        {
            var filePath = EditorUtility.SaveFilePanelInProject("Create Value Validator Script", "MyValueValidator.cs", "cs", "Choose a file path to create a value validator script file at.", saveFilePanelFolderPath);

            if (!string.IsNullOrEmpty(filePath))
            {
                var name = Path.GetFileNameWithoutExtension(filePath);
                bool useStructTemplate = false;

                if (name.FastEndsWith("Validator"))
                {
                    var target = name.Substring(0, name.Length - "Validator".Length);

                    if (ExpressionUtility.TryParseTypeNameAsCSharpIdentifier(target, out var type) && type.IsValueType)
                    {
                        useStructTemplate = true;
                    }
                }

                CreateTemplateScriptFile(filePath, useStructTemplate ? Standard_ValueValidatorFileTemplate_Struct : Standard_ValueValidatorFileTemplate_Class, "MyValueType");
            }
        }

        public static void CreateRuleRootObjectValidator(string saveFilePanelFolderPath)
        {
            var filePath = EditorUtility.SaveFilePanelInProject("Create Root Object Validator Script", "MyRootObjectValidator.cs", "cs", "Choose a file path to create a root object validator script file at.", saveFilePanelFolderPath);

            if (!string.IsNullOrEmpty(filePath))
            {
                CreateTemplateScriptFile(filePath, Rule_RootObjectValidatorFileTemplate, "MyUnityObjectType");
            }
        }

        public static void CreateRuleValueValidator(string saveFilePanelFolderPath)
        {
            var filePath = EditorUtility.SaveFilePanelInProject("Create Value Validator Script", "MyValueValidator.cs", "cs", "Choose a file path to create a value validator script file at.", saveFilePanelFolderPath);

            if (!string.IsNullOrEmpty(filePath))
            {
                var name = Path.GetFileNameWithoutExtension(filePath);
                bool useStructTemplate = false;

                if (name.FastEndsWith("Validator"))
                {
                    var target = name.Substring(0, name.Length - "Validator".Length);

                    if (ExpressionUtility.TryParseTypeNameAsCSharpIdentifier(target, out var type) && type.IsValueType)
                    {
                        useStructTemplate = true;
                    }
                }

                CreateTemplateScriptFile(filePath, useStructTemplate ? Rule_ValueValidatorFileTemplate_Struct : Rule_ValueValidatorFileTemplate_Class, "MyValueType");
            }
        }

        public static void CreateRuleAttributeValidator(string saveFilePanelFolderPath)
        {
            var filePath = EditorUtility.SaveFilePanelInProject("Create Attribute Validator Script", "MyAttributeValidator.cs", "cs", "Choose a file path to create an attribute validator script file at.", saveFilePanelFolderPath);

            if (!string.IsNullOrEmpty(filePath))
            {
                CreateTemplateScriptFile(filePath, Rule_AttributeValidatorFileTemplate, "MyAttributeType");
            }
        }

        public static void CreateStandardRootObjectValidator(string saveFilePanelFolderPath)
        {
            var filePath = EditorUtility.SaveFilePanelInProject("Create Root Object Validator Script", "MyRootObjectValidator.cs", "cs", "Choose a file path to create a root object validator script file at.", saveFilePanelFolderPath);

            if (!string.IsNullOrEmpty(filePath))
            {
                CreateTemplateScriptFile(filePath, Standard_RootObjectValidatorFileTemplate, "MyUnityObjectType");
            }
        }

        [MenuItem("Assets/Odin Validator/Create Rule/Root Object Validator")]
        private static void CreateRuleRootObjectValidator_MenuItem()
        {
            if (!AssetDatabase.Contains(Selection.activeObject)) return;
            var selectedFolder = Path.GetDirectoryName(AssetDatabase.GetAssetPath(Selection.activeObject));
            CreateRuleRootObjectValidator(selectedFolder);
        }

        [MenuItem("Assets/Odin Validator/Create Rule/Attribute Validator")]
        private static void CreateRuleAttributeValidator_MenuItem()
        {
            if (!AssetDatabase.Contains(Selection.activeObject)) return;
            var selectedFolder = Path.GetDirectoryName(AssetDatabase.GetAssetPath(Selection.activeObject));
            CreateRuleAttributeValidator(selectedFolder);
        }

        [MenuItem("Assets/Odin Validator/Create Rule/Value Validator")]
        private static void CreateRuleValueValidator_MenuItem()
        {
            if (!AssetDatabase.Contains(Selection.activeObject)) return;
            var selectedFolder = Path.GetDirectoryName(AssetDatabase.GetAssetPath(Selection.activeObject));
            CreateRuleValueValidator(selectedFolder);
        }

        [MenuItem("Assets/Odin Validator/Create Validator/Root Object Validator")]
        private static void CreateStandardRootObjectValidator_MenuItem()
        {
            if (!AssetDatabase.Contains(Selection.activeObject)) return;
            var selectedFolder = Path.GetDirectoryName(AssetDatabase.GetAssetPath(Selection.activeObject));
            CreateStandardRootObjectValidator(selectedFolder);
        }

        [MenuItem("Assets/Odin Validator/Create Validator/Attribute Validator")]
        private static void CreateStandardAttributeValidator_MenuItem()
        {
            if (!AssetDatabase.Contains(Selection.activeObject)) return;
            var selectedFolder = Path.GetDirectoryName(AssetDatabase.GetAssetPath(Selection.activeObject));
            CreateStandardAttributeValidator(selectedFolder);
        }

        [MenuItem("Assets/Odin Validator/Create Validator/Value Validator")]
        private static void CreateStandardValueValidator_MenuItem()
        {
            if (!AssetDatabase.Contains(Selection.activeObject)) return;
            var selectedFolder = Path.GetDirectoryName(AssetDatabase.GetAssetPath(Selection.activeObject));
            CreateStandardValueValidator(selectedFolder);
        }
    }
}
#endif