//-----------------------------------------------------------------------
// <copyright file="ValidationSessionEditor.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    internal class ResultItemMetaDataValueAttribute : System.Attribute
    {
    }
}
#endif