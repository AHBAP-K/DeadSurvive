//-----------------------------------------------------------------------
// <copyright file="FlagEnumColumnDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor;
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using UnityEditor;
    using UnityEngine;

    internal class FlagEnumColumnDrawer<TEnum>
    {
        private EditorPrefFloat[] columnSizes;
        private ResizableColumn[] resizableColumns;
        private TEnum dynamicWidthColumn;
        private Vector2[] columnPositions;

        public (TEnum, SortDirection) SortedColumn;
        public Func<TEnum, (TEnum, SortDirection)> SortColumn;
        private string name;
        public EditorPrefEnum<TEnum> Columns;

        public enum SortDirection
        {
            Ascending,
            Descending
        }

        public FlagEnumColumnDrawer(string name, TEnum @default, TEnum dynamicWidthColumn)
        {
            this.name = name;
            this.Columns = new EditorPrefEnum<TEnum>("ODIN_VALIDATOR_" + name, @default);
            this.columnSizes = new EditorPrefFloat[EnumTypeUtilities<TEnum>.AllEnumMemberInfos.Length];
            this.columnPositions = new Vector2[EnumTypeUtilities<TEnum>.AllEnumMemberInfos.Length];
            this.resizableColumns = new ResizableColumn[this.columnSizes.Length];
            this.dynamicWidthColumn = dynamicWidthColumn;

            this.InitializeColumns();
        }

        private void InitializeColumns()
        {
            var enumNames = Enum.GetNames(typeof(TEnum));
            for (int i = 0; i < this.columnSizes.Length; i++)
            {
                this.columnSizes[i] = new EditorPrefFloat("ODIN_VALIDATOR_" + name + enumNames[i], 100);
            }

            var enabledColumns = EnumTypeUtilities<TEnum>.DecomposeEnumFlagValues(this.Columns);
            this.resizableColumns = new ResizableColumn[enabledColumns.Length];
            for (int i = 0; i < this.resizableColumns.Length; i++)
            {
                var column = enabledColumns[i];
                var index = EnumTypeUtilities<TEnum>.GetIndexOfEnumValue(column);
                var width = this.columnSizes[index].Value;

                if (EqualityComparer<TEnum>.Default.Equals(column, this.dynamicWidthColumn))
                {
                    this.resizableColumns[i] = ResizableColumn.DynamicColumn(width, 60);
                }
                else
                {
                    this.resizableColumns[i] = ResizableColumn.FlexibleColumn(width, 30);
                }
            }
        }

        public void BeginDrawColumns(Rect columnHeaderRect)
        {
            // Update 
            {
                var columnFlags = EnumTypeUtilities<TEnum>.DecomposeEnumFlagValues(this.Columns);

                for (int i = 0; i < columnFlags.Length; i++)
                {
                    var column = this.resizableColumns[i];
                    this.columnSizes[EnumTypeUtilities<TEnum>.GetIndexOfEnumValue(columnFlags[i])].Value = column.ColWidth;
                }
            }

            GUITableUtilities.ResizeColumns(columnHeaderRect, this.resizableColumns);

            // Draw bar
            {
                var columns = EnumTypeUtilities<TEnum>.DecomposeEnumFlagValues(this.Columns);
                var rect = columnHeaderRect;

                for (int i = 0; i < columns.Length; i++)
                {
                    var colEnumVal = columns[i];
                    var colName = colEnumVal.ToString();
                    var col = this.resizableColumns[i];

                    rect.width = col.ColWidth;

                    var j = EnumTypeUtilities<TEnum>.GetIndexOfEnumValue(colEnumVal);
                    this.columnPositions[j].x = rect.x;
                    this.columnPositions[j].y = rect.width;

                    if (GUI.Button((Rect)rect, GUIContent.none, GUIStyle.none))
                    {
                        if (Event.current.button == 0)
                        {
                            if (this.SortColumn != null)
                            {
                                this.SortedColumn = this.SortColumn(colEnumVal);
                            }
                        }
                        else
                        {
                            var selector = new EnumSelector<TEnum>();
                            selector.SelectionTree.Config.DrawSearchToolbar = false;
                            selector.SetSelection(this.Columns);
                            selector.SelectionChanged += (x) =>
                            {
                                this.Columns.Value = x.FirstOrDefault();
                                this.InitializeColumns();
                            };
                            selector.ShowInPopup();
                        }
                    }

                    if (EqualityComparer<TEnum>.Default.Equals(this.SortedColumn.Item1, colEnumVal))
                    {
                        GUI.Label((Rect)rect, (this.SortedColumn.Item2 == SortDirection.Ascending ? "▲ " : "▼ ") + colName, SirenixGUIStyles.LabelCentered);
                    }
                    else
                    {
                        GUI.Label((Rect)rect, colName, SirenixGUIStyles.LabelCentered);
                    }

                    rect.x += rect.width;
                }

                EditorGUI.DrawRect(columnHeaderRect.AlignBottom(1), ValidatorGui.BorderColor);
                GUITableUtilities.DrawColumnHeaderSeperators(columnHeaderRect, this.resizableColumns, ValidatorGui.BorderColor);
            }
        }

        public Rect GetColumnRect(Rect rect, TEnum column)
        {
            var index = EnumTypeUtilities<TEnum>.GetIndexOfEnumValue(column);
            rect.x = this.columnPositions[index].x;
            rect.width = this.columnPositions[index].y;
            return rect;
        }

        public void EndDrawColumns(Rect resultRect)
        {
            GUITableUtilities.DrawColumnHeaderSeperators(resultRect, this.resizableColumns, ValidatorGui.BorderColor);
        }
    }
}
#endif