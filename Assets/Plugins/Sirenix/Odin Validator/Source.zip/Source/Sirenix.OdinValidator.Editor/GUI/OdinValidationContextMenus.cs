//-----------------------------------------------------------------------
// <copyright file="OdinValidationContextMenus.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using System.Collections.Generic;
    using System.IO;
    using UnityEditor;

    internal class OdinValidationContextMenus
    {
        [MenuItem("Assets/Odin Validator/Validate this")]
        private static void ValidateThis()
        {
            var objs = Selection.objects;
            var include = new List<ValidationItem>();

            foreach (var obj in objs)
            {
                var path = AssetDatabase.GetAssetPath(obj);

                include.Add(ValidationItem.FromAssetPath(path));
                if (File.Exists(path) && obj is SceneAsset)
                {
                    include.Add(ValidationItem.FromScenePath(path, false));
                }
                else
                {
                    include.Add(ValidationItem.FromSceneFolderPath(path, false));
                }
            }

            OdinValidatorWindow.OpenWindow("Custom session", include, null);
        }
    }
}
#endif