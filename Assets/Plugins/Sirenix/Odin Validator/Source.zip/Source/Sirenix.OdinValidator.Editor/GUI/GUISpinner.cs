//-----------------------------------------------------------------------
// <copyright file="GUISpinner.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;

    internal struct GUISpinner
    {
        private static float Accelleration = 4.5f;
        private float dt;
        private float prevT;
        private float spinDir;

        private float warning;
        private float error;
        private float valid;
        private float odin;
        private float spin;
        private bool mouseOver;
        private double mouseOverTime;
        private bool skipDeltaHack;

        public void DrawSceneWidgetSpinner(Rect rect, IconType type, bool spin, bool isMouseOver, float t)
        {
            if (Event.current.type != EventType.Layout)
            {
                if (isMouseOver != mouseOver)
                {
                    mouseOver = isMouseOver;
                    mouseOverTime = EditorApplication.timeSinceStartup;
                    skipDeltaHack = true;
                }

                if (mouseOverTime + 1 > EditorApplication.timeSinceStartup)
                {
                    GUIHelper.RequestRepaint();
                }
            }

            if (this.spin > 0 || spin)
                GUIHelper.RequestRepaint();

            if (Event.current.type == EventType.Repaint)
            {
                float newT = (float)Time.realtimeSinceStartup;
                this.dt = newT - this.prevT;
                this.prevT = newT;

                var prevSpiner = this;

                if (this.spin < 0.5 && spin)
                    this.spinDir = -1;

                if (this.spin > 0.5 && !spin)
                    this.spinDir = 1;

                var speed = dt * Accelleration;

                if (skipDeltaHack)
                {
                    speed = 0;
                    skipDeltaHack = false;
                }

                this.warning = LerpSnap(this.warning, type == IconType.Warning, speed);
                this.error = LerpSnap(this.error, type == IconType.Error, speed);
                this.valid = LerpSnap(this.valid, type == IconType.Valid, speed);
                this.spin = LerpSnap(this.spin, spin, speed);
                this.odin = LerpSnap(this.odin, this.mouseOver, this.mouseOver ? speed * 4 : speed * 3);

                var mat = ValidatorGui.SpinnerMat;
                var color = (ValidatorGui.DarkSkinRedErrorColor * error + ValidatorGui.GreenValidColor * valid + ValidatorGui.DarkSkinYellowWarningColor * warning);

                if (this.spin > 0.01)
                {
                    var spinCol = Color.Lerp(Color.white, ValidatorGui.DarkSkinYellowWarningColor, this.warning);
                    spinCol = Color.Lerp(spinCol, ValidatorGui.DarkSkinRedErrorColor, this.error);
                    color = Color.Lerp(color, spinCol, this.spin);
                }

                // Note that we are using global shader properties because changing
                // shader properties of a material instance, causes the scene view to repaint.
                Shader.SetGlobalVector("_SirenixOdinSpinner_Shape", new Vector4(odin, valid, warning, error));
                Shader.SetGlobalFloat("_SirenixOdinSpinner_Spin", this.spin);
                Shader.SetGlobalFloat("_SirenixOdinSpinner_SpinDir", this.spinDir);
                Shader.SetGlobalColor("_SirenixOdinSpinner_Color", color);
                Shader.SetGlobalFloat("_SirenixOdinSpinner_T", t);
                Shader.SetGlobalFloat("_SirenixOdinSpinner_SpinTime", (float)EditorApplication.timeSinceStartup);

                if (this.spin != prevSpiner.spin ||
                   this.spinDir != prevSpiner.spinDir ||
                   this.warning != prevSpiner.warning ||
                   this.error != prevSpiner.error ||
                   this.valid != prevSpiner.valid ||
                   this.odin != prevSpiner.odin)
                {
                    GUIHelper.RequestRepaint();
                }

                Graphics.DrawTexture(rect, Texture2D.whiteTexture, mat);
            }
        }

        public void DrawOdinSpinner(Rect rect, bool spin, bool isMouseOver, bool enabled)
        {
            if (Event.current.type != EventType.Layout)
            {
                if (isMouseOver != mouseOver)
                {
                    mouseOver = isMouseOver;
                    mouseOverTime = EditorApplication.timeSinceStartup;
                    skipDeltaHack = true;
                }

                if (mouseOverTime + 1 > EditorApplication.timeSinceStartup)
                    GUIHelper.RequestRepaint();
            }

            if (this.spin > 0 || spin)
                GUIHelper.RequestRepaint();

            if (Event.current.type == EventType.Repaint)
            {
                float newT = (float)Time.realtimeSinceStartup;
                this.dt = newT - this.prevT;
                this.prevT = newT;

                var prevSpiner = this;
                var speed = dt * Accelleration;

                if (skipDeltaHack)
                {
                    speed = 0;
                    skipDeltaHack = false;
                }

                this.warning = 0;
                this.error = 0;
                this.valid = 0;
                this.spin = LerpSnap(this.spin, spin && !isMouseOver, speed);
                this.odin = 1 - this.spin;

                var mat = ValidatorGui.SpinnerMat;
                var color = ValidatorGui.BtnMouseOverContentColor;

                if (!enabled && !mouseOver)
                {
                    color = ValidatorGui.BtnContentColor;
                }

                // Note that we are using global shader properties because changing
                // shader properties of a material instance, causes the scene view to repaint.
                Shader.SetGlobalVector("_SirenixOdinSpinner_Shape", new Vector4(odin, valid, warning, error));
                Shader.SetGlobalFloat("_SirenixOdinSpinner_Spin", this.spin);
                Shader.SetGlobalFloat("_SirenixOdinSpinner_SpinDir", this.spinDir);
                Shader.SetGlobalColor("_SirenixOdinSpinner_Color", color);
                Shader.SetGlobalFloat("_SirenixOdinSpinner_SpinTime", (float)EditorApplication.timeSinceStartup);

                if (this.spin != prevSpiner.spin ||
                   this.spinDir != prevSpiner.spinDir ||
                   this.odin != prevSpiner.odin)
                {
                    GUIHelper.RequestRepaint();
                }

                //var prev = GL.sRGBWrite;
                //GL.sRGBWrite = true;
                Graphics.DrawTexture(rect, Texture2D.whiteTexture, mat);
                //GL.sRGBWrite = prev;
            }
        }


        static float LerpSnap(float a, bool goTowardsOne, float t)
        {
            var threshold = 0.05;
            if (a > (1 - threshold) && goTowardsOne)
                return 1;

            if (a < threshold && !goTowardsOne)
                return 0;

            return Mathf.Lerp(a, goTowardsOne ? 1 : 0, t);
        }

        public enum IconType
        {
            Valid,
            Error,
            Warning,
        }
    }
}
#endif