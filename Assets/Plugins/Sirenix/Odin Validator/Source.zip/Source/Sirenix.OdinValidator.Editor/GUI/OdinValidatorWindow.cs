//-----------------------------------------------------------------------
// <copyright file="OdinValidatorWindow.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using System;
    using System.Collections.Generic;
    using UnityEditor;
    using UnityEngine;

    public class OdinValidatorWindow : EditorWindow
    {
        [NonSerialized] private ValidationSessionEditor validationSessionEditor;
        [SerializeField] private bool disposeSessionOnDestroy;
        [SerializeField] private bool isGlobalValidationSession;
        [SerializeField] private List<ValidationItem> include;
        [SerializeField] private List<ValidationItem> exclude;

        private void OnEnable()
        {
            this.titleContent = new GUIContent("Odin Validator");
            this.wantsMouseMove = true;
            this.Init();
        }

        void OnGUI()
        {
            this.Init();

            if (this.validationSessionEditor == null)
            {
                GUILayout.Label("Validation session was lost.");
                return;
            }

            var area = this.position.ResetPosition();
            this.validationSessionEditor.OnGUI(area);

            if ((Event.current.button == 0 && Event.current.type == EventType.MouseDown) || (Event.current.type == EventType.MouseMove || Event.current.type == EventType.MouseDrag))
                GUIHelper.RequestRepaint();

            this.RepaintIfRequested();
        }

        private void Init()
        {
            if (this.validationSessionEditor == null)
            {
                if (this.isGlobalValidationSession)
                {
                    this.validationSessionEditor = new ValidationSessionEditor(this, ValidationSession.GlobalValidationSession);
                }
                else if (this.include != null && this.include.Count > 0)
                {
                    this.include = this.include ?? new List<ValidationItem>();
                    this.exclude = this.exclude ?? new List<ValidationItem>();

                    CreateSession(this.name, this.include, this.exclude);
                }
            }
        }

        [MenuItem("Tools/Odin Validator")]
        public static void Open()
        {
            OpenWindow(ValidationSession.GlobalValidationSession, false);
        }

        public static void OpenWindow(string name, List<ValidationItem> include, List<ValidationItem> exclude, bool startValidating = true)
        {
            var wnd = CreateInstance<OdinValidatorWindow>();
            var session = wnd.CreateSession(name, include, exclude);

            if (startValidating)
            {
                session.ValidateEverythingNow(false, true, true);
            }

            var pos = wnd.position;
            var size = pos.size;

            bool changed = false;

            if (size.x < 1200)
            {
                size.x = 1200;
                changed = true;
            }

            if (size.y < 600)
            {
                size.y = 600;
                changed = true;
            }

            if (changed)
            {
                pos.size = size;
                wnd.position = pos;
            }

            wnd.Show();
        }

        private ValidationSession CreateSession(string name, List<ValidationItem> include, List<ValidationItem> exclude)
        {
            var configData = new SessionConfig.SerializableSessionConfigData(include, exclude);
            configData.OnSaveChanges += () =>
            {
                this.include = (List<ValidationItem>)configData.Include;
                this.exclude = (List<ValidationItem>)configData.Exclude;
                EditorUtility.SetDirty(this);
            };
            var sessionConfig = new SessionConfig(configData);
            var session = new ValidationSession(name, sessionConfig);

            this.validationSessionEditor = new ValidationSessionEditor(this, session);
            this.isGlobalValidationSession = false;
            this.include = include;
            this.exclude = exclude;
            this.disposeSessionOnDestroy = true;
            this.name = name;
            this.titleContent = new GUIContent(name);

            session.StartSession();

            return session;
        }

        public static ValidationSessionEditor OpenWindow(ValidationSession session, bool disposeSessionOnWindowDestroy)
        {
            var wnd = CreateInstance<OdinValidatorWindow>();
            wnd.validationSessionEditor = new ValidationSessionEditor(wnd, session);
            wnd.disposeSessionOnDestroy = disposeSessionOnWindowDestroy;
            wnd.isGlobalValidationSession = ValidationSession.GlobalValidationSession == session;
            wnd.Show();
            return wnd.validationSessionEditor;
        }

        void OnDisable()
        {
            OnDestroy();
        }

        void OnDestroy()
        {
            if (this.validationSessionEditor != null)
            {
                this.validationSessionEditor.Dispose();
                if (this.disposeSessionOnDestroy)
                {
                    this.validationSessionEditor.ValidationSession.Dispose();
                }
                this.validationSessionEditor = null;
            }
        }
    }
}
#endif