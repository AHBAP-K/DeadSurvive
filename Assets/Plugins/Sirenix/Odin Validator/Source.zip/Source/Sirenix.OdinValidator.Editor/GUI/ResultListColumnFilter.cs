//-----------------------------------------------------------------------
// <copyright file="ResultListColumnFilter.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.Utilities;
    using System;
    using UnityEngine;

    [Flags]
    public enum ResultListColumnFilter
    {
        [HideInInspector]
        None = 0,
        [HideInInspector]
        Message = 1 << 1,
        Path = 1 << 2,
        Location = 1 << 3,
        Object = 1 << 4,
        Validator = 1 << 5,
    }
}
#endif