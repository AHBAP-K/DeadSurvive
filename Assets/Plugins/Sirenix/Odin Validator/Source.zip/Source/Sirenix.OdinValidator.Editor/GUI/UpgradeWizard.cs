//-----------------------------------------------------------------------
// <copyright file="UpgradeWizard.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
using Sirenix.Serialization;
using Sirenix.Utilities.Editor.Expressions;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace Sirenix.OdinValidator.Editor
{
    public class UpgradeWizard
    {
        private static readonly Type Old_OdinValidationConfig_Type = TwoWaySerializationBinder.Default.BindToType("Sirenix.OdinValidator.Editor.OdinValidationConfig");

        public static bool HasOldValidator = Old_OdinValidationConfig_Type != null;

        private static Expressionator9000 API = new Expressionator9000(null);

#if SIRENIX_INTERNAL
        [MenuItem("Upgrader/Test")]
        public static void UpgradeTest()
        {
            if (!HasOldValidator) Debug.Log("No old validator!");

            foreach (var hook in API.ForEachExpr("OdinValidationConfig.Instance.Hooks"))
            {
                if (hook.Expr<bool>("Enabled"))
                {
                    var hookInst = hook["Hook"];
                    Debug.Log("Legacy Hook " + hookInst.GetType().Name + " is enabled");
                }
            }
        }
#endif

        //public bool IsDefaultAllAssetsProfile(Expressionator9000 profile)
        //{
        //    if (profile == null) return false;
        //    if (profile.Run<bool>("this is AssetValidationProfileAsset"))
        //    {
        //        profile = Expr(profile["Profile"]);
        //    }

        //    if (!profile.Run<bool>("this is AssetValidationProfile")) return false;
        //    if (profile["Name"] as string != "All Assets") return false;

        //    var assetRefs = profile["AssetReferences"] as Array;
        //    if (assetRefs != null && assetRefs.Length > 0) return false;

        //    var excludeAssets = profile["ExcludeAssetPaths"] as Array;
        //    if (excludeAssets != null && excludeAssets.Length > 0) return false;

        //    var excludeRefs = profile["ExcludeAssetReferences"] as Array;
        //    if (excludeRefs != null && excludeRefs.Length > 0) return false;

        //    var assetPaths = profile["AssetPaths"] as Array;
        //    if (assetPaths == null || assetPaths.Length != 1 || assetPaths.GetValue(0) as string != "Assets") return false;

        //    return true;
        //}

        //public bool IsDefaultAllScenesProfile(Expressionator9000 profile)
        //{
        //    if (profile == null) return false;
        //    if (profile.Run<bool>("this is SceneValidationProfileAsset"))
        //    {
        //        profile = Expr(profile["Profile"]);
        //    }

        //    if (!profile.Run<bool>("this is SceneValidationProfile")) return false;
        //    if (profile["Name"] as string != "All Scenes") return false;

        //    if (profile.Run<bool>("IncludeScenesFromBuildOptions || IncludeOpenScenes || IncludeAssetDependencies")) return false;

        //    var scenePaths = profile["ScenePaths"] as Array;
        //    if (scenePaths == null || scenePaths.Length != 1 || scenePaths.GetValue(0) as string != "Assets") return false;

        //    var excludeScenePaths = profile["ExcludeScenePaths"] as Array;
        //    if (excludeScenePaths != null && excludeScenePaths.Length > 0) return false;

        //    return true;
        //}

        //public Expressionator9000 GetValidationProfile(string name)
        //{
        //    foreach (var profile in API.ForEachExpr("OdinValidationConfig.Instance.MainValidationProfiles"))
        //    {
        //        if (profile["Name"] as string == name)
        //        {
        //            return profile;
        //        }
        //    }

        //    return null;
        //}

        /*
            var allAssets = this.GetOrCreateValidationProfileSubAsset<AssetValidationProfileAsset, AssetValidationProfile>(new AssetValidationProfile()
            {
                Name = "All Assets",
                Description = "Scans all prefabs and scriptable objects in the project",
                AssetPaths = new string[] { "Assets" },
            }, overridePreExistingProfileAssets);

            var allScenes = this.GetOrCreateValidationProfileSubAsset<SceneValidationProfileAsset, SceneValidationProfile>(new SceneValidationProfile()
            {
                Name = "All Scenes",
                Description = "Scans all scenes in the project",
                ScenePaths = new string[] { "Assets" }
            }, overridePreExistingProfileAssets);

            var entireProject = this.GetOrCreateValidationProfileSubAsset<ValidationCollectionProfileAsset, ValidationCollectionProfile>(new ValidationCollectionProfile()
            {
                Name = "Entire Project",
                Description = "Scans all prefabs, scriptable objects and scenes in the project",
                Profiles = new ValidationProfileAsset[] { allAssets, allScenes }
            }, overridePreExistingProfileAssets);

            var openScenes = this.GetOrCreateValidationProfileSubAsset<SceneValidationProfileAsset, SceneValidationProfile>(new SceneValidationProfile()
            {
                Name = "Open Scenes",
                Description = "Scans all open scenes, without going through scene asset dependencies.",
                IncludeOpenScenes = true,
            }, overridePreExistingProfileAssets);

            var scenesFromBuildOptions = this.GetOrCreateValidationProfileSubAsset<SceneValidationProfileAsset, SceneValidationProfile>(new SceneValidationProfile()
            {
                Name = "Scenes from Build Options",
                Description = "Scans all scenes from build options, including scene asset dependencies.",
                IncludeScenesFromBuildOptions = true,
                IncludeAssetDependencies = true,
            }, overridePreExistingProfileAssets);

            var openScenesAndAllAssets = this.GetOrCreateValidationProfileSubAsset<ValidationCollectionProfileAsset, ValidationCollectionProfile>(new ValidationCollectionProfile()
            {
                Name = "Open Scenes, All Assets",
                Description = "Scans all prefabs, scriptable objects and scenes in the project",
                Profiles = new ValidationProfileAsset[] { openScenes, allAssets }
            }, overridePreExistingProfileAssets);

            var onPlayHook = new AutomatedValidationHook(new OnPlayValidationHook())
            {
                Enabled = false,
                Validations = new List<AutomatedValidation>()
                {
                    new AutomatedValidation()
                    {
                        Actions = AutomatedValidation.Action.OpenValidatorIfError | AutomatedValidation.Action.OpenValidatorIfWarning,
                        ProfilesToRun = new List<IValidationProfile>() { openScenes }
                    }
                }
            };

            var onBuild = new AutomatedValidationHook(new OnBuildValidationHook())
            {
                Enabled = false,
                Validations = new List<AutomatedValidation>()
                {
                    new AutomatedValidation()
                    {
                        Actions = AutomatedValidation.Action.OpenValidatorIfError | AutomatedValidation.Action.OpenValidatorIfWarning,
                        ProfilesToRun = new List<IValidationProfile>() { scenesFromBuildOptions }
                    }
                }
            };

            var onStartup = new AutomatedValidationHook(new OnProjectStartupValidationHook())
            {
                Enabled = false,
                Validations = new List<AutomatedValidation>()
                {
                    new AutomatedValidation()
                    {
                        Actions = AutomatedValidation.Action.OpenValidatorIfError | AutomatedValidation.Action.OpenValidatorIfWarning,
                        ProfilesToRun = new List<IValidationProfile>() { entireProject }
                    }
                }
            };

            this.MainValidationProfiles = new List<IValidationProfile>()
            {
                openScenesAndAllAssets,
                entireProject,
                allAssets,
                allScenes,
                openScenes,
                scenesFromBuildOptions,
            };

            this.Hooks = new List<AutomatedValidationHook>()
            {
                onPlayHook,
                onBuild,
                onStartup
            };
         */

        public static Expressionator9000 Expr(object instance)
        {
            return new Expressionator9000(instance);
        }
    }

    internal static class UpgradeWizardExtensions
    {
    }

    public class Expressionator9000
    {
        public Expressionator9000(object value)
        {
            this.value = value;
        }

        private object value;
        //public ExpressionState State;

        public object Value
        {
            get { return this.value ?? this; }
            set { this.value = value; }
        }

        public Type ValueType
        {
            get { return this.Value.GetType(); }
        }

        public object this[string expression]
        {
            get
            {
                return this.Expr(expression);
            }
        }

        public object Expr(string expression)
        {
            return this.Expr<object>(expression);
        }

        public T Expr<T>(string expression)
        {
            var del = ExpressionUtility.ParseExpression(expression, new EmitContext()
            {
                IsStatic = false,
                //ReturnType = typeof(T),
                Type = this.ValueType,
                //Parameters = new Type[] { typeof(ExpressionState) },
                //ParameterNames = new string[] { "state" },
            }, out string error);

            if (error != null)
            {
                throw new Exception(error);
            }

            return (T)del.DynamicInvoke(this.Value/*, this.State*/);
        }

        public IEnumerable<Expressionator9000> ForEachExpr(string expression)
        {
            var enumerable = this.Expr<IEnumerable>(expression);

            if (enumerable != null)
            {
                foreach (var result in enumerable)
                {
                    yield return new Expressionator9000(result);
                }
            }
        }

        //public class ExpressionState
        //{
        //    public Dictionary<string, object> Values = new Dictionary<string, object>();

        //    public object this[string name]
        //    {
        //        get
        //        {
        //            if (this.Values.TryGetValue(name, out var val))
        //            {
        //                return val;
        //            }
        //            throw new ArgumentException($"No state value '{name}' exists.");
        //        }

        //        set
        //        {
        //            this.Values[name] = value;
        //        }
        //    }
        //}
    }
}
#endif