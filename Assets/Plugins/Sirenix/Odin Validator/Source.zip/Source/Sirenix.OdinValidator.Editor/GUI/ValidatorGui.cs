//-----------------------------------------------------------------------
// <copyright file="cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector;
    using Sirenix.OdinInspector.Editor;
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using System;
    using UnityEditor;
    using UnityEngine;

    internal static class ValidatorGui
    {
        public const int LineHeight = 21;
        private static Vector2 tmpSlideRectValue;
        private static GUIStyle whiteLabelVerticalCentered;
        private static GUIStyle blackLabelVerticalCentered;
        private static GUIStyle labelVerticalCentered;
        private static GUIStyle whiteLabelVertical;
        private static GUIStyle labelVertical;
        private static GUIStyle labelLowerCenterBold;
        private static Material drawColorMat;
        private static Material spinnerMat;

        public static Color ToolbarBgColor = IsProSkin ? new Color(60 / 255f, 60 / 255f, 60 / 255f, 1) : Color.Lerp(EditorWindowBgColor, Color.white, 0.15f);
        public static int LeftMenuLineHeight = 21;
        public static int IconButtonWidth = 30;
        public static float ContentPadding = 5;
        public static Color BtnActiveBgColor = IsProSkin ? new Color(70 / 255f, 96 / 255f, 124 / 255f, 1) : new Color(58 / 255f, 114 / 255f, 176 / 255f, 1);
        public static Color BtnInActiveBgColor => IsProSkin ? SirenixGUIStyles.DefaultSelectedInactiveMenuTreeColorDarkSkin : SirenixGUIStyles.DefaultSelectedInactiveMenuTreeColorLightSkin;
        public static Color Green = new Color((57 / 255f) * 1.4f, (181 / 255f) * 1.4f, (74 / 255f) * 1.4f, 1);
        public static Color DarkRed = new Color(0.717f, 0.233f, 0.238f, 1f);
        public static Color DarkSkinYellowWarningColor = new Color(1, 193 / 255f, 7 / 255f);
        public static Color GreenValidColor = new Color(0.2f, 193 / 255f, 7 / 255f);
        public static Color DarkSkinEditorWindowBgColor => new Color(0.22f, 0.22f, 0.22f, 1f);
        public static Color DarkSkinRedErrorColor = new Color(1, 83 / 255f, 74 / 255f);
        public static Color RedErrorColor = IsProSkin ? DarkSkinRedErrorColor : new Color(177 / 255f, 12 / 255f, 12 / 255f, 1);
        public static Color YellowWarningColor = IsProSkin ? DarkSkinYellowWarningColor : new Color(201 / 255f, 151 / 255f, 0, 1);
        public static Color EditorWindowBgColor => IsProSkin ? DarkSkinEditorWindowBgColor : new Color(0.76f, 0.76f, 0.76f, 1f); /*+ new Color(0.05f, 0.05f, 0.05f, 0)*/
        public static Color BorderColor = IsProSkin ? new Color(0.11f, 0.11f, 0.11f, 0.8f) : new Color(0, 0, 0, 0.184f);
        public static Color BtnContentColor => IsProSkin ? new Color(176 / 255f, 176 / 255f, 176 / 255f, 1) : GrayIconColor;
        public static Color BtnMouseOverContentColor => IsProSkin ? Color.white : Color.black;
        public static Color BtnMouseOverBgColor => IsProSkin ? Color.Lerp(EditorWindowBgColor, Color.white, 0.1f) : Color.Lerp(EditorWindowBgColor, Color.white, 0.15f);
        public static Color HighlightedBgColor => IsProSkin ? Color.Lerp(EditorWindowBgColor, Color.white, 0.15f) : new Color(239 / 255f, 239 / 255f, 239 / 255f, 1);
        public static Color GrayIconColor => IsProSkin ? new Color(196 / 255f, 196 / 255f, 196 / 255f, 1) : new Color(85 / 255f, 85 / 255f, 85 / 255f, 1);

        public static GUIStyle WhiteLabelVerticalCentered => whiteLabelVerticalCentered ?? (whiteLabelVerticalCentered = new GUIStyle(SirenixGUIStyles.WhiteLabel)
        {
            alignment = TextAnchor.MiddleLeft,
            hover = SirenixGUIStyles.WhiteLabel.normal,
            onActive = SirenixGUIStyles.WhiteLabel.normal,
            onHover = SirenixGUIStyles.WhiteLabel.normal,
            onNormal = SirenixGUIStyles.WhiteLabel.normal,
            onFocused = SirenixGUIStyles.WhiteLabel.normal,
            focused = SirenixGUIStyles.WhiteLabel.normal,
        });

        public static GUIStyle DarkLabelVerticalCentered => blackLabelVerticalCentered ?? (blackLabelVerticalCentered = new GUIStyle(SirenixGUIStyles.BlackLabel)
        {
            alignment = TextAnchor.MiddleLeft,
            hover = SirenixGUIStyles.BlackLabel.normal,
            onActive = SirenixGUIStyles.BlackLabel.normal,
            onHover = SirenixGUIStyles.BlackLabel.normal,
            onNormal = SirenixGUIStyles.BlackLabel.normal,
            onFocused = SirenixGUIStyles.BlackLabel.normal,
            focused = SirenixGUIStyles.BlackLabel.normal,
        });

        public static GUIStyle LabelVerticalCentered => labelVerticalCentered ?? (labelVerticalCentered = new GUIStyle(SirenixGUIStyles.Label)
        {
            alignment = TextAnchor.MiddleLeft,
            hover = SirenixGUIStyles.Label.normal,
            onActive = SirenixGUIStyles.Label.normal,
            onHover = SirenixGUIStyles.Label.normal,
            onNormal = SirenixGUIStyles.Label.normal,
            onFocused = SirenixGUIStyles.Label.normal,
            focused = SirenixGUIStyles.Label.normal,
        });

        public static GUIStyle WhiteLabelVertical => whiteLabelVertical ?? (whiteLabelVertical = new GUIStyle(SirenixGUIStyles.WhiteLabel)
        {
            alignment = TextAnchor.UpperLeft,
            hover = SirenixGUIStyles.WhiteLabel.normal,
            onActive = SirenixGUIStyles.WhiteLabel.normal,
            onHover = SirenixGUIStyles.WhiteLabel.normal,
            onNormal = SirenixGUIStyles.WhiteLabel.normal,
            onFocused = SirenixGUIStyles.WhiteLabel.normal,
            focused = SirenixGUIStyles.WhiteLabel.normal,
        });

        public static GUIStyle LabelVertical => labelVertical ?? (labelVertical = new GUIStyle(SirenixGUIStyles.Label)
        {
            alignment = TextAnchor.UpperLeft,
            hover = SirenixGUIStyles.Label.normal,
            onActive = SirenixGUIStyles.Label.normal,
            onHover = SirenixGUIStyles.Label.normal,
            onNormal = SirenixGUIStyles.Label.normal,
            onFocused = SirenixGUIStyles.Label.normal,
            focused = SirenixGUIStyles.Label.normal,
        });

        public static GUIStyle LabelLowerCenterBold => labelLowerCenterBold ?? (labelLowerCenterBold = new GUIStyle(SirenixGUIStyles.BoldLabel)
        {
            alignment = TextAnchor.LowerCenter,
            hover = SirenixGUIStyles.BoldLabel.normal,
            onActive = SirenixGUIStyles.BoldLabel.normal,
            onHover = SirenixGUIStyles.BoldLabel.normal,
            onNormal = SirenixGUIStyles.BoldLabel.normal,
            onFocused = SirenixGUIStyles.BoldLabel.normal,
            focused = SirenixGUIStyles.BoldLabel.normal,
        });

        public static GUIStyle ActiveLabelVerticalCentered => IsProSkin ? WhiteLabelVerticalCentered : DarkLabelVerticalCentered;

        public static Material SpinnerMat
        {
            get
            {
                if (spinnerMat == null)
                {
                    const string key = "odin_validator_spinnerMat3";
                    int matInstanceId = SessionState.GetInt(key, 0); // survive assembly reloads.
                    if (matInstanceId != 0)
                    {
#if !SIRENIX_INTERNAL
                        spinnerMat = EditorUtility.InstanceIDToObject(matInstanceId) as Material;
#endif
                    }

                    if (spinnerMat == null)
                    {
                        var shader = Shader.Find("Hidden/Sirenix/SpinningShader");
                        spinnerMat = new Material(shader);
                        SessionState.SetInt(key, spinnerMat.GetInstanceID());
                    }
                }

                return spinnerMat;
            }
        }

        public static bool IsProSkin => EditorGUIUtility.isProSkin;

        private static Texture2D prefabIcon;
        private static Texture sceneAssetIcon;

        public static Texture PrefabIcon
        {
            get
            {
                if (!prefabIcon)
                {
                    prefabIcon = EditorGUIUtility.FindTexture("Prefab Icon");
                }
                return prefabIcon;
            }
        }

        public static Texture SceneAssetIcon
        {
            get
            {
                if (!sceneAssetIcon)
                {
                    sceneAssetIcon = EditorGUIUtility.IconContent("SceneAsset Icon").image;
                }

                return sceneAssetIcon;
            }
        }

        public static float VerticalMenuSlider(Rect rect, float width, float minWidth, float maxWidth, int direction = 1)
        {
            var slideRect = rect.Expand(5, 0);
            var newWidth = Mathf.Clamp(SlideRect(slideRect, new Vector2(width, 0), MouseCursor.ResizeHorizontal, direction).x, minWidth, maxWidth);
            EditorGUI.DrawRect(rect, BorderColor);
            return newWidth;
        }

        public static bool FoldoutToggle(bool toggled, ref bool val, string name)
        {
            toggled = Foldout(toggled, name, LineHeight);
            var toggleRect = GUILayoutUtility.GetLastRect().AlignLeft(LineHeight);
            toggleRect.x += ContentPadding;
            val = EditorGUI.ToggleLeft(toggleRect, GUIContent.none, val);

            return toggled;
        }

        public static bool Foldout(bool val, string name, int leftIndent)
        {
            var rect = GUILayoutUtility.GetRect(0, LineHeight);
            EditorGUI.DrawRect(rect, ToolbarBgColor);
            EditorGUI.DrawRect(rect.AlignBottom(1), BorderColor);
            EditorGUI.DrawRect(rect.AlignTop(1).AddY(-1), BorderColor);
            var foldoutRect = rect.AlignCenterY(EditorGUIUtility.singleLineHeight);
            val = SirenixEditorGUI.Foldout(foldoutRect.HorizontalPadding(ContentPadding).AddXMin(leftIndent), val, new GUIContent(name));
            return val;
        }

        public static bool Foldout(bool val, string name)
        {
            var rect = GUILayoutUtility.GetRect(0, LineHeight);
            EditorGUI.DrawRect(rect, ToolbarBgColor);
            EditorGUI.DrawRect(rect.AlignBottom(1), BorderColor);
            EditorGUI.DrawRect(rect.AlignTop(1).AddY(-1), BorderColor);
            var foldoutRect = rect.AlignCenterY(EditorGUIUtility.singleLineHeight);
            val = SirenixEditorGUI.Foldout(foldoutRect.HorizontalPadding(ContentPadding), val, new GUIContent(name));
            return val;
        }

        public static bool Foldout(Rect rect, bool val, string name, UnityEngine.Texture icon)
        {
            EditorGUI.DrawRect(rect, ToolbarBgColor);
            EditorGUI.DrawRect(rect.AlignBottom(1), BorderColor);
            EditorGUI.DrawRect(rect.AlignTop(1).AddY(-1), BorderColor);
            var foldoutRect = rect.AlignCenterY(EditorGUIUtility.singleLineHeight);
            var iconRect = foldoutRect.AlignLeft(16).AlignCenterY(16);
            iconRect.x += 20;
            val = SirenixEditorGUI.Foldout(foldoutRect.HorizontalPadding(ContentPadding), val, new GUIContent("      " + name));
            GUI.DrawTexture(iconRect, icon);
            return val;
        }

        public static Rect Header(string name, int height = LineHeight)
        {
            var rect = GUILayoutUtility.GetRect(0, height);
            EditorGUI.DrawRect(rect, ToolbarBgColor);
            EditorGUI.DrawRect(rect.AlignBottom(1), BorderColor);
            EditorGUI.DrawRect(rect.AlignTop(1).AddY(-1), BorderColor);
            GUI.Label(rect.AlignBottom(LineHeight).AlignCenterY(EditorGUIUtility.singleLineHeight).HorizontalPadding(ContentPadding), name);
            return rect;
        }

        public static void Header(Rect rect, string name, UnityEngine.Texture icon)
        {
            EditorGUI.DrawRect(rect, ToolbarBgColor);
            EditorGUI.DrawRect(rect.AlignBottom(1), BorderColor);
            EditorGUI.DrawRect(rect.AlignTop(1).AddY(-1), BorderColor);

            rect = rect.HorizontalPadding(ContentPadding);

            var headerRect = rect.AlignCenterY(EditorGUIUtility.singleLineHeight);
            var iconToggle = icon == null ? 0 : 1;
            var iconRect = headerRect.AlignLeft(16 * iconToggle).AlignCenterY(16 * iconToggle);

            GUI.Label(rect.AlignCenterY(EditorGUIUtility.singleLineHeight).AddXMin(iconRect.width), name);

            if (icon != null)
            {
                GUI.DrawTexture(iconRect, icon);
            }
        }

        public static float HorizontalMenuSlider(Rect rect, float height, float minHeight, float maxHeight)
        {
            var slideRect = rect.Expand(0, 5);
            var newHeight = Mathf.Clamp(SlideRect(slideRect, new Vector2(0, height), MouseCursor.ResizeVertical).y, minHeight, maxHeight);
            EditorGUI.DrawRect(rect, BorderColor);
            return newHeight;
        }

        public static void HandleKeyboardNavigation(ref int selectedIndex)
        {
            if (Event.current.type != EventType.KeyDown)
                return;


            var keycode = Event.current.keyCode;

            if (keycode == KeyCode.DownArrow)
            {
                selectedIndex++;
                Event.current.Use();
                GUIHelper.RequestRepaint();
            }
            else if (keycode == KeyCode.UpArrow)
            {
                selectedIndex--;
                Event.current.Use();
                GUIHelper.RequestRepaint();
            }
        }

        public static Vector2 SlideRect(Rect rect, Vector2 value, MouseCursor cursor = MouseCursor.SlideArrow, int direction = 1)
        {
            if (!GUI.enabled)
            {
                return value;
            }

            EditorGUIUtility.AddCursorRect(rect, cursor);
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            if (GUI.enabled && Event.current.type == EventType.MouseDown && Event.current.button == 0 && rect.Contains(Event.current.mousePosition))
            {
                GUIUtility.hotControl = controlID;
                Event.current.Use();
                tmpSlideRectValue = value;
            }
            else if (GUIUtility.hotControl == controlID)
            {
                if (Event.current.type == EventType.MouseDrag)
                {
                    Event.current.Use();
                    GUI.changed = true;
                    tmpSlideRectValue += new Vector2(Event.current.delta.x * direction, -Event.current.delta.y);
                    return tmpSlideRectValue;
                }

                if (Event.current.type == EventType.MouseUp)
                {
                    GUIUtility.hotControl = 0;
                    Event.current.Use();
                }
            }

            return value;
        }

        public static float SlideRect(Rect rect, float value, float minValue, float maxValue)
        {
            rect = SirenixEditorGUI.GetFeatureRichControl(rect, null, out int controlId, out bool hasKeyboardFocus);
            if (Event.current.type == EventType.Layout)
            {
                return value;
            }

            if (GUI.enabled)
            {
                bool flag = false;
                if ((Event.current.type == EventType.MouseDown && Event.current.button == 0 && rect.Contains(Event.current.mousePosition)) || (GUIUtility.hotControl == controlId && (Event.current.type == EventType.MouseMove || Event.current.type == EventType.MouseDrag)))
                {
                    GUIUtility.hotControl = controlId;
                    value = minValue + Mathf.Abs(maxValue - minValue) * (float)Mathf.Clamp01((Event.current.mousePosition.x - rect.xMin) / rect.width) * ((minValue <= maxValue) ? 1.0f : (-1.0f));
                    flag = true;
                }
                else if (hasKeyboardFocus && Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.RightArrow)
                {
                    value += (float)((minValue < maxValue) ? 1 : (-1));
                    flag = true;
                }
                else if (hasKeyboardFocus && Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.LeftArrow)
                {
                    value -= (float)((minValue < maxValue) ? 1 : (-1));
                    flag = true;
                }
                else if (GUIUtility.hotControl == controlId && Event.current.rawType == EventType.MouseUp)
                {
                    GUIUtility.hotControl = 0;
                }

                if (flag)
                {
                    GUI.changed = true;
                    float num = Math.Min(minValue, maxValue);
                    float num2 = Math.Max(minValue, maxValue);
                    value = ((value <= num) ? num : ((value >= num2) ? num2 : value));
                    GUIHelper.RequestRepaint();
                    Event.current.Use();
                }
            }

            return value;
        }

        public static string GetNiceValidatorTypeName(this Type t)
        {
            // Yeah I know, don't judge...

            var k = "";

            k = t.GetNiceName();
            var i = k.IndexOf('<');

            if (i >= 0)
            {
                k = k.Substring(0, i);
            }

            for (int j = 0; j < 2; j++)
            {
                if (k.FastEndsWith("Validator")) k = k.Substring(0, k.Length - "Validator".Length);
                if (k.FastEndsWith("Attribute")) k = k.Substring(0, k.Length - "Attribute".Length);
            }

            return ObjectNames.NicifyVariableName(k);
        }

        public static void DrawErrorIcon(Rect iconRect, bool hasErrors, bool useDarkSkin)
        {
            if (useDarkSkin)
                SdfIcons.DrawIcon(iconRect, SdfIconType.ExclamationOctagonFill, hasErrors ? DarkSkinRedErrorColor : GrayIconColor);
            else
                SdfIcons.DrawIcon(iconRect, SdfIconType.ExclamationOctagonFill, hasErrors ? RedErrorColor : GrayIconColor);
        }

        public static void DrawErrorIcon(Rect iconRect, Color bgColor, bool hasErrors, bool useDarkSkin)
        {
            if (useDarkSkin)
                SdfIcons.DrawIcon(iconRect, SdfIconType.ExclamationOctagonFill, hasErrors ? DarkSkinRedErrorColor : GrayIconColor, bgColor);
            else
                SdfIcons.DrawIcon(iconRect, SdfIconType.ExclamationOctagonFill, hasErrors ? RedErrorColor : GrayIconColor, bgColor);
        }

        public static void DrawWarningIcon(Rect iconRect, bool hasWarnings, bool useDarkSkin)
        {
            if (useDarkSkin)
                SdfIcons.DrawIcon(iconRect, SdfIconType.ExclamationTriangleFill, hasWarnings ? DarkSkinYellowWarningColor : GrayIconColor);
            else
                SdfIcons.DrawIcon(iconRect, SdfIconType.ExclamationTriangleFill, hasWarnings ? YellowWarningColor : GrayIconColor);
        }

        public static void DrawWarningIcon(Rect iconRect, Color bgColor, bool hasWarnings, bool useDarkSkin)
        {
            if (useDarkSkin)
                SdfIcons.DrawIcon(iconRect, SdfIconType.ExclamationTriangleFill, hasWarnings ? DarkSkinYellowWarningColor : GrayIconColor, bgColor);
            else
                SdfIcons.DrawIcon(iconRect, SdfIconType.ExclamationTriangleFill, hasWarnings ? YellowWarningColor : GrayIconColor, bgColor);
        }

        public static void DrawValidIcon(Rect iconRect, bool hasValids, bool useDarkSkin)
        {
            // Currenly no difference between dark-skin green and light skin green.
            SdfIcons.DrawIcon(iconRect, SdfIconType.CheckCircleFill, hasValids ? GreenValidColor : GrayIconColor);
        }

        public static void DrawValidIcon(Rect iconRect, Color bgColor, bool hasValids, bool useDarkSkin)
        {
            SdfIcons.DrawIcon(iconRect, SdfIconType.CheckCircleFill, hasValids ? GreenValidColor : GrayIconColor, bgColor);
        }

        public static void ProgressBar(Rect rect, float t, string text)
        {
            // Passing in an empty string can cause substring errors inside EditorGUI.ProgressBar
            if (text == "")
                text = null;

            EditorGUI.ProgressBar(rect, t, text);
        }

        //public static void ProgressBar(Rect rect, float t, string text, Color color)
        //{
        //    EditorGUI.ProgressBar(rect, t, text);
        //}

        public static bool IconButton(Rect rect, SdfIconType icon, string tooltip)
        {
            Color col;

            if (rect.Contains(Event.current.mousePosition))
            {
                col = BtnMouseOverContentColor;
            }
            else
            {
                col = BtnContentColor;
            }

            col.a *= GUI.enabled ? 1 : 0.2f;
            SdfIcons.DrawIcon(rect.VerticalPadding(3), icon, col, EditorWindowBgColor);

            return GUI.Button(rect, new GUIContent("", tooltip), GUIStyle.none);
        }

        public static bool ToolbarBtn(Rect rect, bool on, SdfIconType icon, string text, string tooltip)
        {
            if (GUI.Button(rect, new GUIContent("", tooltip), GUIStyle.none))
            {
                on = !on;
            }

            if (Event.current.type == EventType.Repaint)
            {
                var bgColor = ToolbarBgColor;
                var style = LabelVerticalCentered;
                var col = BtnContentColor;

                if (on)
                {
                    bgColor = HighlightedBgColor;
                    style = ActiveLabelVerticalCentered;
                    col = BtnMouseOverContentColor;
                }

                if (rect.Contains(Event.current.mousePosition))
                {
                    bgColor = BtnMouseOverBgColor;
                    col = BtnMouseOverContentColor;
                }

                EditorGUI.DrawRect(rect, bgColor);

                var iconSize = (int)(rect.height * 1.2f);
                var textSize = text == null ? 0 : style.CalcSize(new GUIContent(text)).x;
                var padding = rect.width - textSize - iconSize;
                if (padding > 0)
                {
                    rect.x += padding / 2;
                    rect.width -= padding;
                }
                rect = rect.VerticalPadding(3);

                SdfIcons.DrawIcon(rect.TakeFromLeft(iconSize), icon, col, bgColor);

                if (text != null)
                {
                    GUI.Label(rect, text, style);
                }
            }

            return on;
        }

        public static bool ToolbarToggle(Rect rect, bool on, SdfIconType iconOn, SdfIconType iconOff, string text, string tooltip)
        {
            if (GUI.Button(rect, new GUIContent("", tooltip), GUIStyle.none))
            {
                return true;
            }

            if (Event.current.type == EventType.Repaint)
            {
                var hover = rect.Contains(Event.current.mousePosition);
                var style = LabelVertical;
                var iconSize = (int)(rect.height);
                var bgColor = hover ? BtnMouseOverBgColor : ToolbarBgColor;

                EditorGUI.DrawRect(rect, bgColor);

                rect.TakeFromLeft(3);
                var icon1 = rect.TakeFromLeft(iconSize);
                rect.TakeFromLeft(3);
                var icon2 = rect.TakeFromLeft(iconSize);
                rect.TakeFromLeft(3);

                var col1 = hover ? BtnMouseOverContentColor : BtnContentColor;
                var col2 = hover ? BtnMouseOverContentColor : BtnContentColor;

                if (on)
                    col2.a *= 0.2f;
                else
                    col1.a *= 0.2f;

                GUI.Label(rect, text, LabelVerticalCentered);
                SdfIcons.DrawIcon(icon1.VerticalPadding(3), iconOn, col1, bgColor);
                SdfIcons.DrawIcon(icon2.VerticalPadding(3), iconOff, col2, bgColor);
            }

            return false;
        }

        //internal static void DrawTriangles()
        //{
        //    DrawTriangle(new Vector2(0, -1000), new Vector2(+1000, +1000), new Vector2(-1000, +1000), Color.green);
        //}

        static void Initialize()
        {
            if (drawColorMat == null)
            {
                drawColorMat = new Material(Shader.Find("UI/Default"));
            }
        }

        public static void DrawTriangles(Vector2[] sPoints, Color sColor)
        {
            if (Event.current.type.Equals(EventType.Repaint))
            {
                Initialize();
                GL.PushMatrix();
                drawColorMat.SetPass(0);
                GL.LoadPixelMatrix();
                GL.Begin(GL.TRIANGLES);
                GL.Color(sColor);
                foreach (Vector2 tV in sPoints)
                {
                    GL.Vertex3(tV.x, tV.y, 0);
                }
                GL.End();
                GL.PopMatrix();
            }
        }

        public static void DrawTriangle(Vector2 sA, Vector2 sB, Vector2 sC, Color sColor)
        {
            if (Event.current.type.Equals(EventType.Repaint))
            {
                Initialize();
                GL.PushMatrix();
                drawColorMat.SetPass(0);
                GL.LoadPixelMatrix();
                GL.Begin(GL.TRIANGLES);
                GL.Color(sColor);
                GL.Vertex3(sA.x, sA.y, 0);
                GL.Vertex3(sB.x, sB.y, 0);
                GL.Vertex3(sC.x, sC.y, 0);
                GL.End();
                GL.PopMatrix();
            }
        }
    }
}
#endif