//-----------------------------------------------------------------------
// <copyright file="ValidationSessionEditor.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector;
    using Sirenix.OdinInspector.Editor;
    using Sirenix.OdinInspector.Editor.Validation;
    using Sirenix.OdinInspector.Editor.Validation.Internal;
    using Sirenix.OdinInspector.Editor.Windows;
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using Sirenix.Utilities.Editor.Expressions;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading;
    using UnityEditor;
    using UnityEngine;

    public class ValidationSessionEditor : IDisposable
    {
        #region Statics
        private static GUIStyle padding;
        private static GUIStyle labelStyle;
        private static ExpressionFunc<EditorWindow, bool> windowIsVisible;

        public static List<ValidationSessionEditor> ActiveEditors = new List<ValidationSessionEditor>();

        [InitializeOnLoadMethod]
        private static void Init()
        {
            new Thread(() =>
            {
                var del = ExpressionUtility.ParseExpression("this.m_Parent && this.m_Parent.actualView == this", new EmitContext()
                {
                    IsStatic = false,
                    Type = typeof(EditorWindow),
                }, out string error);

                if (error != null)
                    throw new Exception(error);

                windowIsVisible = (ExpressionFunc<EditorWindow, bool>)del;
            }).Start();

            EditorApplication.update += ProcessVisibleEditors;
            UnityEditorEventUtility.DuringSceneGUI += UnityEditorEventUtility_DuringSceneGUI;
        }

        private static double prevRepaintTime;

        private static void ProcessVisibleEditors()
        {
            if (windowIsVisible == null)
                return;

            var repaintValidatingWindows = prevRepaintTime + 0.2 < EditorApplication.timeSinceStartup;
            if (repaintValidatingWindows)
            {
                prevRepaintTime = EditorApplication.timeSinceStartup;
            }

            foreach (var editor in ActiveEditors)
            {
                if (!editor.ValidationSession.IsValidatingInBackground || !windowIsVisible(editor.Window))
                    continue;

                // Repaint at a slower pace while the progress bar is going.
                if (repaintValidatingWindows && editor.ValidationSession.ShouldDisplayProgressBar)
                {
                    editor.window.Repaint();
                }

                // Consntantly validate visible items in the result list. (Queue one at a time each tick)
                if (editor.ValidationSession.WorkQueue.Count == 0 &&
                    !editor.ValidationSession.currentlyProcessingWorkItem.HasValue &&
                    GlobalValidationConfig.ContinuouslyValidateVisibleIssues)
                {
                    var idx = editor.largeGuiCollectionDrawing.StartIndex + editor.offset;

                    if (idx >= 0 && idx < editor.ValidationSession.Results.Length && idx < editor.largeGuiCollectionDrawing.EndIndex)
                    {
                        var r = editor.ValidationSession.Results[idx];
                        var address = r.Result.DynamicObjectAddress;

                        if (address.TryGetObjectReference(false, false, out var obj, out var err))
                        {
                            if (r.WorkItem.SceneValidators.HasValue && r.WorkItem.SceneValidators.Value.IsLoaded)
                            {
                                editor.ValidationSession.Enqueue(r.WorkItem, true);
                            }
                            else if (r.WorkItem.SceneValidators.HasValue && r.WorkItem.SceneValidators.Value.IsLoaded)
                            {
                            }
                            else
                            {
                                if (obj)
                                {
                                    var isAsset = AssetDatabase.Contains(obj);

                                    editor.ValidationSession.Enqueue(new ProjectEvent()
                                    {
                                        AssetGuid = address.LatestAddress.AssetGUID,
                                        Path = address.LatestAddress.AssetPath,
                                        Type = isAsset ? ProjectEventType.AssetModified : ProjectEventType.SceneObjectModified,
                                        InstanceID = obj.GetInstanceID(),
                                        Source = r.WorkItem.Source,

                                    }, false);
                                }
                            }
                        }
                        editor.offset++;
                    }
                    else
                    {
                        editor.offset = 0;
                    }
                }
            }
        }

        private static void UnityEditorEventUtility_DuringSceneGUI(SceneView sceneView)
        {
            foreach (var item in ActiveEditors)
            {
                item.OnSceneGui(sceneView);
            }
        }

        private static Validator GetValidatorForResultOrNull(PropertyTree tree, PersistentValidationResult result)
        {
            if (result.Path == null)
                return null;

            var prop = tree.GetPropertyAtPath(result.Path);

            if (prop != null)
            {
                var validator = prop.GetComponent<ValidationComponent>();
                var validators = validator.GetValidators();
                for (int i = 0; i < validators.Count; i++)
                {
                    var val = validators[i];

                    if (val.GetType() == result.ValidatorType)
                    {
                        if (val is IAttributeValidator iAttr)
                        {
                            if (result.ValidatorIndex == iAttr.AttributeNumber)
                            {
                                return val;
                            }
                        }
                        else
                        {
                            return val;
                        }
                    }
                }
            }

            return null;
        }

        public static void OpenOrFocusWindowForSession(ValidationSession session)
        {
            var editorForSession = ValidationSessionEditor.ActiveEditors.FirstOrDefault(n => n.ValidationSession == session);

            if (editorForSession != null)
            {
                editorForSession.Window.Show();
                editorForSession.Window.Focus();
            }
            else
            {
                OdinValidatorWindow.OpenWindow(session, false);
            }
        }

        #endregion

        private bool normalize = false;
        private Vector2 bulkFixMetaDataScrollPos;
        private Vector2 metaDataScrollPos;
        private Vector2 resultsScrollPos;
        private Vector2 infoScrollPos;
        private Vector2 bulkFixScrollPos;
        private GUISpinner guiSpinner = new GUISpinner();
        private RuleDataWrapper rules;
        private string showTip;
        private PersistentValidationResult prevSelectedResult;
        private PropertyTree currentResultTree;
        private ResultItem? currentSelectedRestoredHighestSeverityResultItem;
        private PropertyTree metaDataTree;
        private PropertyTree issueFixerTree;
        private Fix currentFix;
        private Timings timings = new Timings();
        private Action delayedAction = null;
        private int offset = 0;
        private UnityEditor.IMGUI.Controls.SearchField searchField = new UnityEditor.IMGUI.Controls.SearchField();
        private EditorWindow window;
        private LargeGuiCollectionHelper largeGuiCollectionDrawing;
        private readonly FlagEnumColumnDrawer<ResultListColumnFilter> columnDrawer;
        private EditorPrefBool hideFilterTips = new EditorPrefBool("Odin_Validator_Editor_" + nameof(hideFilterTips), false);
        private EditorPrefFloat leftMenuWidth = new EditorPrefFloat("Odin_Validator_Editor_" + nameof(leftMenuWidth), 190);
        private EditorPrefFloat rightMenuWidth = new EditorPrefFloat("Odin_Validator_Editor_" + nameof(rightMenuWidth), 190);
        private EditorPrefFloat resultInfoHeight = new EditorPrefFloat("Odin_Validator_Editor_" + nameof(resultInfoHeight), 90);
        private EditorPrefBool filterToggleFixTypes = new EditorPrefBool("Odin_Validator_Editor_" + nameof(filterToggleFixTypes), false);
        private EditorPrefBool filterToggleScenes = new EditorPrefBool("Odin_Validator_Editor_" + nameof(filterToggleScenes), false);
        private EditorPrefBool filterToggleObjectTypes = new EditorPrefBool("Odin_Validator_Editor_" + nameof(filterToggleObjectTypes), false);
        private EditorPrefBool filterToggleValidatorTypes = new EditorPrefBool("Odin_Validator_Editor_" + nameof(filterToggleValidatorTypes), false);
        private EditorPrefBool expandSessionSettings = new EditorPrefBool("Odin_Validator_Editor_" + nameof(expandSessionSettings), false);
        private EditorPrefBool expandValidationSettings = new EditorPrefBool("Odin_Validator_Editor_" + nameof(expandValidationSettings), false);
        private EditorPrefBool expandWidgetSettings = new EditorPrefBool("Odin_Validator_Editor_" + nameof(expandWidgetSettings), false);
        private EditorPrefBool expandWindowSettings = new EditorPrefBool("Odin_Validator_Editor_" + nameof(expandWindowSettings), false);
        private EditorPrefBool expandProfilerTickTime = new EditorPrefBool("Odin_Validator_Editor_" + nameof(expandProfilerTickTime), false);
        private EditorPrefBool expandProfilerBreakdown = new EditorPrefBool("Odin_Validator_Editor_" + nameof(expandProfilerBreakdown), false);
        private EditorPrefBool expandProfilerCurrentSession = new EditorPrefBool("Odin_Validator_Editor_" + nameof(expandProfilerCurrentSession), false);
        private EditorPrefBool expandProfilerTimings = new EditorPrefBool("Odin_Validator_Editor_" + nameof(expandProfilerTimings), false);
        private EditorPrefBool expandProfilerEvents = new EditorPrefBool("Odin_Validator_Editor_" + nameof(expandProfilerEvents), false);
        private EditorPrefBool expandEventsOnPlay = new EditorPrefBool("Odin_Validator_Editor_" + nameof(expandEventsOnPlay), false);
        private EditorPrefBool expandEventsOnBuild = new EditorPrefBool("Odin_Validator_Editor_" + nameof(expandEventsOnBuild), false);
        private EditorPrefBool expandEventsOnProjectStartup = new EditorPrefBool("Odin_Validator_Editor_" + nameof(expandEventsOnProjectStartup), false);
        private EditorPrefEnum<MenuOptions> selectedOption = new EditorPrefEnum<MenuOptions>("Odin_Validator_Editor_" + nameof(selectedOption), MenuOptions.FilterResults);
        private EditorPrefBool selectedOptionIsVisisble = new EditorPrefBool("Odin_Validator_Editor_" + nameof(selectedOptionIsVisisble), false);
        private EditorPrefFloat[] scrollPositions = EnumTypeUtilities<MenuOptions>.VisibleEnumMemberInfos.Select(x => new EditorPrefFloat("Odin_Validator_Editor_" + nameof(scrollPositions) + x.Value, 0f)).ToArray();
        private EditorPrefEnum<ConfigSourceType> selectedRuleSrc = new EditorPrefEnum<ConfigSourceType>("Odin_Validator_Editor_" + nameof(selectedRuleSrc), ConfigSourceType.Project);
        private EditorPrefEnum<ConfigSourceType> selectedExcludeSrc = new EditorPrefEnum<ConfigSourceType>("Odin_Validator_Editor_" + nameof(selectedExcludeSrc), ConfigSourceType.Project);
        private PersistentValidationResult selectionToRecover = null;
        private SessionConfigDataDrawer sessionConfigDataDrawer;
        private SessionConfigDataDrawer eventConfigDataDrawer;
        private int nextScrollTo = -1;

        public readonly ValidationSession ValidationSession;
        public int SelectedIndex;

        public bool MenuVisibility
        {
            get => this.selectedOptionIsVisisble.Value;
            set
            {
                if (value != this.selectedOptionIsVisisble.Value)
                {
                    this.selectionToRecover = this.selectionToRecover ?? this.SelectedResult;
                    this.selectedOptionIsVisisble.Value = value;
                }
            }
        }
        public MenuOptions SelectedMenu
        {
            get => this.selectedOption.Value;
            set
            {
                if (value != this.selectedOption.Value)
                {
                    this.selectionToRecover = this.selectionToRecover ?? this.SelectedResult;
                    this.selectedOption.Value = value;
                }
            }
        }
        public EditorWindow Window => this.window;
        public PersistentValidationResult SelectedResult => SelectedItem.Result;
        public ValidationSessionEditor(EditorWindow window, ValidationSession session)
        {
            this.window = window;
            this.ValidationSession = session;
            //this.ValidationSession.OnResult += CollectTimings;
            this.ValidationSession.Results.OnResultsChanged += RepaintWindow;
            this.columnDrawer = new FlagEnumColumnDrawer<ResultListColumnFilter>("VALIDATION_SESSION2", ResultListColumnFilter.Message | ResultListColumnFilter.Location, ResultListColumnFilter.Message);
            this.rules = RuleConfig.Instance.GetRuleDataWrapper();
            ActiveEditors.Add(this);

            this.sessionConfigDataDrawer = new SessionConfigDataDrawer()
            {
                Session = this.ValidationSession,
                DataSources = this.ValidationSession.Config.SessionData,
                SelectedConfigSource = new EditorPrefInt("Odin_Validator_Editor_SelectedConfigSource", 0)
            };

            this.eventConfigDataDrawer = new SessionConfigDataDrawer()
            {
                Session = this.ValidationSession
            };
        }

        private ValidationSessionResultCollector.ResultItem SelectedItem
        {
            get
            {
                if (this.SelectedIndex < 0)
                    this.SelectedIndex = 0;
                else if (this.SelectedIndex >= this.ValidationSession.Results.Length)
                    this.SelectedIndex = this.ValidationSession.Results.Length - 1;

                if (this.ValidationSession.Results.Length > 0)
                    return this.ValidationSession.Results[this.SelectedIndex];

                return default;
            }
        }

        public void OnGUI(Rect area)
        {
            if (Event.current.type == EventType.Layout && this.delayedAction != null)
            {
                try
                {
                    delayedAction();
                }
                catch (Exception ex)
                {
                    if (ex.IsExitGUIException()) throw ex.AsExitGUIException();
                    Debug.LogException(ex);
                }
                finally
                {
                    delayedAction = null;
                }
            }


            this.HandleIssueSelectionChanges();

            labelStyle = labelStyle ?? new GUIStyle(SirenixGUIStyles.Label);
            labelStyle.alignment = TextAnchor.MiddleLeft;
            padding = padding ?? new GUIStyle() { padding = new RectOffset(10, 10, (int)(ValidatorGui.LineHeight / 2), (int)(ValidatorGui.LineHeight / 2)) };

#if ODIN_TRIAL
            if (ValidatorTrialUtility.IsExpired)
            {
                var trialWarningRect = area.TakeFromTop(30);
                EditorGUI.DrawRect(trialWarningRect, ValidatorGui.DarkRed);

                string msg;

                if (ValidatorTrialUtility.IsReallyExpired)
                {
                    msg = "Your Odin Validator trial expired " + ValidatorTrialUtility.EndTimeString + ", " + ValidatorTrialUtility.TimeLeftString + " ago. Scanning the project will no longer yield any results.";
                }
                else
                {
                    msg = "Your Odin Validator trial expired " + ValidatorTrialUtility.EndTimeString + ", " + ValidatorTrialUtility.TimeLeftString + " ago.";
                }

                GUI.Label(trialWarningRect.TakeFromLeft(trialWarningRect.width * 0.6f).Padding(5), msg, SirenixGUIStyles.LeftAlignedWhiteMiniLabel);
                trialWarningRect.TakeFromRight(10);
                if (GUI.Button(trialWarningRect.AlignCenterY(20).AlignRight(160), "Purchase Odin Validator"))
                {
                    Application.OpenURL("https://odininspector.com/pricing");
                }
            }
#endif

            var toolbarRect = area.TakeFromTop(ValidatorGui.LineHeight);
            var leftMenuSelectorRect = area.TakeFromLeft(ValidatorGui.IconButtonWidth);
            var leftMenuWidth = this.leftMenuWidth.Value * (this.MenuVisibility ? 1 : 0);
            var leftMenuRect = area.TakeFromLeft(leftMenuWidth);

            this.leftMenuWidth.Value = ValidatorGui.VerticalMenuSlider(leftMenuRect.TakeFromRight(1), this.leftMenuWidth, 100, 900);

            this.DrawFeedbackIcon(true);

            if (this.SelectedMenu == MenuOptions.BulkFixing && this.MenuVisibility)
            {
                var rightMenuRect = area.TakeFromRight(this.rightMenuWidth.Value);
                this.rightMenuWidth.Value = ValidatorGui.VerticalMenuSlider(area.TakeFromRight(1), this.rightMenuWidth, 100, 900, -1);
                this.DrawBulkFixingFixer(rightMenuRect);
                this.DrawResults(area);
            }
            else
            {
                var issueInfoRect = area.TakeFromBottom(this.resultInfoHeight);
                var issueInfoSlideRect = issueInfoRect.TakeFromTop(1);
                this.resultInfoHeight.Value = ValidatorGui.HorizontalMenuSlider(issueInfoSlideRect, this.resultInfoHeight, 50, 600);
                this.DrawResults(area);
                this.DrawBottomResultInfo(issueInfoRect);
            }

            this.DrawLeftMenu(leftMenuRect);
            this.DrawLeftMenuSelector(leftMenuSelectorRect);
            this.DrawToolbar(toolbarRect);

            this.DrawFeedbackIcon(false);

        }

        public void OnSceneGui(SceneView sceneView)
        {
            var result = this.SelectedResult;
            if (result != null && this.currentResultTree != null && this.currentSelectedRestoredHighestSeverityResultItem.HasValue)
            {
                var val = this.GetValidatorForCurrentSelectedResultOrNull();
                if (val != null)
                {
                    var resultItem = this.currentSelectedRestoredHighestSeverityResultItem.Value;
                    if (result.HighestSeverityResult.ResultType != ValidationResultType.Valid)
                    {
                        val.OnSceneGuiSelected(ref resultItem, sceneView);
                    }
                }
            }
        }

        private Validator GetValidatorForCurrentSelectedResultOrNull()
        {
            if (this.currentResultTree == null)
                return null;

            if (this.SelectedResult == null)
                return null;

            if (this.SelectedResult.Path == null)
                return null;

            return GetValidatorForResultOrNull(this.currentResultTree, this.SelectedResult);
        }

        private void RepaintWindow()
        {
            if (window)
                window.Repaint();
        }

        private void HandleIssueSelectionChanges()
        {
            this.ValidationSession.Results.ApplyFilters = (this.SelectedMenu == MenuOptions.FilterResults || this.SelectedMenu == MenuOptions.BulkFixing) && this.MenuVisibility;

            // Update search filters.
            if (Event.current.type == EventType.Layout)
            {
                if (this.SelectedMenu == MenuOptions.FilterResults || !this.MenuVisibility)
                {
                    if (this.ValidationSession.Results.FixTypeFilters.Enabled)
                    {
                        if (this.selectionToRecover == null)
                            this.selectionToRecover = this.SelectedResult;

                        this.ValidationSession.Results.FixTypeFilters.Enabled = false;
                        this.ValidationSession.Results.MarkFiltersDirty();
                    }
                }
                else if (this.SelectedMenu == MenuOptions.BulkFixing)
                {
                    var filters = this.ValidationSession.Results.FixTypeFilters;

                    if (!filters.Enabled)
                    {
                        if (this.selectionToRecover == null)
                            this.selectionToRecover = this.SelectedResult;
                        filters.Enabled = true;
                        this.ValidationSession.Results.MarkFiltersDirty();
                    }

                    var turnOthersOff = false;
                    if (Event.current.type == EventType.Layout)
                    {
                        foreach (var item in filters.OrderedItems)
                        {
                            if (turnOthersOff)
                            {
                                if (item.Enabled)
                                {
                                    if (this.selectionToRecover == null)
                                        this.selectionToRecover = this.SelectedResult;

                                    item.Enabled = false;
                                    this.ValidationSession.Results.MarkFiltersDirty();
                                }
                            }
                            else if (item.Enabled)
                            {
                                turnOthersOff = true;
                            }
                        }
                    }
                }
            }

            // Update selected result.
            var selectedResult = this.SelectedResult;

            // Recover selection
            {
                if (this.prevSelectedResult != selectedResult && this.selectionToRecover != null)
                {
                    this.SelectedIndex = 0;
                    var arr = this.ValidationSession.Results.GetFilteredItems();
                    var comparer = new PersistentValidationResult.Comparer();
                    for (int i = 0; i < arr.Length; i++)
                    {
                        if (comparer.Equals(this.selectionToRecover, arr[i].Result))
                        {
                            this.SelectedIndex = i;
                            break;
                        }
                    }

                    selectedResult = this.SelectedResult;
                    this.nextScrollTo = this.SelectedIndex;
                }

                this.selectionToRecover = null;
            }

            if (this.prevSelectedResult != selectedResult)
            {
                this.prevSelectedResult = selectedResult;
                this.currentResultTree?.Dispose();
                this.currentResultTree = null;
                this.metaDataTree?.Dispose();
                this.metaDataTree = null;
                this.currentSelectedRestoredHighestSeverityResultItem = null;

                if (selectedResult != null && selectedResult.DynamicObjectAddress
                    .TryGetObjectReference(false, false, out var uObj, out _) && selectedResult.ValidatorType != null)
                {
                    this.currentResultTree = PropertyTree.Create(uObj);

                    var validator = this.GetValidatorForCurrentSelectedResultOrNull();

                    ResultItemMetaData[] metadata;
                    ResultItemPersistor.PersistenceContext rebuildContext;

                    if (validator != null)
                    {
                        rebuildContext = ResultItemPersistor.CreateContextFromValidator(validator);
                    }
                    else
                    {
                        var prop = this.currentResultTree.GetPropertyAtPath(selectedResult.Path);

                        rebuildContext = new ResultItemPersistor.PersistenceContext()
                        {
                            Tree = this.currentResultTree,
                            Property = prop,
                            Root = uObj,
                            ValueEntry = prop?.ValueEntry,
                            BaseValueEntry = prop?.BaseValueEntry
                        };
                    }

                    this.currentSelectedRestoredHighestSeverityResultItem = ResultItemPersistor.RebuildResultItems(new PersistentResultItem[] { selectedResult.HighestSeverityResult }, ref rebuildContext, false)[0];
                    metadata = this.currentSelectedRestoredHighestSeverityResultItem.Value.MetaData;

                    if (metadata != null && metadata.Length > 0)
                    {
                        this.metaDataTree = PropertyTree.Create(new ResultItemMetaDataDrawer(metadata));
                    }
                }
            }


            //// Update metadata to always be the latest.
            //if (this.currentFix != null && selectedResult != null)
            //{
            //    //var drawer = this.metaDataTree.WeakTargets.FirstOrDefault() as ResultItemMetaDataDrawer;
            //    //if (drawer != null && this.currentSelectedRestoredHighestSeverityResultItem.HasValue)
            //    //{
            //    //    drawer.MetaData = this.currentSelectedRestoredHighestSeverityResultItem.Value.MetaData;
            //    //}
            //}

            // Update current selected issue
            if (true)
            {
                var fix = selectedResult?.HighestSeverityResult.Data.MangledFix;

                if (this.SelectedResult == null)
                {
                    this.issueFixerTree?.Dispose();
                    this.issueFixerTree = null;
                    this.currentFix = null;
                }
                else
                {
                    if (this.currentFix != null)
                    {
                        if (fix != null)
                        {
                            var currFixerType = this.currentFix.FixIdentifier;
                            var fixerType = fix.FixIdentifier;

                            if (fixerType != currFixerType)
                            {
                                this.issueFixerTree?.Dispose();
                                this.issueFixerTree = null;
                                this.currentFix = null;
                            }
                        }
                        else
                        {
                            this.issueFixerTree?.Dispose();
                            this.issueFixerTree = null;
                            this.currentFix = null;
                        }
                    }
                }

                if (this.currentFix == null && fix != null)
                {
                    var obj = fix.CreateEditorObject();
                    this.issueFixerTree?.Dispose();
                    if (obj != null)
                    {
                        this.issueFixerTree = PropertyTree.Create(obj);
                    }
                    this.currentFix = fix;
                }
            }
            //else if (this.currentFix != null || this.issueFixerTree != null)
            //{
            //    this.issueFixerTree?.Dispose();
            //    this.issueFixerTree = null;
            //    this.currentFix = null;
            //}
        }

        private void DrawBulkFixingFixer(Rect rect)
        {
            if (this.currentFix != null)
            {
                var toolbarRect = rect.TakeFromTop(ValidatorGui.LineHeight);
                var btnRect = toolbarRect.AlignRight(110).VerticalPadding(0, 1);

                ValidatorGui.Header(toolbarRect, this.currentFix.Title, null);

                EditorGUI.DrawRect(btnRect.AddX(-1).SetWidth(1), ValidatorGui.BorderColor);
                if (ValidatorGui.ToolbarBtn(btnRect, false, SdfIconType.Tools, "Execute", ""))
                {
                    var toFix = this.ValidationSession.Results
                        .GetFilteredItems()
                        .Where(x => x.Result != null && x.Result.HighestSeverityResult.ResultType != ValidationResultType.Valid)
                        .Select(x => x.Result)
                        .ToList();

                    FixResults(toFix);
                }

                GUILayout.BeginArea(rect.TakeFromTop(rect.height * 0.5f));
                this.bulkFixScrollPos = EditorGUILayout.BeginScrollView(this.bulkFixScrollPos, padding);
                this.issueFixerTree?.Draw(false);
                EditorGUILayout.EndScrollView();
                GUILayout.EndArea();
            }

            var selectedResult = this.SelectedResult;

            if (selectedResult != null)
            {
                GUILayout.BeginArea(rect);
                GUILayout.Space(1);
                ValidatorGui.Header("Issue info");
                this.bulkFixMetaDataScrollPos = EditorGUILayout.BeginScrollView(this.bulkFixMetaDataScrollPos);

                GUILayout.BeginVertical(padding);
                DrawIssueMessage();
                GUILayout.Space(10);
                DrawIssueInfo();
                GUILayout.EndVertical();

                if (this.metaDataTree != null)
                {
                    ValidatorGui.Header("Metadata");
                    DrawMetaData();
                }
                EditorGUILayout.EndScrollView();
                GUILayout.EndArea();
            }
        }

        private void FixResults(List<PersistentValidationResult> toFix)
        {
            var action = this.currentFix.Action;
            var arg = this.issueFixerTree?.WeakTargets[0];
            var fixType = this.currentFix.FixIdentifier;

            InvokeStartOfNextFrame(() =>
            {
                PropertyTree tree = null;
                var setup = UnityEditor.SceneManagement.EditorSceneManager.GetSceneManagerSetup();

                if (toFix.Count == 0)
                    return;

                // Ask user to save scene if there are unloaded scenes.
                var sceneGuids = new HashSet<SceneReference>();
                foreach (var item in toFix)
                {
                    var scene = item.GetSceneReference();
                    if (scene.IsValid)
                        sceneGuids.Add(scene);
                }

                if (sceneGuids.Any(x => !x.IsLoaded))
                    UnityEditor.SceneManagement.EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();

                try
                {
                    for (int i = 0; i < toFix.Count; i++)
                    {
                        PersistentValidationResult item = toFix[i];
                        UnityEngine.Object obj = null;

                        if (item.DynamicObjectAddress == null)
                        {
                            if (GlobalValidationConfig.DebugMode)
                            {
                                Debug.LogError("Currently unsupported/unimplented case: fixing issue for non-UnityEngine.Object root value.");
                            }
                            continue;
                        }
                        else if (!item.DynamicObjectAddress.TryGetObjectReference(true, true, out obj, out var error))
                        {
                            if (GlobalValidationConfig.DebugMode)
                            {
                                Debug.LogError($"Could not load object to fix with; resolving address failed with error '{error}'. The address was: {item.DynamicObjectAddress.LatestAddress.ToString(true)}");
                            }
                            continue;
                        }

                        if (GUIHelper.ShouldDisplaySmartCancellableProgressBar())
                            if (GUIHelper.DisplaySmartUpdatingCancellableProgressBar($"Fixing {i + 1} / {toFix.Count} results", obj + "", (i / (float)toFix.Count)))
                                break;

                        if (tree == null)
                        {
                            tree = PropertyTree.Create(obj);
                        }
                        else if (tree.TargetType != obj.GetType())
                        {
                            tree.Dispose();
                            tree = PropertyTree.Create(obj);
                        }
                        else
                        {
                            tree.SetTargets(obj);
                        }

                        var fix = this.currentFix;

                        Undo.RegisterCompleteObjectUndo(obj, $"Bulk Fix ({fix.GetType().GetNiceName()})");

                        var validator = GetValidatorForResultOrNull(tree, item);
                        var restoreContext = ResultItemPersistor.CreateContextFromValidator(validator);
                        var restoredResultItem = ResultItemPersistor.RebuildResultItems(new PersistentResultItem[] { item.HighestSeverityResult }, ref restoreContext, false)[0];

                        if (restoredResultItem.Fix.FixIdentifier == fixType)
                        {
                            try
                            {
                                if (arg == null)
                                {
                                    restoredResultItem.Fix.Action.DynamicInvoke();
                                }
                                else
                                {
                                    restoredResultItem.Fix.Action.DynamicInvoke(new object[] { arg });
                                }

                                tree.ApplyChanges();

                                if (item.DynamicObjectAddress.TryGetObjectReference(true, true, out var fixedObj, out var err))
                                {
                                    var workItem = item.HighestSeverityResult;

                                    this.ValidationSession.Enqueue(new ValidationWorkItem() { InstanceID = fixedObj.GetInstanceID(), Source = ProjectEventSource.Other }, false);
                                    this.ValidationSession.ValidateQueuedUpWorkNow(false, false);
                                }
                            }
                            catch (Exception ex)
                            {
#if !ODIN_BETA && !SIRENIX_INTERNAL
#error Filter results on args! 
#endif
                                if (GlobalValidationConfig.DebugMode)
                                {
                                    Debug.LogException(ex);
                                }
                                continue;
                            }
                        }
                    }
                }
                finally
                {
                    Undo.FlushUndoRecordObjects();
                    tree?.Dispose();
                    tree = null;
                    this.ValidationSession.Results.ProcessQueue();
                    EditorUtility.ClearProgressBar();

                    // Only automatically save changes and restore if we're switching scenes back to the original scene setup.
                    var newSetup = UnityEditor.SceneManagement.EditorSceneManager.GetSceneManagerSetup();

                    if (newSetup.Length != setup.Length)
                    {
                        UnityEditor.SceneManagement.EditorSceneManager.SaveOpenScenes();
                        UnityEditor.SceneManagement.EditorSceneManager.RestoreSceneManagerSetup(setup);
                    }
                    else
                    {
                        for (int i = 0; i < newSetup.Length; i++)
                        {
                            if (setup[i].path != newSetup[i].path)
                            {
                                UnityEditor.SceneManagement.EditorSceneManager.SaveOpenScenes();
                                UnityEditor.SceneManagement.EditorSceneManager.RestoreSceneManagerSetup(setup);
                                break;
                            }
                        }
                    }
                }

                //GUIUtility.ExitGUI();
            });
        }

        private void DrawBulkFixing()
        {
            DrawFilteredList(this.ValidationSession.Results.FixTypeFilters, filterToggleFixTypes, "Fixables", true);

            DrawFilteredList(this.ValidationSession.Results.SceneFilters, filterToggleScenes, "Locations");

            DrawFilteredList(this.ValidationSession.Results.ObjectTypeFilters, filterToggleObjectTypes, "Types");

            DrawFilteredList(this.ValidationSession.Results.ValidatorTypeFilters, filterToggleValidatorTypes, "Validators");
        }

        private void DrawBottomResultInfo(Rect issueInfoRect)
        {
            var selectedResult = this.SelectedResult;

            if (selectedResult == null)
                return;

            var rightMenuRect = issueInfoRect.TakeFromRight(this.rightMenuWidth.Value);
            this.rightMenuWidth.Value = ValidatorGui.VerticalMenuSlider(issueInfoRect.TakeFromRight(1), this.rightMenuWidth, 100, 900, -1);
            GUILayout.BeginArea(rightMenuRect);
            {
                this.metaDataScrollPos = EditorGUILayout.BeginScrollView(this.metaDataScrollPos);

                var drawInfoHeader = false;

                if (this.currentFix != null)
                {
                    var toolbarRect = ValidatorGui.Header(this.currentFix.Title);
                    GUILayout.BeginVertical(padding);
                    this.issueFixerTree?.Draw(false);

                    drawInfoHeader = true;

                    var btnRect = toolbarRect.AlignRight(110).VerticalPadding(0, 1);
                    EditorGUI.DrawRect(btnRect.AddX(-1).SetWidth(1), ValidatorGui.BorderColor);
                    if (ValidatorGui.ToolbarBtn(btnRect, false, SdfIconType.Tools, "Execute", ""))
                    {
                        var toFix = this.ValidationSession.Results
                            .GetFilteredItems()
                            .Where(x => x.Result != null && x.Result.HighestSeverityResult.ResultType != ValidationResultType.Valid)
                            .ToList();

                        FixResults(new List<PersistentValidationResult>() { SelectedResult });
                    }

                    GUILayout.EndVertical();
                    GUILayout.Space(10);
                }

                if (this.metaDataTree != null)
                {
                    drawInfoHeader = true;

                    ValidatorGui.Header("Metadata");
                    DrawMetaData();
                    GUILayout.Space(10);
                }

                if (drawInfoHeader)
                {
                    ValidatorGui.Header("Info");
                }

                GUILayout.BeginVertical(padding);
                DrawIssueInfo();
                GUILayout.EndVertical();

                EditorGUILayout.EndScrollView();
            }
            GUILayout.EndArea();


            GUILayout.BeginArea(issueInfoRect);
            {
                this.infoScrollPos = EditorGUILayout.BeginScrollView(this.infoScrollPos);
                GUILayout.BeginVertical(padding);
                DrawIssueMessage();
                GUILayout.EndVertical();
                EditorGUILayout.EndScrollView();
            }
            GUILayout.EndArea();
        }

        //private void DrawMetaData(Rect metaDataRect)
        //{
        //    GUILayout.BeginArea(metaDataRect);
        //    {
        //        ValidatorGui.Header("Metadata");
        //        this.metaDataScrollPos = EditorGUILayout.BeginScrollView(this.metaDataScrollPos);
        //        GUILayout.BeginVertical(padding);
        //        GUIHelper.PushLabelWidth(metaDataRect.width * 0.25f);
        //        DrawMetaData();
        //        GUIHelper.PopLabelWidth();
        //        GUILayout.EndVertical();
        //        EditorGUILayout.EndScrollView();
        //    }
        //    GUILayout.EndArea();
        //}

        private void DrawMetaData()
        {
            if (this.metaDataTree != null)
            {
                GUILayout.BeginVertical(padding);
                this.metaDataTree.Draw(false);
                GUILayout.EndVertical();
            }
        }

        private void DrawIssueMessage()
        {
            var selectedResult = this.SelectedResult;
            if (selectedResult == null) return;
            var message = selectedResult.HighestSeverityResult.Message;
            GUILayout.Label(message, SirenixGUIStyles.MultiLineLabel);
        }

        private void DrawIssueInfo()
        {
            var selectedResult = this.SelectedResult;
            if (selectedResult == null)
                return;
            var address = selectedResult.DynamicObjectAddress?.LatestAddress;
            var propertyPath = selectedResult.Path;
            var scene = selectedResult.GetSceneReference();
            var assetPath = address?.AssetPath;
            var hierarchyPath = address?.Hierarchy.ToString();

            var showAdvanced = GlobalValidationConfig.DebugMode.Value;

            DrawItem("Scene", scene.Name);
            DrawItem("Asset Path", assetPath);
            DrawItem("Hierachy Path", hierarchyPath);
            DrawItem("Property Path", propertyPath);

            if (showAdvanced)
            {
                var isBroken = address?.IsBroken.ToString();
                var workItem = this.SelectedItem.WorkItem;
                var latestInstanceId = selectedResult.DynamicObjectAddress?.LatestInstanceID.ToString();
                var objectType = selectedResult.DynamicObjectAddress?.LatestAddress?.ObjectType.Type?.GetNiceName();
                var validatorType = selectedResult.GetGenericValidatorType().GetNiceName();

                DrawItem("Is Broken", isBroken);
                DrawItem("Object Type", objectType);
                DrawItem("Latest Instance Id", latestInstanceId);
                DrawItem("Validator Type", validatorType);
                var h1 = System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(selectedResult.DynamicObjectAddress);
                var h2 = System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(selectedResult.DynamicObjectAddress.LatestAddress);
                DrawItem("DO Address ID", h1.GetHashCode().ToString());
                DrawItem("Latest Address ID", h2.GetHashCode().ToString());
                DrawItem("Latest Address Type", selectedResult.DynamicObjectAddress.LatestAddress.Type.ToString());

                DrawWorkItem(workItem, "Work Item");
            }

            void DrawItem(string label, string value)
            {
                if (string.IsNullOrEmpty(value) && !GlobalValidationConfig.DebugMode.Value)
                    return;

                var rect = GUILayoutUtility.GetRect(0, EditorGUIUtility.singleLineHeight);
                var isMouseOver = rect.Contains(Event.current.mousePosition);
                var labelRect = rect.TakeFromLeft(100);
                var style = isMouseOver ? SirenixGUIStyles.LeftAlignedWhiteMiniLabel : SirenixGUIStyles.LeftAlignedGreyMiniLabel;

                GUI.Label(labelRect, label, style);
                GUI.Label(rect, value, style);
            }
        }

        private void DrawResults(Rect resultsRect)
        {
            GUILayout.BeginArea(resultsRect);
            {
                var columnHeaderRect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight);
                var time = (float)EditorApplication.timeSinceStartup;

                this.columnDrawer.BeginDrawColumns(columnHeaderRect);
                {
                    this.resultsScrollPos = EditorGUILayout.BeginScrollView(this.resultsScrollPos);
                    this.largeGuiCollectionDrawing.AllocateLayout(ValidatorGui.LineHeight, this.ValidationSession.Results.Length);

                    if (this.nextScrollTo != -1)
                    {
                        this.largeGuiCollectionDrawing.ScrollTo(this.nextScrollTo, ref this.resultsScrollPos);

                        this.nextScrollTo = -1;
                    }

                    if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.A && Event.current.modifiers == EventModifiers.Control)
                    {
                        var toSelect = new List<DynamicObjectAddress>();
                        for (int j = 0; j < this.ValidationSession.Results.Length; j++)
                        {
                            toSelect.Add(this.ValidationSession.Results[j].Result?.DynamicObjectAddress);
                        }
                        SelectionUtils.AddToSelection(toSelect);
                    }

                    if (Event.current.type != EventType.Layout)
                    {
                        var columns = EnumTypeUtilities<ResultListColumnFilter>.DecomposeEnumFlagValues(this.columnDrawer.Columns.Value);

                        for (int i = this.largeGuiCollectionDrawing.StartIndex; i < this.largeGuiCollectionDrawing.EndIndex; i++)
                        {
                            ref var item = ref this.ValidationSession.Results[i];

                            item.Update();

                            var isSelectedInHiearchy = SelectionUtils.Selection.Contains(item.Result.DynamicObjectAddress.LatestInstanceID);
                            var rect = this.largeGuiCollectionDrawing.GetRect(i);
                            var isUnloaded = item.Result.DynamicObjectAddress.IsUnloaded;
                            var isSelected = i == SelectedIndex;

                            // Input events:
                            {
                                if (rect.Contains(Event.current.mousePosition) && Event.current.isMouse && Event.current.type == EventType.MouseDown)
                                {
                                    if (Event.current.modifiers == EventModifiers.Control || Event.current.modifiers == EventModifiers.Shift)
                                    {
                                        if (Event.current.modifiers == EventModifiers.Control)
                                        {
                                            SelectionUtils.AddToSelection(Enumerable.Repeat(item.Result.DynamicObjectAddress, 1));
                                        }
                                        else if (Event.current.modifiers == EventModifiers.Shift)
                                        {
                                            var from = this.SelectedIndex;
                                            var to = i;

                                            if (to < from)
                                            {
                                                var tmp = from;
                                                from = to;
                                                to = tmp;
                                            }

                                            var toSelect = new List<DynamicObjectAddress>();
                                            for (int j = from; j <= to; j++)
                                            {
                                                toSelect.Add(this.ValidationSession.Results[j].Result?.DynamicObjectAddress);
                                            }

                                            SelectionUtils.AddToSelection(toSelect);
                                        }
                                    }
                                    else
                                    {
                                        if (Event.current.clickCount == 2 && this.SelectedIndex == i)
                                        {
                                            SelectionUtils.SelectInInspector(item.Result?.DynamicObjectAddress, true, true);
                                        }
                                        else
                                        {
                                            SelectionUtils.SelectInInspector(item.Result?.DynamicObjectAddress, false, false);
                                        }
                                    }

                                    this.SelectedIndex = i;
                                    GUIHelper.RequestRepaint();
                                    this.largeGuiCollectionDrawing.ScrollTo(i, ref this.resultsScrollPos);
                                    Event.current.Use();
                                    GUIHelper.RemoveFocusControl();
                                }

                                if (Event.current.OnContextClick(rect, true))
                                {
                                    GenericMenu menu = new GenericMenu();

                                    var objType = item.Result.GetObjectType();
                                    var valType = item.Result.GetGenericValidatorType();
                                    var scene = item.Result.GetSceneReference();
                                    var message = item.Result.HighestSeverityResult.Message;

                                    if (scene.GUID != null)
                                    {
                                        menu.AddItem(new GUIContent("Only show results from this scene"), false, () =>
                                        {
                                            SelectedMenu = MenuOptions.FilterResults;
                                            MenuVisibility = true;

                                            foreach (var x in this.ValidationSession.Results.SceneFilters.OrderedItems)
                                                x.Enabled = x.Value.GUID == scene.GUID;

                                            this.ValidationSession.Results.MarkFiltersDirty();
                                            GUIHelper.RemoveFocusControl();
                                        });
                                    }
                                    else
                                    {
                                        menu.AddItem(new GUIContent("Only show results from assets"), false, () =>
                                        {
                                            SelectedMenu = MenuOptions.FilterResults;
                                            MenuVisibility = true;

                                            foreach (var x in this.ValidationSession.Results.SceneFilters.OrderedItems)
                                                x.Enabled = x.Value.GUID == null;

                                            this.ValidationSession.Results.MarkFiltersDirty();
                                            GUIHelper.RemoveFocusControl();
                                        });
                                    }

                                    menu.AddItem(new GUIContent("Only show results from this object type"), false, () =>
                                    {
                                        SelectedMenu = MenuOptions.FilterResults;
                                        MenuVisibility = true;

                                        foreach (var x in this.ValidationSession.Results.ObjectTypeFilters.OrderedItems)
                                            x.Enabled = x.Value == objType;

                                        this.ValidationSession.Results.MarkFiltersDirty();
                                        GUIHelper.RemoveFocusControl();
                                    });

                                    menu.AddItem(new GUIContent("Only show results from this validator"), false, () =>
                                    {
                                        SelectedMenu = MenuOptions.FilterResults;
                                        MenuVisibility = true;

                                        foreach (var x in this.ValidationSession.Results.ValidatorTypeFilters.OrderedItems)
                                            x.Enabled = x.Value == valType;

                                        this.ValidationSession.Results.MarkFiltersDirty();
                                        GUIHelper.RemoveFocusControl();
                                    });

                                    menu.AddItem(new GUIContent("Only show results with this error message"), false, () =>
                                    {
                                        this.selectionToRecover = this.SelectedResult;
                                        this.ValidationSession.Results.SearchTerm = message;
                                        this.ValidationSession.Results.MarkFiltersDirty();
                                        GUIHelper.RemoveFocusControl();
                                    });

                                    menu.AddSeparator("");

                                    var msg = item.Result.HighestSeverityResult.Message;
                                    var assetPath = item.Result.DynamicObjectAddress.LatestAddress.AssetPath;

                                    menu.AddItem(new GUIContent("Copy message"), false, () =>
                                    {
                                        Clipboard.Copy(msg);
                                    });

                                    menu.AddItem(new GUIContent("Copy asset path"), false, () =>
                                    {
                                        Clipboard.Copy(assetPath);
                                    });


                                    if (scene.GUID != null)
                                    {
                                        menu.AddSeparator("");

                                        menu.AddItem(new GUIContent("Ping scene asset"), false, () =>
                                        {
                                            var asset = AssetDatabase.LoadAssetAtPath(scene.Path, typeof(UnityEngine.Object));
                                            EditorGUIUtility.PingObject(asset);
                                        });
                                    }

                                    //menu.AddItem(new GUIContent("Ignore"), false, () =>
                                    //{
                                    //    SelectedMenu = MenuOptions.FilterResults;
                                    //    MenuVisibility = true;
                                    //});

                                    menu.ShowAsContext();
                                }
                            }

                            // Drawing
                            {
                                if (isUnloaded) GUIHelper.PushColor(new Color(1, 1, 1, 0.2f));

                                var bg = ValidatorGui.EditorWindowBgColor;

                                if (isSelected)
                                {
                                    bg = ValidatorGui.BtnActiveBgColor;
                                }

                                if (isSelectedInHiearchy && i != SelectedIndex)
                                {
                                    bg = ValidatorGui.BtnActiveBgColor;
                                    bg.a *= 0.3f;
                                }

                                var speed = 0.2f;
                                var stateChangeT = time - item.LastStateChangeTime;

                                if (stateChangeT < speed)
                                {
                                    GUIHelper.RequestRepaint();
                                    stateChangeT = ((speed - stateChangeT) / speed);
                                }
                                else
                                    stateChangeT = 0;

                                if (bg != ValidatorGui.EditorWindowBgColor)
                                {
                                    EditorGUI.DrawRect(rect, bg);
                                }

                                var labelStyle = i == SelectedIndex ? ValidatorGui.WhiteLabelVertical : ValidatorGui.LabelVertical;
                                var address = item.Result.DynamicObjectAddress.LatestAddress;

                                foreach (var column in columns)
                                {
                                    var columnRect = this.columnDrawer.GetColumnRect(rect, column).AlignCenterY(EditorGUIUtility.singleLineHeight);
                                    columnRect.x += 7;
                                    columnRect.width -= 14;

                                    if (column == ResultListColumnFilter.Message)
                                    {
                                        if (item.ExplodeCount > 0)
                                        {
                                            //columnRect.xMin += 10;

                                            if (Event.current.type == EventType.Repaint)
                                            {
                                                var col = ValidatorGui.BtnContentColor;
                                                var one = columnRect.height;
                                                var halfY = columnRect.height * 0.5f;
                                                var halfX = 4;

                                                if (item.ExplodedIndex == 0)
                                                {
                                                    EditorGUI.DrawRect(new Rect(columnRect.x - halfX, columnRect.y + halfY, 1, halfY + 1), col);
                                                }
                                                else if (item.ExplodedIndex == item.ExplodeCount - 1)
                                                {
                                                    EditorGUI.DrawRect(new Rect(columnRect.x - halfX, columnRect.y - 2, 1, halfY + 3), col);
                                                }
                                                else
                                                {
                                                    EditorGUI.DrawRect(new Rect(columnRect.x - halfX, columnRect.y - 2, 1, one + 3), col);
                                                }

                                                EditorGUI.DrawRect(new Rect(columnRect.x - halfX, columnRect.y + halfY, halfX, 1), col);
                                            }
                                        }

                                        var h = 16 + stateChangeT * 10;
                                        var iconRect = columnRect.TakeFromLeft(columnRect.height).AlignCenter(h, h);

                                        if (item.Result.HighestSeverityResult.ResultType == ValidationResultType.Error)
                                            ValidatorGui.DrawErrorIcon(iconRect, bg, true, isSelected);
                                        else if (item.Result.HighestSeverityResult.ResultType == ValidationResultType.Warning)
                                            ValidatorGui.DrawWarningIcon(iconRect, bg, true, isSelected);
                                        else
                                            ValidatorGui.DrawValidIcon(iconRect, bg, true, isSelected);

                                        if (item.Result.HighestSeverityResult.Data.MangledFix != null)
                                        {
                                            var fixIconRect = columnRect.TakeFromRight(columnRect.height).AlignCenter(h, h);

                                            if (isSelected)
                                            {
                                                SdfIcons.DrawIcon(fixIconRect, SdfIconType.Tools, ValidatorGui.BtnMouseOverContentColor);
                                            }
                                            else
                                            {
                                                SdfIcons.DrawIcon(fixIconRect, SdfIconType.Tools, ValidatorGui.BtnContentColor);
                                            }
                                        }

                                        GUI.Label(columnRect, item.Result.HighestSeverityResult.Message, labelStyle);
                                    }
                                    else if (column == ResultListColumnFilter.Object)
                                    {
                                        var iconRect = columnRect.TakeFromLeft(columnRect.height).AlignCenter(16, 16);
                                        var icon = GUIHelper.GetAssetThumbnail(null, address.ObjectType.Type, false);

                                        if (icon != null)
                                        {
                                            GUI.DrawTexture(iconRect, icon);
                                        }

                                        var objTypeName = address.ObjectType.GetNiceName();
                                        if (objTypeName != null)
                                        {
                                            GUI.Label(columnRect, address.Name + " / " + objTypeName, labelStyle);
                                        }
                                        else
                                        {
                                            GUI.Label(columnRect, address.Name, labelStyle);
                                        }
                                    }
                                    else if (column == ResultListColumnFilter.Location)
                                    {
                                        Texture icon;
                                        var location = string.IsNullOrEmpty(address.AssetPath) ? "Unknown" : Path.GetFileNameWithoutExtension(address.AssetPath);

                                        if (address.Type == ObjectAddress.AddressType.SceneComponent || address.Type == ObjectAddress.AddressType.SceneGameObject)
                                        {
                                            icon = ValidatorGui.SceneAssetIcon;
                                        }
                                        else if (address.Type == ObjectAddress.AddressType.PrefabComponent || address.Type == ObjectAddress.AddressType.PrefabGameObject)
                                        {
                                            icon = ValidatorGui.PrefabIcon;
                                        }
                                        else if (address.Type == ObjectAddress.AddressType.Asset)
                                        {
                                            icon = GUIHelper.GetAssetThumbnail(null, address.ObjectType.Type, false);
                                        }
                                        else
                                        {
                                            icon = GUIHelper.GetAssetThumbnail(null, typeof(UnityEngine.Object), false);
                                        }

                                        var iconRect = columnRect.TakeFromLeft(columnRect.height).AlignCenter(16, 16);

                                        if (icon != null)
                                        {
                                            GUI.DrawTexture(iconRect, icon);
                                        }

                                        GUI.Label(columnRect, location, labelStyle);
                                    }
                                    else if (column == ResultListColumnFilter.Validator)
                                    {
                                        var t = item.Result.ValidatorType;

                                        if (t != null)
                                        {
                                            GUI.Label(columnRect, t.GetNiceName(), labelStyle);
                                        }
                                        else
                                        {
                                            GUI.Label(columnRect, "-", labelStyle);
                                        }
                                    }
                                    else if (column == ResultListColumnFilter.Path)
                                    {
                                        var iconRect = columnRect.TakeFromLeft(columnRect.height).AlignCenter(16, 16);
                                        Texture icon;
                                        var t = item.Result.DynamicObjectAddress.LatestAddress.Type;

                                        if (address?.AssetPath == null)
                                        {
                                            icon = EditorGUIUtility.whiteTexture;
                                        }
                                        else if (t == ObjectAddress.AddressType.PrefabGameObject || t == ObjectAddress.AddressType.PrefabComponent || address.AssetPath.FastEndsWith(".prefab"))
                                        {
                                            icon = ValidatorGui.PrefabIcon;
                                        }
                                        else if (t == ObjectAddress.AddressType.SceneComponent || t == ObjectAddress.AddressType.SceneGameObject)
                                        {
                                            icon = ValidatorGui.SceneAssetIcon;
                                        }
                                        else
                                        {
                                            icon = GUIHelper.GetAssetThumbnail(null, address.ObjectType, false);
                                        }

                                        if (icon != null)
                                        {
                                            GUI.DrawTexture(iconRect, icon);
                                        }
                                        GUI.Label(columnRect, address.AssetPath, labelStyle);
                                    }
                                }

                                if (isUnloaded) GUIHelper.PopColor();
                            }
                        }
                    }
                    EditorGUILayout.EndScrollView();
                }
                this.columnDrawer.EndDrawColumns(GUIHelper.GetCurrentLayoutRect().ResetPosition());
            }
            GUILayout.EndArea();

            // Handle keyboard navigation
            {
                var index = this.SelectedIndex;
                var shiftSelect = (Event.current.modifiers & EventModifiers.Shift) != 0;
                ValidatorGui.HandleKeyboardNavigation(ref index);
                index = Mathf.Clamp(index, 0, this.ValidationSession.Results.Length - 1);

                if (this.SelectedIndex != index)
                {
                    if (index >= 0 && index < this.ValidationSession.Results.Length)
                    {
                        if (shiftSelect)
                        {
                            var from = this.SelectedIndex;
                            var to = index;

                            if (to < from)
                            {
                                var tmp = from;
                                from = to;
                                to = Mathf.Clamp(tmp, 0, this.ValidationSession.Results.Length - 1);
                            }

                            var toSelect = new List<DynamicObjectAddress>();
                            for (int j = from; j < to; j++)
                            {
                                toSelect.Add(this.ValidationSession.Results[j].Result?.DynamicObjectAddress);
                            }

                            SelectionUtils.AddToSelection(toSelect);
                        }
                        else
                        {
                            SelectionUtils.SelectInInspector(this.ValidationSession.Results[index].Result?.DynamicObjectAddress, false, false);
                        }
                    }

                    this.SelectedIndex = index;
                    this.largeGuiCollectionDrawing.ScrollTo(this.SelectedIndex, ref this.resultsScrollPos);
                }
            }
        }

        private void CollectTimings(ValidationSession.ValidationSessionResult e)
        {
            if (e.Result == null && e.Type == ValidationSession.ValidationSessionResult.ValidationSessionResultType.ResultAddedOrChanged)
            {
                throw new NullReferenceException();
            }

            this.timings.SampleResult(e.Result);
        }

        private void DrawLeftMenuSelector(Rect rect)
        {
            var height = ValidatorGui.LeftMenuLineHeight - 1;
            var sideMenuRect = rect;

            EditorGUI.DrawRect(sideMenuRect.TakeFromRight(1), ValidatorGui.BorderColor);

            if (SideMenuButton(sideMenuRect.TakeFromBottom(height), this.MenuVisibility ? SdfIconType.ArrowBarLeft : SdfIconType.ArrowBarRight, false, new GUIContent(this.MenuVisibility ? "Hide" : "Show")))
            {
                this.MenuVisibility = !this.MenuVisibility;
            }
            EditorGUI.DrawRect(sideMenuRect.TakeFromBottom(1), ValidatorGui.BorderColor);

            // Draw Side Menu
            // EditorGUI.DrawRect(sideMenuRect, ValidatorGUI.BorderColor);
            foreach (var option in Enum.GetValues(typeof(MenuOptions)).Cast<MenuOptions>())
            {
                if (option == MenuOptions.None)
                    continue;

                SdfIconType icon;
                if (option == MenuOptions.FilterAssets) icon = SdfIconType.Folder;
                else if (option == MenuOptions.FilterResults) icon = SdfIconType.Search;
                else if (option == MenuOptions.Rules) icon = SdfIconType.CardChecklist;
                else if (option == MenuOptions.Events) icon = SdfIconType.CalendarCheck;
                else if (option == MenuOptions.Config) icon = SdfIconType.Gear;
                else if (option == MenuOptions.Profiler) icon = SdfIconType.MenuButtonWide;
                else if (option == MenuOptions.BulkFixing) icon = SdfIconType.UiChecks;
                else if (option == MenuOptions.About) icon = SdfIconType.QuestionCircle;
                else { throw new NotImplementedException(); }

                var label = new GUIContent(option.ToString().SplitPascalCase());
                var selected = this.SelectedMenu == option;

                if (SideMenuButton(sideMenuRect.TakeFromTop(height), icon, selected && MenuVisibility, label))
                {
                    var localOptions = option;
                    InvokeStartOfNextFrame(() =>
                    {
                        if (SelectedMenu == localOptions)
                        {
                            this.MenuVisibility = !this.MenuVisibility;
                        }
                        else
                        {
                            this.SelectedMenu = localOptions;
                            this.MenuVisibility = true;
                        }
                    });
                }

                EditorGUI.DrawRect(sideMenuRect.TakeFromTop(1), ValidatorGui.BorderColor);
            }

            bool SideMenuButton(Rect btnRect, SdfIconType icon, bool selected, GUIContent label)
            {
                const float iconPadding = 2;
                var isMouseOver = btnRect.Contains(Event.current.mousePosition);
                var nameWidth = labelStyle.CalcSize(label).x;

                var prevWidth = btnRect.width;
                if (isMouseOver)
                {
                    btnRect.width += nameWidth + 10;
                }

                var iconRect = btnRect.TakeFromLeft(prevWidth);

                if (selected)
                {
                    EditorGUI.DrawRect(btnRect, ValidatorGui.BtnActiveBgColor);
                    EditorGUI.DrawRect(iconRect, ValidatorGui.BtnActiveBgColor);

                    SdfIcons.DrawIcon(iconRect.Padding(0, iconPadding), icon, Color.white, ValidatorGui.BtnActiveBgColor);

                    if (isMouseOver)
                    {
                        labelStyle.normal.textColor = Color.white;
                        GUI.Label(btnRect.AlignRight(nameWidth + 5), label, labelStyle);
                    }
                }
                else
                {
                    if (isMouseOver)
                    {
                        EditorGUI.DrawRect(iconRect, ValidatorGui.BtnMouseOverBgColor);
                        EditorGUI.DrawRect(btnRect, ValidatorGui.BtnMouseOverBgColor);

                        labelStyle.normal.textColor = ValidatorGui.BtnMouseOverContentColor;
                        GUI.Label(btnRect.AlignRight(nameWidth + 5), label, labelStyle);

                        SdfIcons.DrawIcon(iconRect.Padding(0, iconPadding), icon, ValidatorGui.BtnMouseOverContentColor, ValidatorGui.BtnMouseOverBgColor);
                        SirenixEditorGUI.DrawBorders(btnRect.Expand(1), 0, 1, 1, 1, ValidatorGui.BorderColor);
                    }
                    else
                    {
                        EditorGUI.DrawRect(iconRect, ValidatorGui.EditorWindowBgColor);
                        SdfIcons.DrawIcon(iconRect.Padding(0, iconPadding), icon, ValidatorGui.BtnContentColor, ValidatorGui.EditorWindowBgColor);
                    }
                }

                return GUI.Button(iconRect, GUIContent.none, GUIStyle.none);
            }
        }

        private void DrawLeftMenu(Rect rect)
        {
            if (this.SelectedMenu == MenuOptions.None || !this.MenuVisibility)
                return;

            GUILayout.BeginArea(rect);
            {
                GUIHelper.PushLabelWidth(rect.width * 0.25f);

                // Draw config
                this.scrollPositions[(int)this.SelectedMenu].Value = EditorGUILayout.BeginScrollView(new Vector2(0, this.scrollPositions[(int)this.SelectedMenu].Value)).y;

                this.showTip = null;

                switch (this.SelectedMenu)
                {
                    case MenuOptions.FilterResults:
                        this.DrawFilterResults();
                        break;
                    case MenuOptions.FilterAssets:
                        this.sessionConfigDataDrawer.Draw();
                        break;
                    case MenuOptions.Rules:
                        this.DrawRules(rect.ResetPosition());
                        break;
                    case MenuOptions.Events:
                        this.DrawEvents();
                        break;
                    case MenuOptions.Config:
                        this.DrawConfig();
                        break;
                    case MenuOptions.Profiler:
                        this.DrawProfiler();
                        break;
                    case MenuOptions.BulkFixing:
                        this.DrawBulkFixing();
                        break;
                    case MenuOptions.About:
                        this.DrawAbout();
                        break;
                    case MenuOptions.None:
                        break;
                    default:
                        throw new NotImplementedException();
                }


                EditorGUILayout.EndScrollView();

                if (this.showTip != null)
                {
                    SirenixEditorGUI.InfoMessageBox(this.showTip);
                    GUILayout.Space(5);
                    this.showTip = null;
                }

                GUIHelper.PopLabelWidth();
            }
            GUILayout.EndArea();
        }

        private static ISessionConfigData[] buffer = new ISessionConfigData[1];

        private void DrawEvents()
        {
            var events = AutomationConfig.Instance;
            EditorGUI.BeginChangeCheck();
            this.expandEventsOnPlay.Value = ValidatorGui.FoldoutToggle(this.expandEventsOnPlay.Value, ref events.OnPlayMode, "On Play");

            var configureLabelText = "Configure";
            var configureLabelWidth = EditorStyles.label.CalcSize(GUIHelper.TempContent(configureLabelText)).x + 10;

            if (SirenixEditorGUI.BeginFadeGroup(this.expandEventsOnPlay, this.expandEventsOnPlay.Value))
            {
                GUIHelper.PushGUIEnabled(events.OnPlayMode);
                {
                    buffer[0] = events.OnPlayModeSetup.SessionConfigData;
                    this.eventConfigDataDrawer.DataSources = buffer;

                    events.OnPlayModeIfWarnings = EnumSelector<AutomationConfig.OnPlayModeActions>.DrawEnumField(GetRect(), GUIHelper.TempContent("If Warnings"), events.OnPlayModeIfWarnings);
                    events.OnPlayModeIfErrors = EnumSelector<AutomationConfig.OnPlayModeActions>.DrawEnumField(GetRect(), GUIHelper.TempContent("If Errors"), events.OnPlayModeIfErrors);
                    events.OnPlayModeAlwaysCompleteValidationFully = EditorGUI.ToggleLeft(GetRect(), "Always Complete Validation", events.OnPlayModeAlwaysCompleteValidationFully);
                    events.OnPlayModeFlashScreen = EditorGUI.ToggleLeft(GetRect(), "Flash Screen", events.OnPlayModeFlashScreen);

                    var profileRect = GetRect();
                    var profileBtnRect = profileRect.TakeFromRight(configureLabelWidth);
                    events.OnPlayModeSetup.Profile = EditorGUI.ToggleLeft(profileRect, "Custom Profile", events.OnPlayModeSetup.Profile == AutomationConfig.ValidationSetup.RunKind.Custom) ? AutomationConfig.ValidationSetup.RunKind.Custom : AutomationConfig.ValidationSetup.RunKind.GlobalValidation;
                    GUIHelper.PushGUIEnabled(events.OnPlayModeSetup.Profile == AutomationConfig.ValidationSetup.RunKind.Custom);
                    if (GUI.Button(profileBtnRect, configureLabelText))
                    {
                        var wnd = OdinEditorWindow.InspectObject(
                            new SessionConfigDataDrawer()
                            {
                                Session = this.ValidationSession,
                                DataSources = new ISessionConfigData[] { events.OnPlayModeSetup.SessionConfigData }
                            });

                        wnd.OnClose += () => { EditorUtility.SetDirty(events); };
                    }
                    GUIHelper.PopGUIEnabled();
                }
                GUIHelper.PopGUIEnabled();
                GUILayout.Space((int)(ValidatorGui.LineHeight * 0.5f));
            }
            SirenixEditorGUI.EndFadeGroup();

            this.expandEventsOnBuild.Value = ValidatorGui.FoldoutToggle(this.expandEventsOnBuild.Value, ref events.OnBuild, "On Build");
            if (SirenixEditorGUI.BeginFadeGroup(this.expandEventsOnBuild, this.expandEventsOnBuild.Value))
            {
                GUIHelper.PushGUIEnabled(events.OnBuild);
                {
                    buffer[0] = events.OnBuildSetup.SessionConfigData;
                    this.eventConfigDataDrawer.DataSources = buffer;

                    events.OnBuildIfWarnings = EnumSelector<AutomationConfig.OnBuildActions>.DrawEnumField(GetRect(), GUIHelper.TempContent("If Warnings"), events.OnBuildIfWarnings);
                    events.OnBuildIfErrors = EnumSelector<AutomationConfig.OnBuildActions>.DrawEnumField(GetRect(), GUIHelper.TempContent("If Errors"), events.OnBuildIfErrors);
                    events.OnBuildAlwaysCompleteValidationFully = EditorGUI.ToggleLeft(GetRect(), "Always Complete Validation", events.OnBuildAlwaysCompleteValidationFully);
                    events.OnBuildFlashScreen = EditorGUI.ToggleLeft(GetRect(), "Flash Screen", events.OnBuildFlashScreen);

                    var profileRect = GetRect();
                    var profileBtnRect = profileRect.TakeFromRight(configureLabelWidth);
                    events.OnBuildSetup.Profile = EditorGUI.ToggleLeft(profileRect, "Custom Profile", events.OnBuildSetup.Profile == AutomationConfig.ValidationSetup.RunKind.Custom) ? AutomationConfig.ValidationSetup.RunKind.Custom : AutomationConfig.ValidationSetup.RunKind.GlobalValidation;
                    GUIHelper.PushGUIEnabled(events.OnBuildSetup.Profile == AutomationConfig.ValidationSetup.RunKind.Custom);
                    if (GUI.Button(profileBtnRect, configureLabelText))
                    {
                        var wnd = OdinEditorWindow.InspectObject(
                            new SessionConfigDataDrawer()
                            {
                                Session = this.ValidationSession,
                                DataSources = new ISessionConfigData[] { events.OnBuildSetup.SessionConfigData }
                            });

                        wnd.OnClose += () => { EditorUtility.SetDirty(events); };
                    }
                    GUIHelper.PopGUIEnabled();
                }
                GUIHelper.PopGUIEnabled();
                GUILayout.Space((int)(ValidatorGui.LineHeight * 0.5f));
            }
            SirenixEditorGUI.EndFadeGroup();
            this.expandEventsOnProjectStartup.Value = ValidatorGui.FoldoutToggle(this.expandEventsOnProjectStartup.Value, ref events.OnProjectStartup, "On Project Startup");
            if (SirenixEditorGUI.BeginFadeGroup(this.expandEventsOnProjectStartup, this.expandEventsOnProjectStartup.Value))
            {
                GUIHelper.PushGUIEnabled(events.OnProjectStartup);
                {
                    buffer[0] = events.OnProjectStartupSetup.SessionConfigData;
                    this.eventConfigDataDrawer.DataSources = buffer;

                    events.OnProjectStartupIfWarnings = EnumSelector<AutomationConfig.OnProjectStartupActions>.DrawEnumField(GetRect(), new GUIContent("If Warnings"), events.OnProjectStartupIfWarnings);
                    events.OnProjectStartupIfErrors = EnumSelector<AutomationConfig.OnProjectStartupActions>.DrawEnumField(GetRect(), new GUIContent("If Errors"), events.OnProjectStartupIfErrors);
                    events.OnProjectStartupAlwaysCompleteValidationFully = EditorGUI.ToggleLeft(GetRect(), "Always Complete Validation", events.OnProjectStartupAlwaysCompleteValidationFully);
                    events.OnProjectStartupFlashScreen = EditorGUI.ToggleLeft(GetRect(), "Flash Screen", events.OnProjectStartupFlashScreen);

                    var profileRect = GetRect();
                    var profileBtnRect = profileRect.TakeFromRight(configureLabelWidth);
                    events.OnProjectStartupSetup.Profile = EditorGUI.ToggleLeft(profileRect, "Custom Profile", events.OnProjectStartupSetup.Profile == AutomationConfig.ValidationSetup.RunKind.Custom) ? AutomationConfig.ValidationSetup.RunKind.Custom : AutomationConfig.ValidationSetup.RunKind.GlobalValidation;
                    GUIHelper.PushGUIEnabled(events.OnProjectStartupSetup.Profile == AutomationConfig.ValidationSetup.RunKind.Custom);
                    if (GUI.Button(profileBtnRect, configureLabelText))
                    {
                        var wnd = OdinEditorWindow.InspectObject(
                            new SessionConfigDataDrawer()
                            {
                                Session = this.ValidationSession,
                                DataSources = new ISessionConfigData[] { events.OnProjectStartupSetup.SessionConfigData }
                            });

                        wnd.OnClose += () => { EditorUtility.SetDirty(events); };
                    }
                    GUIHelper.PopGUIEnabled();
                }
                GUIHelper.PopGUIEnabled();
                GUILayout.Space((int)(ValidatorGui.LineHeight * 0.5f));
            }
            SirenixEditorGUI.EndFadeGroup();
            if (EditorGUI.EndChangeCheck())
            {
                EditorUtility.SetDirty(events);
            }
            buffer[0] = null;
        }

        private void DrawFeedbackIcon(bool isFirst)
        {
            if (Event.current.type == EventType.Layout)
                return;

            if (!GlobalValidationConfig.ShowFeedbackButton.Value)
                return;

            var rect = GUIHelper.GetCurrentLayoutRect().AlignRight(30).AlignCenterY(30);

            rect.x = Mathf.RoundToInt(rect.x);
            rect.y = Mathf.RoundToInt(rect.y);
            rect.width = Mathf.RoundToInt(rect.width);
            rect.height = Mathf.RoundToInt(rect.height);

            if (isFirst)
            {
                if (GUI.Button(rect, new GUIContent("", "Open a feedback form to send feedback to the developers. This is a preview build, we'd love hear some feedback and ideas for improvements from you."), GUIStyle.none))
                {
                    OdinFeedbackWindow.Open("Odin Validator", new OdinFeedbackUtility.FeedbackMetaData[] { new OdinFeedbackUtility.FeedbackMetaData("preview", "true") });
                }
            }
            else
            {
                var bg = ValidatorGui.EditorWindowBgColor;
                var isMouseOver = rect.Contains(Event.current.mousePosition);

                if (EditorGUIUtility.isProSkin)
                {
                    bg.r *= 0.7f;
                    bg.g *= 0.7f;
                    bg.b *= 0.7f;
                }
                else
                {
                    bg.r *= 1.5f;
                    bg.g *= 1.5f;
                    bg.b *= 1.5f;
                }

                EditorGUI.DrawRect(rect, bg);
                SirenixEditorGUI.DrawBorders(rect, 1);

                SdfIcons.DrawIcon(rect.Padding(4), SdfIconType.EnvelopePlusFill, isMouseOver ? ValidatorGui.BtnMouseOverContentColor : ValidatorGui.BtnContentColor, bg);

            }
        }

        private static Texture2D validatorLogo;

        private void DrawAbout()
        {
            if (validatorLogo == null)
            {
                if (EditorGUIUtility.isProSkin)
                    validatorLogo = AssetDatabase.LoadAssetAtPath<Texture2D>(SirenixAssetPaths.DefaultSirenixPluginPath + "Odin Validator/Editor/Assets/Odin Validator - White.png");
                else
                    validatorLogo = AssetDatabase.LoadAssetAtPath<Texture2D>(SirenixAssetPaths.DefaultSirenixPluginPath + "Odin Validator/Editor/Assets/Odin Validator - Black.png");
            }
            GUI.DrawTexture(GUILayoutUtility.GetRect(0, 80).Padding(10, 10, 10, 0), validatorLogo, ScaleMode.ScaleToFit);
            GUILayout.BeginVertical(padding);

            GUILayout.Label("Developed and published by Sirenix", SirenixGUIStyles.CenteredGreyMiniLabel);
            GUILayout.Label("Version " + OdinInspectorVersion.Version, SirenixGUIStyles.CenteredGreyMiniLabel);

            GUILayout.BeginHorizontal();
            {
                if (GUILayout.Button("Tutorials"))
                    Application.OpenURL("https://odininspector.com/tutorials#odin-validator");

                if (GUILayout.Button("Issue Tracker"))
                    Application.OpenURL("https://bitbucket.org/sirenix/odin-inspector/issues");

                if (GUILayout.Button("Support"))
                    Application.OpenURL("https://discord.gg/WTYJEra");
            }
            GUILayout.EndHorizontal();


            GUILayout.EndVertical();
        }

        private void DrawFilterResults()
        {
            DrawFilteredList(this.ValidationSession.Results.SceneFilters, filterToggleScenes, "Locations");

            DrawFilteredList(this.ValidationSession.Results.ObjectTypeFilters, filterToggleObjectTypes, "Types");

            DrawFilteredList(this.ValidationSession.Results.ValidatorTypeFilters, filterToggleValidatorTypes, "Validators");

            GUILayout.FlexibleSpace();
        }

        private void DrawFilteredList<T>(ValidationSessionResultCollector.Filter<T> collection, EditorPrefBool foldoutToggle, string name, bool isRadio = false)
        {
            if (collection.OrderedItems.Count == 0)
                return;

            if (isRadio)
            {
                ValidatorGui.Header(name);
            }
            else
            {
                foldoutToggle.Value = ValidatorGui.Foldout(foldoutToggle.Value, name, isRadio ? 0 : ValidatorGui.LineHeight);
            }

            var toggleRect = GUILayoutUtility.GetLastRect().AlignLeft(ValidatorGui.LineHeight);
            toggleRect.x += ValidatorGui.ContentPadding;

            var items = collection.OrderedItems;
            if (!isRadio)
            {
                var isMixed = false;
                var isAllToggled = true;

                if (Event.current.type != EventType.Layout && collection.OrderedItems.Count > 0)
                {
                    var firstIsToggled = collection.OrderedItems[0].Enabled;

                    for (int i = 0; i < items.Count; i++)
                    {
                        var isToggled = items[i].Enabled;

                        if (isToggled != firstIsToggled)
                        {
                            isMixed = true;
                        }

                        if (!isToggled)
                        {
                            isAllToggled = false;
                        }
                    }
                }

                EditorGUI.BeginChangeCheck();
                EditorGUI.showMixedValue = isMixed;
                var newToggleAllState = EditorGUI.ToggleLeft(toggleRect, GUIContent.none, isAllToggled);
                EditorGUI.showMixedValue = false;
                if (EditorGUI.EndChangeCheck())
                {
                    InvokeStartOfNextFrame(() =>
                    {
                        this.selectionToRecover = this.SelectedResult;

                        foreach (var item in items)
                        {
                            item.Enabled = newToggleAllState;
                        }

                        this.ValidationSession.Results.MarkFiltersDirty();
                    });
                }
            }

            if (SirenixEditorGUI.BeginFadeGroup(foldoutToggle, foldoutToggle.Value))
            {
                var countContent = GUIHelper.TempContent("");
                var labelStyle = SirenixGUIStyles.Label;
                var toggleStyle = isRadio ? EditorStyles.radioButton : EditorStyles.toggle;

                for (int i = 0; i < items.Count; i++)
                {
                    var item = items[i];
                    var rect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight).AlignCenterY(EditorGUIUtility.singleLineHeight);

                    //SirenixEditorGUI.GetFeatureRichControl(rect, out var id, out var hasKeyboardFocus);

                    if (Event.current.type != EventType.Layout && Event.current.type != EventType.Repaint)
                    {
                        if (Event.current.type == EventType.MouseDown && rect.Contains(Event.current.mousePosition))
                        {
                            InvokeStartOfNextFrame(() =>
                            {
                                this.selectionToRecover = this.SelectedResult;

                                if (isRadio)
                                {
                                    foreach (var m in items)
                                    {
                                        m.Enabled = false;
                                    }

                                    item.Enabled = true;
                                }
                                else
                                {
                                    item.Enabled = !item.Enabled;
                                }

                                this.ValidationSession.Results.MarkFiltersDirty();
                            });

                            Event.current.Use();
                        }
                    }

                    if (Event.current.type == EventType.Repaint)
                    {
                        var icon = GetFilterItemIcon(item, out bool highlightIcon);
                        rect.TakeFromLeft(ValidatorGui.ContentPadding);
                        var contentRect = rect;
                        toggleRect = contentRect.TakeFromLeft(contentRect.height);
                        countContent.text = item.Count.ToString();
                        var countRectWidth = labelStyle.CalcSize(countContent).x;
                        var countRect = contentRect.TakeFromRight(countRectWidth + ValidatorGui.ContentPadding).AlignLeft(countRectWidth);
                        var iconRect = contentRect.TakeFromLeft(icon != null ? contentRect.height : 0).AlignCenter(16, 16);
                        var labelRect = contentRect;

                        toggleStyle.Draw(position: toggleRect,
                                         content: GUIContent.none,
                                         isHover: rect.Contains(Event.current.mousePosition),
                                         isActive: false,
                                         on: item.Enabled,
                                         hasKeyboardFocus: false);

                        if (!item.Enabled)
                        {
                            GUIHelper.PushColor(new Color(1, 1, 1, 0.4f));
                        }

                        GUI.Label(countRect, countContent, labelStyle);
                        GUI.Label(labelRect, item.Name, labelStyle);

                        if (icon != null)
                        {
                            var prev = GUI.color;
                            GUI.color = highlightIcon ? new Color(1, 1, 1, 1f) : new Color(1, 1, 1, 0.4f);
                            GUI.DrawTexture(iconRect, icon);
                            GUI.color = prev;
                        }

                        if (!item.Enabled)
                        {
                            GUIHelper.PopColor();
                        }
                    }
                }

                GUILayout.Space((int)(ValidatorGui.LineHeight * 0.5f));
            }
            SirenixEditorGUI.EndFadeGroup();
        }

        private void DrawConfig()
        {
            const string DeepValidationTooltip = "Validate all components and assets deeply. When this is off, only components and assets drawn by Odin will be validated deeply, such that their members are scanned, and all other components and assets are only validated directly on the root objects, without their members being scanned. Enabling this will *significantly* increase validation times and is very unlikely to catch more issues.";

            // Session
            //expandSessionSettings.Value = ValidatorGui.Foldout(expandSessionSettings.Value, this.ValidationSession.Name);
            //if (SirenixEditorGUI.BeginFadeGroup(expandSessionSettings, expandSessionSettings.Value))
            //{
            //    this.ValidationSession.Runner.Config.DeepValidation = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Deep validations", DeepValidationTooltip), this.ValidationSession.Runner.Config.DeepValidation);
            //}
            //SirenixEditorGUI.EndFadeGroup();

            // Validation
            expandValidationSettings.Value = ValidatorGui.Foldout(expandValidationSettings.Value, "Validation");
            if (SirenixEditorGUI.BeginFadeGroup(expandValidationSettings, expandValidationSettings.Value))
            {
                EditorGUI.BeginChangeCheck();
                GlobalValidationConfig.DeepValidation.Value = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Deep validations", DeepValidationTooltip), GlobalValidationConfig.DeepValidation.Value);
                if (EditorGUI.EndChangeCheck())
                {
                    ValidationRunnerConfig.Default.DeepValidation = GlobalValidationConfig.DeepValidation.Value;
                }

                GlobalValidationConfig.EnableOnLoad.Value = EditorGUI.ToggleLeft(GetRect(), "Enable validator on load", GlobalValidationConfig.EnableOnLoad.Value);
                GUIHelper.PushGUIEnabled(GlobalValidationConfig.EnableOnLoad.Value);
                GlobalValidationConfig.ValidateOnLoad.Value = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Validate On Load", "Start a full background validation on load, as if you'd clicked the Validate button. May cause slight occasional stutter if the validation includes large assets to load."), GlobalValidationConfig.ValidateOnLoad.Value);
                GUIHelper.PopGUIEnabled();
                GlobalValidationConfig.ContinuouslyValidateVisibleIssues.Value = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Continuously validate visible issues", "Issues visible in the issue list will be continuously revalidated all the time."), GlobalValidationConfig.ContinuouslyValidateVisibleIssues.Value);
                GlobalValidationConfig.PauseValidationWhileWorkingInSceneView.Value = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Pause Validation While Working In Scene View", "Validation will be paused while you are actively working in the scene view, to prevent perceptible stutter during user input."), GlobalValidationConfig.PauseValidationWhileWorkingInSceneView.Value);

                //GlobalValidationConfig.ValidateAssetLoadEvents.Value = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Validate Asset Load Events", "Assets that are loaded, moved or otherwise changed will be (re)validated if watching is enabled."), GlobalValidationConfig.ValidateAssetLoadEvents.Value);
                //GlobalValidationConfig.ValidateSceneObjectLoadEvents.Value = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Validate Scene Object Load Events", "The contents of scenes that are loaded will be queued for validation if watching is enabled."), GlobalValidationConfig.ValidateSceneObjectLoadEvents.Value);
            }
            SirenixEditorGUI.EndFadeGroup();

            // Validator window
            expandWindowSettings.Value = ValidatorGui.Foldout(expandWindowSettings.Value, "Validator Window");
            if (SirenixEditorGUI.BeginFadeGroup(expandWindowSettings, expandWindowSettings.Value))
            {
                GlobalValidationConfig.PingOnDoubleClick.Value = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Ping Object On Double Click", "Ping objects when they are double-clicked in the result view."), GlobalValidationConfig.PingOnDoubleClick);
                GlobalValidationConfig.FocusObjectOnDoubleClick.Value = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Frame Object On Double Click", "Move to the camera to scene objects when they are double-clicked in the result view."), GlobalValidationConfig.FocusObjectOnDoubleClick);
                GlobalValidationConfig.FrameSelection.Value = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Frame Selection", "Move the camera to view all scene objects that are selected in the result view."), GlobalValidationConfig.FrameSelection);
                GlobalValidationConfig.OpenComponentInInspectorAndCloseOthers.Value = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Open Component In Inspector And Close Others", "Open the component in the inspector containing the error selected in the result view, and close all other components. NOTE: this setting may cause lag when selecting results in some versions of Unity."), GlobalValidationConfig.OpenComponentInInspectorAndCloseOthers);

                GlobalValidationConfig.DebugMode.Value =
                    EditorGUI.ToggleLeft(GetRect(), new GUIContent("Debug Mode", "Shows advanced info data and enables error reporting during fixes."), GlobalValidationConfig.DebugMode.Value);

                GlobalValidationConfig.ShowFeedbackButton.Value =
                    EditorGUI.ToggleLeft(GetRect(), new GUIContent("Show Feedback Button"), GlobalValidationConfig.ShowFeedbackButton.Value);
            }
            SirenixEditorGUI.EndFadeGroup();

            // Sesssion
            expandSessionSettings.Value = ValidatorGui.Foldout(expandSessionSettings.Value, "Validation");
            if (SirenixEditorGUI.BeginFadeGroup(expandSessionSettings, expandSessionSettings.Value))
            {
                var isValidatingInBackground = this.ValidationSession.IsValidatingInBackground;
                var isWatching = this.ValidationSession.IsWatching;

                if (!isWatching || !isValidatingInBackground)
                {
                    SirenixEditorGUI.MessageBox("The validator will not work properly with either of the settings below turned off.", MessageType.Warning);
                }

                isWatching = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Watch for changes", "With watching turned off, the validator won't be able to discover when values changes and issues gets fixed."), isWatching);
                isValidatingInBackground = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Validate in background"), isValidatingInBackground);

                if (this.ValidationSession.IsWatching != isWatching)
                {
                    if (isWatching)
                        this.ValidationSession.StartSession(true, false);
                    else
                        this.ValidationSession.StopSession(true, false);
                }

                if (this.ValidationSession.IsValidatingInBackground != isValidatingInBackground)
                {
                    if (isValidatingInBackground)
                        this.ValidationSession.StartSession(true, false);
                    else
                        this.ValidationSession.StopSession(true, false);
                }
            }
            SirenixEditorGUI.EndFadeGroup();


            // Scene widget
            expandWidgetSettings.Value = ValidatorGui.Foldout(expandWidgetSettings.Value, "Scene Widget");
            if (SirenixEditorGUI.BeginFadeGroup(expandWidgetSettings, expandWidgetSettings.Value))
            {
                EditorGUI.BeginChangeCheck();
                GlobalValidationConfig.ShowWidget.Value = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Shown"), GlobalValidationConfig.ShowWidget.Value);
                GUIHelper.PushGUIEnabled(GlobalValidationConfig.ShowWidget.Value);
                GlobalValidationConfig.ShowWidgetOnlyWhenErrorOrWarnings.Value = EditorGUI.ToggleLeft(GetRect(), new GUIContent("Only show widget when results are found"), GlobalValidationConfig.ShowWidgetOnlyWhenErrorOrWarnings.Value);
                GlobalValidationConfig.WidgetAnchor.Value = EnumSelector<SceneValidationWidget.WidgetAnchor>.DrawEnumField(GetRect(), new GUIContent("Anchor"), GlobalValidationConfig.WidgetAnchor.Value);
                GlobalValidationConfig.WidgetOffsetX.Value = EditorGUI.FloatField(GetRect(), new GUIContent("Offset X"), GlobalValidationConfig.WidgetOffsetX.Value);
                GlobalValidationConfig.WidgetOffsetY.Value = EditorGUI.FloatField(GetRect(), new GUIContent("Offset Y"), GlobalValidationConfig.WidgetOffsetY.Value);
                GUIHelper.PopGUIEnabled();
                if (EditorGUI.EndChangeCheck())
                {
                    SceneView.RepaintAll();
                }
            }
            SirenixEditorGUI.EndFadeGroup();

        }

        private Rect GetRect() => GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight).AlignCenterY(EditorGUIUtility.singleLineHeight).HorizontalPadding(ValidatorGui.ContentPadding);

        private void DrawProfiler()
        {
            GUIHelper.RequestRepaint();
            var tasks = BackgroundTaskRunner.AllTasks;
            var total = BackgroundTaskRunner.TotalWorkLastTickMs;
            var max = 6;
            var tMax = Mathf.Clamp01(total / max);
            var tUser = total / BackgroundTaskRunner.MaxBackgroundTaskMSPerFrame;

            // Tick time
            {

                this.expandProfilerTickTime.Value = ValidatorGui.Foldout(this.expandProfilerTickTime.Value, "Max tick time");
                if (SirenixEditorGUI.BeginFadeGroup(this.expandProfilerTickTime, this.expandProfilerTickTime.Value))
                {
                    GUILayout.BeginVertical(padding);
                    SirenixEditorGUI.MessageBox(
                        "Odin Validator is using a slice of CPU time every frame when validation is toggled on. " +
                        "Here you can monitor how much time it is spending every frame, and adjust how much time it is allowed to spend.");

                    GUILayout.Space(10);

                    // Draw slide rect
                    var slideRect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight);
                    EditorGUI.DrawRect(slideRect, ValidatorGui.BorderColor);
                    EditorGUI.DrawRect(slideRect.AlignLeft(slideRect.width * tMax).Padding(1), ValidatorGui.Green);

                    tMax = BackgroundTaskRunner.MaxBackgroundTaskMSPerFrame.Value / max;
                    var r = slideRect.AlignLeft(slideRect.width * tMax).AlignRight(2);
                    EditorGUI.DrawRect(r, Color.white);
                    EditorGUI.DrawRect(r.AlignTop(1).AlignRight(5), Color.white);
                    EditorGUI.DrawRect(r.AlignBottom(1).AlignRight(5), Color.white);

                    GUI.Label(r.AddX(7).AlignLeft(200), "Max " + BackgroundTaskRunner.MaxBackgroundTaskMSPerFrame.Value.ToString("0.00") + " ms", SirenixGUIStyles.LeftAlignedWhiteMiniLabel);

                    GUIHelper.PushColor(new Color(1, 1, 1, 0.8f));
                    GUI.Label(slideRect.HorizontalPadding(0, 10), total.ToString("0.00") + " ms", SirenixGUIStyles.LeftAlignedWhiteMiniLabel);
                    GUIHelper.PopColor();
                    BackgroundTaskRunner.MaxBackgroundTaskMSPerFrame.Value = ValidatorGui.SlideRect(slideRect, BackgroundTaskRunner.MaxBackgroundTaskMSPerFrame.Value, 0.2f, max);
                    GUILayout.EndVertical();
                }
                SirenixEditorGUI.EndFadeGroup();

            }

            // Breakdown
            {
                this.expandProfilerBreakdown.Value = ValidatorGui.Foldout(this.expandProfilerBreakdown.Value, "Breakdown");
                if (SirenixEditorGUI.BeginFadeGroup(this.expandProfilerBreakdown, this.expandProfilerBreakdown.Value))
                {
                    var mul = Mathf.Clamp(tUser, 0, 1);

                    normalize = EditorGUI.ToggleLeft(GetRect(), "Normalize", normalize);

                    if (normalize)
                    {
                        mul = 1;
                    }

                    GUILayout.BeginVertical(padding);
                    for (int i = 0; i < tasks.Count; i++)
                    {
                        if (i != 0)
                        {
                            GUILayout.Space(10);
                        }

                        BackgroundTaskHandle item = tasks[i];
                        var state = item.CurrentState;
                        Color forColor;
                        Color backColor = ValidatorGui.BorderColor;

                        if (state == BackgroundTaskHandle.State.Paused) forColor = Color.grey;
                        else if (state == BackgroundTaskHandle.State.Running) forColor = ValidatorGui.DarkRed;
                        else if (state == BackgroundTaskHandle.State.Killed) forColor = Color.red;
                        else if (state == BackgroundTaskHandle.State.Relaxed) forColor = ValidatorGui.BtnActiveBgColor;
                        else forColor = Color.white;

                        var rect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight);
                        var labelRect = rect;
                        var progressBarRect = rect;

                        if (state == BackgroundTaskHandle.State.Paused || state == BackgroundTaskHandle.State.Killed)
                        {
                            backColor.a *= 0.5f;
                            EditorGUI.DrawRect(progressBarRect, backColor);
                        }
                        else
                        {
                            EditorGUI.DrawRect(progressBarRect, backColor);
                            EditorGUI.DrawRect(progressBarRect.Padding(1).AlignLeft(progressBarRect.width * (float)item.WorkWeight * mul), forColor);
                        }

                        GUI.Label(labelRect, item.Name, SirenixGUIStyles.MiniLabelCentered);
                    }
                    GUILayout.EndVertical();
                }
                SirenixEditorGUI.EndFadeGroup();
            }

            // Current Session
            {
                this.expandProfilerCurrentSession.Value = ValidatorGui.Foldout(this.expandProfilerCurrentSession.Value, "Current session");
                if (SirenixEditorGUI.BeginFadeGroup(this.expandProfilerCurrentSession, this.expandProfilerCurrentSession.Value))
                {
                    GUILayout.BeginVertical(padding);
                    EditorGUILayout.LabelField("Name", this.ValidationSession.Name);
                    EditorGUILayout.LabelField("Work queue", this.ValidationSession.WorkQueue.Count + "");
                    EditorGUILayout.LabelField("Work done", this.ValidationSession.WorkDone.Count + "");
                    EditorGUILayout.LabelField("Remaining work", this.ValidationSession.RemainingWorkCountSample + "");
                    EditorGUILayout.LabelField("Work done", this.ValidationSession.RemainingWorkCountSample + "");

                    var prevWorkItem = this.ValidationSession.prevProcessedWorkItem;
                    var currWorkItem = this.ValidationSession.currentlyProcessingWorkItem;
                    var nextWorkItem = this.ValidationSession.WorkQueue.Count > 0 ? this.ValidationSession.WorkQueue.PeekMaybeInvalid() : default;

                    DrawWorkItem(prevWorkItem, "Previous Work Item");
                    DrawWorkItem(currWorkItem.HasValue ? currWorkItem.Value : default, "Current Work Item");
                    DrawWorkItem(nextWorkItem, "Next Work Item");
                    GUILayout.EndVertical();
                }
                SirenixEditorGUI.EndFadeGroup();
            }

            // Validator Timings
            //{
            //    this.expandProfilerTimings.Value = ValidatorGui.Foldout(this.expandProfilerTimings.Value, "Validator Timings");
            //    if (SirenixEditorGUI.BeginFadeGroup(this.expandProfilerTimings, this.expandProfilerTimings.Value))
            //    {
            //        GUILayout.BeginVertical(padding);
            //        GlobalValidationConfig.SkipFirstSample.Value = EditorGUILayout.ToggleLeft(new GUIContent("Skip first sample", "Skip the first timing sample for each validator. This will ensure the first-time JIT compilation overhead is not counted for each validator."), GlobalValidationConfig.SkipFirstSample.Value);

            //        if (GUILayout.Button("Clear"))
            //        {
            //            this.timings.Reset();
            //        }

            //        var titlesRect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight);
            //        var sampleId = titlesRect.TakeFromLeft(20);
            //        var timingLabelRect = titlesRect.TakeFromRight(80);
            //        titlesRect.TakeFromRight(ValidatorGui.ContentPadding);
            //        var sampleCountLabelRect = titlesRect.TakeFromRight(80);
            //        var maxAvgTime = 0.00001;

            //        if (GUI.Button(sampleId, EditorIcons.Timer.Highlighted))
            //        {
            //            this.timings.Samples = this.timings.Samples.OrderByDescending(x => x.sampler.GlobalSampleIndex).ToList();
            //        }
            //        if (GUI.Button(titlesRect, "Validator type"))
            //        {
            //            this.timings.Samples = this.timings.Samples.OrderByDescending(x => x.type.Name).ToList();
            //        }
            //        if (GUI.Button(sampleCountLabelRect, "Samples"))
            //        {
            //            this.timings.Samples = this.timings.Samples.OrderByDescending(x => x.sampler.SampleCount).ToList();
            //        }
            //        if (GUI.Button(timingLabelRect, "Avg time"))
            //        {
            //            this.timings.Samples = this.timings.Samples.OrderByDescending(x => x.sampler.SampleAverage).ToList();
            //        }

            //        if (Event.current.type == EventType.Repaint)
            //        {
            //            foreach (var item in this.timings.Samples)
            //            {
            //                if (item.sampler.SampleCount == 0)
            //                    continue;
            //                maxAvgTime = Math.Max(maxAvgTime, item.sampler.SampleAverage);
            //            }
            //        }

            //        foreach (var item in this.timings.Samples)
            //        {
            //            if (item.sampler.SampleCount == 0 || item.type == typeof(NoValidator))
            //                continue;

            //            var labelRect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight);
            //            if (Event.current.type == EventType.Repaint)
            //            {
            //                labelRect.y += 2;
            //                labelRect.height -= 4;
            //                var timingRect = labelRect.TakeFromRight(80);
            //                labelRect.TakeFromRight(ValidatorGui.ContentPadding);
            //                var sampleCountRect = labelRect.TakeFromRight(80);

            //                var name = item.type.GetNiceName();
            //                var time = item.sampler.SampleAverage;
            //                var timeT = (float)(time / maxAvgTime);

            //                var col = Color.Lerp(ValidatorGui.Green, ValidatorGui.DarkRed, timeT);
            //                var backColor = new Color(0, 0, 0, 0.8f);
            //                GUI.Label(labelRect.AlignCenterY(EditorGUIUtility.singleLineHeight), name);
            //                EditorGUI.DrawRect(timingRect, backColor);
            //                EditorGUI.DrawRect(timingRect.AlignLeft(timingRect.width * timeT), col);

            //                GUI.Label(timingRect, time.ToString("F4") + " ms", SirenixGUIStyles.CenteredWhiteMiniLabel);
            //                GUI.Label(sampleCountRect, item.sampler.SampleCount + " ");
            //            }
            //        }
            //        GUILayout.EndVertical();
            //    }
            //    SirenixEditorGUI.EndFadeGroup();
            //}

            // Project Events

            {
                this.expandProfilerEvents.Value = ValidatorGui.Foldout(this.expandProfilerEvents.Value, "Project Watcher");

                if (SirenixEditorGUI.BeginFadeGroup(this.expandProfilerEvents, this.expandProfilerEvents.Value))
                {
                    GUILayout.BeginVertical(padding);
                    for (int i = 0; i < ProjectWatcher.latestEvents.Length; i++)
                    {
                        var e = ProjectWatcher.latestEvents[i];
                        var titlesRect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight);

                        GUI.Label(titlesRect, (ProjectWatcher.latestEvents.Position - i) + " : " + e.Type + " : " + e);
                    }
                    GUILayout.EndVertical();
                }

                SirenixEditorGUI.EndFadeGroup();
            }
        }

        private static void DrawWorkItem(ValidationWorkItem workItem, string label)
        {
            var isValid = workItem.IsValid();
            EditorGUILayout.LabelField(label, isValid ? workItem.ToNiceString() : "-");
            if (!isValid) GUIHelper.PushGUIEnabled(false);

            EditorGUILayout.LabelField("   Asset Guid", String.IsNullOrEmpty(workItem.AssetGuid) ? "-" : workItem.AssetGuid);
            EditorGUILayout.LabelField("   Asset Path", String.IsNullOrEmpty(workItem.AssetGuid) ? "-" : AssetDatabase.GUIDToAssetPath(workItem.AssetGuid));
            EditorGUILayout.LabelField("   InstanceId", (workItem.InstanceID == 0 ? "-" : workItem.InstanceID.ToString()));
            EditorGUILayout.LabelField("   Non Unity Object:", workItem.NonUnityObjectValue == null ? "-" : "Provided");
            EditorGUILayout.LabelField("   Scene Content", workItem.SceneContent.HasValue ? workItem.SceneContent.Value.Name : "-");
            EditorGUILayout.LabelField("   Scene Validators", workItem.SceneValidators.HasValue ? workItem.SceneValidators.Value.Name : "-");

            if (!isValid) GUIHelper.PopGUIEnabled();
        }


        private void DrawRules(Rect rect)
        {
            this.showTip = "There are currently very few built-in rules implemented in this preview build. Far more built-in rules are coming soon! Please use the feedback form to suggest default rules that would be useful to have included out of the box.";

            {
                var toolbarRect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight);
                EditorGUI.DrawRect(toolbarRect.TakeFromBottom(1), ValidatorGui.BorderColor);
                var projectRect = toolbarRect.TakeFromLeft(toolbarRect.width * 0.5F);

                EditorGUI.DrawRect(toolbarRect.TakeFromLeft(1), ValidatorGui.BorderColor);
                var localRect = toolbarRect;

                if (ValidatorGui.ToolbarBtn(projectRect, selectedRuleSrc.Value == ConfigSourceType.Project, SdfIconType.PeopleFill, $"Project Rules", "Rules shared with your team"))
                    this.selectedRuleSrc.Value = ConfigSourceType.Project;

                if (ValidatorGui.ToolbarBtn(localRect, selectedRuleSrc.Value == ConfigSourceType.Local, SdfIconType.PersonFill, $"Local Rules", "Rules local only for you"))
                    this.selectedRuleSrc.Value = ConfigSourceType.Local;
            }

            {
                var toolbarRect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight);
                var addRect = toolbarRect.TakeFromRight(toolbarRect.height); toolbarRect.TakeFromRight(1);
                var exRect = toolbarRect.TakeFromRight(toolbarRect.height); toolbarRect.TakeFromRight(1);
                ValidatorGui.Header(toolbarRect, "All rules", null);

                if (DrawToolbarButton(addRect, SdfIconType.Plus, "Create new custom rule or validator"))
                {
                    var menu = new GenericMenu();
                    ValidatorScriptTemplates.AddTemplateScriptCreationToGenericMenu(menu);
                    menu.ShowAsContext();
                }

                if (DrawToolbarButton(exRect, SdfIconType.ArrowCounterclockwise, "Reset to default"))
                {
                    if (EditorUtility.DisplayDialog("Reset rules?", "This will reset all your rules to their default settings. All current rule data config will be lost.", "Ok", "Cancel"))
                    {
                        foreach (var item in this.rules.Rules)
                        {
                            if (this.selectedRuleSrc.Value == ConfigSourceType.Project)
                                item.Project = null;

                            if (this.selectedRuleSrc.Value == ConfigSourceType.Local)
                                item.Local = null;
                        }
                        this.rules.SaveChanges();
                    }

                    GUIUtility.ExitGUI();
                }
            }

            // this.expandProjectRules.Value = ValidatorGUI.Foldout(this.expandProjectRules.Value, "Project Rules");

            var allRules = this.rules.Rules;

            EditorGUI.BeginChangeCheck();

            foreach (var rule in allRules)
            {
                var itemRect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight).AlignCenterY(EditorGUIUtility.singleLineHeight);
                var isEnabledOverriddenInCurrent = rule.IsEnabledOverriddenIn(this.selectedRuleSrc.Value);
                var overriddenInCurrent = rule.EnabledOverrideState == this.selectedRuleSrc.Value;
                var isCurrentProjectAndEnabledOverridenInLocal = this.selectedRuleSrc.Value == ConfigSourceType.Project && rule.EnabledOverrideState == ConfigSourceType.Local;
                var serializedRule = rule.GetSerializedRule(this.selectedRuleSrc.Value);
                var hasDataOverride = rule.IsDataOverriddenIn(this.selectedRuleSrc.Value) || isEnabledOverriddenInCurrent;

                if (Event.current.OnContextClick(itemRect))
                {
                    var localRule = rule;
                    var menu = new GenericMenu();

                    if (isEnabledOverriddenInCurrent)
                    {
                        menu.AddItem(new GUIContent("Reset enabled"), false, () =>
                        {
                            serializedRule.DataOverride = null;
                            serializedRule.EnabledOverridden = false;
                        });
                    }
                    else
                    {
                        menu.AddDisabledItem(new GUIContent("Reset enabled"));
                    }

                    if (serializedRule?.DataOverride != null)
                    {
                        menu.AddItem(new GUIContent("Reset config"), false, () =>
                        {
                            serializedRule.DataOverride = null;
                        });
                    }
                    else
                    {
                        menu.AddDisabledItem(new GUIContent("Reset config"));
                    }

                    menu.ShowAsContext();
                }

                itemRect.TakeFromLeft(ValidatorGui.ContentPadding);
                if (ValidatorGui.IconButton(itemRect.TakeFromRight(itemRect.height), SdfIconType.GearFill, "Configure"))
                {
                    var localSetting = this.selectedRuleSrc.Value;
                    var data = rule.GetOverrideDataOrDefaultCopy(localSetting);
                    OdinEditorWindow wnd = null;
                    var localRule = rule;

                    wnd = OdinEditorWindow.InspectObject(new RuleDataDrawer(rule.Name, data, () =>
                    {
                        localRule.SetOverrideData(localSetting, data);
                        this.rules.SaveChanges();
                        wnd.Close();
                    }));

                    wnd.titleContent = new GUIContent(rule.Name);
                    wnd.WindowPadding = new Vector4(0, 0, 0, 0);
                }
                itemRect.TakeFromRight(ValidatorGui.ContentPadding);

                GUIHelper.PushColor(new Color(1, 1, 1, isCurrentProjectAndEnabledOverridenInLocal ? 0.5f : 1));

                if (hasDataOverride)
                {
                    GUIHelper.PushIsBoldLabel(hasDataOverride);
                    serializedRule.Enabled = EditorGUI.ToggleLeft(itemRect, new GUIContent(rule.Name, isCurrentProjectAndEnabledOverridenInLocal ? "Rule is overriden by local changes on this machine." : rule.Description), serializedRule.Enabled);
                    GUIHelper.PopIsBoldLabel();
                }
                else
                {
                    var enabled = rule.IsEnabledIn(this.selectedRuleSrc.Value | ConfigSourceType.Default);
                    if (enabled != EditorGUI.ToggleLeft(itemRect, new GUIContent(rule.Name, rule.Description), enabled))
                    {
                        enabled = !enabled;
                        rule.SetEnabledOverrideState(this.selectedRuleSrc, enabled);
                    };
                }
                GUIHelper.PopColor();
            }

            GUILayout.FlexibleSpace();

            if (EditorGUI.EndChangeCheck())
            {
                this.rules.SaveChanges();
            }
        }

        private class SessionConfigDataDrawer
        {
            [HideInInspector] public ValidationSession Session;
            [HideInInspector] public IList<ISessionConfigData> DataSources;
            [HideInInspector] public EditorPrefInt SelectedConfigSource;

            private int selectedConfigSourceFallback;

            private int SelectedConfig
            {
                get
                {
                    if (this.SelectedConfigSource == null)
                        return this.selectedConfigSourceFallback;

                    return this.SelectedConfigSource.Value;
                }
                set
                {
                    if (this.SelectedConfigSource == null)
                        this.selectedConfigSourceFallback = value;
                    else
                        this.SelectedConfigSource.Value = value;
                }
            }

            [OnInspectorGUI, PropertyOrder(-1)]
            public void Draw()
            {
                if (this.DataSources.Count == 0)
                {
                    GUILayout.Label("No config is specified for this session.");
                    return;
                }

                // Toolbar
                {
                    if (this.DataSources.Count > 1)
                    {
                        var toolbarRect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight);
                        var width = toolbarRect.width / this.DataSources.Count;

                        for (int i = 0; i < this.DataSources.Count; i++)
                        {
                            var btnRect = toolbarRect.TakeFromLeft(width);
                            if (i != this.DataSources.Count - 1)
                            {
                                EditorGUI.DrawRect(btnRect.TakeFromRight(1), ValidatorGui.BorderColor);
                            }
                            var s = this.DataSources[i];
                            if (ValidatorGui.ToolbarBtn(btnRect, this.SelectedConfig == i, s.Icon, s.Name, s.Description))
                            {
                                this.SelectedConfig = i;
                            }
                        }
                    }
                    else
                    {
                        this.SelectedConfig = 0;
                    }
                }

                if (this.SelectedConfig >= this.DataSources.Count)
                    this.SelectedConfig = 0;

                var source = this.DataSources[this.SelectedConfig];

                EditorGUI.BeginChangeCheck();
                {
                    DrawFilterAssetsGroup(source, "Scenes", EditorIcons.UnityLogo, ValidationItem.ValidationItemType.Scene, dst =>
                    {
                        SelectScenePopup(dst.Add, null);
                    });

                    DrawFilterAssetsGroup(source, "Assets", EditorIcons.UnityFolderIcon, ValidationItem.ValidationItemType.Asset, dst =>
                    {
                        EditorWindow wnd = null;
                        var selector = new AssetSelector(x =>
                        {
                            dst.Add(ValidationItem.FromAssetPath(x.Path, x.Filter));
                            wnd.Close();
                            source.SaveChanges();
                        });
                        wnd = OdinEditorWindow.InspectObjectInDropDown(selector, 400);
                    });

                    DrawFilterAssetsGroup(source, "Asset Bundles", EditorIcons.UnityLogo, ValidationItem.ValidationItemType.AssetBundle, dst =>
                    {
                        var names = AssetDatabase.GetAllAssetBundleNames();
                        var existingNames = dst.Where(x => x.Type == ValidationItem.ValidationItemType.AssetBundle).Select(x => x.AssetBundle).ToList();
                        var selector = new GenericSelector<string>(existingNames.Concat(names).Distinct());
                        selector.SetSelection(existingNames);
                        selector.SelectionConfirmed += newSelection =>
                        {
                            // We need to preserve old items when they already exist
                            var newItems = newSelection.Select(bundle =>
                            {
                                foreach (var entry in dst)
                                {
                                    if (entry.Type == ValidationItem.ValidationItemType.AssetBundle && entry.AssetBundle == bundle)
                                    {
                                        return entry;
                                    }
                                }

                                return ValidationItem.FromAssetBundle(bundle);
                            }).ToList();

                            for (int i = dst.Count - 1; i >= 0; i--)
                            {
                                if (dst[i].Type == ValidationItem.ValidationItemType.AssetBundle)
                                {
                                    dst.RemoveAt(i);
                                }
                            }

                            dst.AddRange(newItems);
                            source.SaveChanges();
                        };
                        selector.ShowInPopup(400);
                    });

                    GUIHelper.PushGUIEnabled(AddressablesUtility.AddressablesAvailable && GUI.enabled);
                    DrawFilterAssetsGroup(source, "Addressable Groups", EditorIcons.UnityLogo, ValidationItem.ValidationItemType.AddressableGroup, dst =>
                    {
                        var names = AddressablesUtility.GetAddressableGroupNames();
                        var existingNames = dst.Where(x => x.Type == ValidationItem.ValidationItemType.AddressableGroup).Select(x => x.AddressableGroup).ToList();
                        var selector = new GenericSelector<string>(existingNames.Concat(names).Distinct());
                        selector.SetSelection(existingNames);
                        selector.SelectionConfirmed += newSelection =>
                        {
                            // We need to preserve old items when they already exist
                            var newItems = newSelection.Select(group =>
                            {
                                foreach (var entry in dst)
                                {
                                    if (entry.Type == ValidationItem.ValidationItemType.AddressableGroup && entry.AddressableGroup == group)
                                    {
                                        return entry;
                                    }
                                }

                                return ValidationItem.FromAddressableGroup(group);
                            }).ToList();

                            for (int i = dst.Count - 1; i >= 0; i--)
                            {
                                if (dst[i].Type == ValidationItem.ValidationItemType.AddressableGroup)
                                {
                                    dst.RemoveAt(i);
                                }
                            }

                            dst.AddRange(newItems);

                            source.SaveChanges();
                        };
                        selector.ShowInPopup(400);
                    });
                    GUIHelper.PopGUIEnabled();

                    //DrawFilterAssetsGroup(source, "Object References", EditorIcons.UnityLogo, ValidationItem.ValidationItemType.Object, dst =>
                    //{
                    //    var objs = dst.Where(n => n.Type == ValidationItem.ValidationItemType.Object && n.Object != null).Select(n => n.Object).ToList();
                    //    var list = new UnityObjectList()
                    //    { 
                    //        ObjectsToScan = objs,
                    //    };

                    //    var window = OdinEditorWindow.InspectObject(list);

                    //    list.OnSave = () =>
                    //    {
                    //        window.Close();

                    //        // We need to preserve old items when they already exist
                    //        var newItems = list.ObjectsToScan.Select(obj =>
                    //        {
                    //            foreach (var entry in dst)
                    //            {
                    //                if (entry.Type == ValidationItem.ValidationItemType.Object && entry.Object == obj)
                    //                {
                    //                    return entry;
                    //                }
                    //            }

                    //            return ValidationItem.FromUnityObjectReference(obj);
                    //        }).ToList();

                    //        for (int i = dst.Count - 1; i >= 0; i--)
                    //        {
                    //            if (dst[i].Type == ValidationItem.ValidationItemType.Object)
                    //            {
                    //                dst.RemoveAt(i);
                    //            }
                    //        }

                    //        dst.AddRange(newItems);
                    //    };
                    //});
                }

                if (EditorGUI.EndChangeCheck())
                {
                    source.SaveChanges();
                    this.Session.Config.MarkDirty();
                }
            }

            private class UnityObjectList
            {
                [AssetsOnly, OnValueChanged("@ObjectsToScan = ObjectsToScan ?? new List<UnityEngine.Object>()")]
                public List<UnityEngine.Object> ObjectsToScan;

                [HideInInspector]
                public Action OnSave;

                [Button]
                public void Save()
                {
                    this.OnSave?.Invoke();
                }
            }

            [OnInspectorGUI, PropertyOrder(-2)]
            void DrawHeader()
            {
                ValidatorGui.Header("Configuration");
            }

            private void DrawFilterAssetsGroup(ISessionConfigData source, string headerText, Texture2D headerIcon, ValidationItem.ValidationItemType vType, Action<IList<ValidationItem>> select)
            {
                var includeCount = 0;
                var excludeCount = 0;

                foreach (var item in source.Include)
                    if (item.Type == vType)
                        includeCount++;

                foreach (var item in source.Exclude)
                    if (item.Type == vType)
                        excludeCount++;

                {
                    var rect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight);
                    var addRect = rect.TakeFromRight(rect.height); rect.TakeFromRight(1);
                    var exRect = rect.TakeFromRight(rect.height); rect.TakeFromRight(1);

                    ValidatorGui.Header(rect, headerText, headerIcon);

                    if (DrawToolbarButton(addRect, SdfIconType.Plus, "Add include"))
                    {
                        select(source.Include);
                    }

                    if (DrawToolbarButton(exRect, SdfIconType.SlashCircle, "Add exclude"))
                    {
                        select(source.Exclude);
                    }
                }

                if (includeCount > 0 && excludeCount > 0)
                {
                    GUI.Label(GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight).HorizontalPadding(3), "Included", ValidatorGui.LabelLowerCenterBold);
                }

                DrawValidationItems(source.Include, vType);

                if (excludeCount > 0)
                {
                    GUI.Label(GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight).HorizontalPadding(3), "Excluded", ValidatorGui.LabelLowerCenterBold);
                    DrawValidationItems(source.Exclude, vType);
                }
            }

            private static void DrawValidationItems(IList<ValidationItem> items, ValidationItem.ValidationItemType type)
            {
                var monoBehaviourIcon = GUIHelper.GetAssetThumbnail(null, typeof(MonoBehaviour), false);
                var sceneIcon = GUIHelper.GetAssetThumbnail(null, typeof(SceneAsset), false);
                var fileIcon = GUIHelper.GetAssetThumbnail(null, typeof(UnityEngine.Object), false);

                for (int i = 0; i < items.Count; i++)
                {
                    var item = items[i];
                    if (item.Type != type) continue;

                    var rect = GUILayoutUtility.GetRect(0, ValidatorGui.LineHeight);
                    var contentRect = rect.HorizontalPadding(ValidatorGui.ContentPadding, 0).AlignCenterY(EditorGUIUtility.singleLineHeight);
                    var toggleRect = contentRect.TakeFromLeft(contentRect.height);
                    var iconRect = contentRect.TakeFromLeft(contentRect.height).AlignCenter(16, 16);
                    var deleteRect = contentRect.TakeFromRight(rect.height).AlignCenterY(rect.height - ValidatorGui.ContentPadding);
                    contentRect.TakeFromRight(1);
                    var editRect = contentRect.TakeFromRight(rect.height).AlignCenterY(rect.height - ValidatorGui.ContentPadding);
                    var labelRect = contentRect;
                    var label = (string)null;
                    var suffix = (string)null;
                    var icon = (Texture)null;

                    var isSpecialReadonlyItem = item.Scene.Type == ValidationItem.SceneIncludeType.OpenScenes || item.Scene.Type == ValidationItem.SceneIncludeType.ScenesInBuildOptions;
                    if (!isSpecialReadonlyItem)
                    {
                        if (ValidatorGui.IconButton(deleteRect, SdfIconType.X, null))
                        {
                            items.RemoveAt(i);
                            i--;
                            break;
                        }

                        if (ValidatorGui.IconButton(editRect, SdfIconType.PencilFill, null))
                        {
                            if (item.Type == ValidationItem.ValidationItemType.Asset)
                            {
                                EditorWindow wnd = null;
                                var toReplace = i;
                                var selector = new AssetSelector(x =>
                                {
                                    items[toReplace] = ValidationItem.FromAssetPath(x.Path, x.Filter);
                                    wnd.Close();
                                });
                                selector.Path = item.Asset.Path;
                                selector.Filter = item.Asset.Filter;
                                wnd = OdinEditorWindow.InspectObjectInDropDown(selector, editRect, 400);
                            }
                            else if (item.Type == ValidationItem.ValidationItemType.Scene)
                            {
                                var toReplace = i;
                                SelectScenePopup(x => items[toReplace] = x, items[toReplace].Scene.Value);
                            }
                        }
                    }

                    if (item.Type == ValidationItem.ValidationItemType.Asset)
                    {
                        label = item.Asset.Path;
                        suffix = item.Asset.Filter;

                        var isFile = item.Asset.Path.LastIndexOf('.') > item.Asset.Path.LastIndexOf('/');
                        icon = isFile ? fileIcon : EditorIcons.UnityFolderIcon;

                        if (!isFile)
                            label = label + "/*";
                    }
                    else if (item.Type == ValidationItem.ValidationItemType.AddressableGroup)
                    {
                        label = item.AddressableGroup;
                        icon = monoBehaviourIcon;
                    }
                    else if (item.Type == ValidationItem.ValidationItemType.AssetBundle)
                    {
                        label = item.AssetBundle;
                        icon = monoBehaviourIcon;
                    }
                    else if (item.Type == ValidationItem.ValidationItemType.Scene)
                    {
                        if (item.Scene.Type == ValidationItem.SceneIncludeType.OpenScenes)
                        {
                            label = "Open Scenes";
                            icon = sceneIcon;
                        }
                        else if (item.Scene.Type == ValidationItem.SceneIncludeType.SceneGuid)
                        {
                            label = new SceneReference(item.Scene.Value).Name + ".unity";
                            icon = sceneIcon;
                        }
                        else if (item.Scene.Type == ValidationItem.SceneIncludeType.ScenesInBuildOptions)
                        {
                            label = "Scenes in build options";
                            icon = sceneIcon;
                        }
                        else if (item.Scene.Type == ValidationItem.SceneIncludeType.ScenesInFolder)
                        {
                            label = item.Scene.Value + "/*";
                            icon = EditorIcons.UnityFolderIcon;
                        }
                        else
                        {
                            throw new NotImplementedException(item.Scene.Type.ToString());
                        }
                    }
                    else if (item.Type == ValidationItem.ValidationItemType.Object)
                    {
                        label = item.Object.ToString();
                        icon = GUIHelper.GetAssetThumbnail(item.Object, null, false);
                    }
                    else
                    {
                        throw new NotImplementedException(item.Type.ToString());
                    }

                    if (Event.current.type == EventType.Repaint)
                    {
                        if (suffix != null)
                        {
                            var suffixLabelStyle = SirenixGUIStyles.RightAlignedGreyMiniLabel;
                            var width = suffixLabelStyle.CalcSize(new GUIContent(suffix)).x;
                            labelRect.TakeFromRight(5);
                            var suffixRect = labelRect.TakeFromRight(width + 5);
                            GUI.Label(suffixRect, suffix, suffixLabelStyle);
                        }

                        GUI.DrawTexture(iconRect, icon);
                        GUI.Label(labelRect, label);
                    }

                    //item.Enabled = EditorGUI.Toggle(toggleRect, item.Enabled);
                    item.Enabled = EditorGUI.Toggle(toggleRect.SetXMax(contentRect.xMax), item.Enabled);

                    items[i] = item;
                }
            }
        }

        private static void SelectScenePopup(Action<ValidationItem> onSelect, string selected)
        {
            var scenes = AssetDatabase.FindAssets("t:scene").Select(x => AssetDatabase.GUIDToAssetPath(x)).Distinct();
            var selector = new GenericSelector<string>(null, scenes, false);
            if (selected != null)
            {
                string path;
                if (selected.Length == 32 && !Directory.Exists(selected))
                {
                    path = AssetDatabase.GUIDToAssetPath(selected);
                }
                else
                {
                    path = selected;
                }

                var item = selector.SelectionTree.EnumerateTree(false).Where(x => x.GetFullPath() == path).FirstOrDefault();
                if (item != null)
                {
                    item.Select();
                }
            }
            ConfigureSelector(selector);
            foreach (var item in selector.SelectionTree.EnumerateTree())
            {
                item.Icon = item.ChildMenuItems.Count == 0 ? EditorIcons.UnityLogo : EditorIcons.UnityFolderIcon;
            }
            selector.SelectionConfirmed += (_) =>
            {
                var item = selector.SelectionTree.Selection.Select(x => x.GetFullPath()).FirstOrDefault();
                if (item != null)
                {
                    onSelect(File.Exists(item) ? ValidationItem.FromScenePath(item, false) : ValidationItem.FromSceneFolderPath(item, false));
                }
            };
            selector.ShowInPopup();
        }

        private static void ConfigureSelector<T>(OdinSelector<T> selector)
        {
            selector.SelectionTree.Config.SearchToolbarHeight = 18;
            selector.SelectionTree.Config.DefaultMenuStyle.Height = 18;
            selector.SelectionTree.SortMenuItemsByName();
        }

        private static bool DrawToolbarButton(Rect rect, SdfIconType icon, string tooltip = "")
        {
            EditorGUI.DrawRect(rect.TakeFromBottom(1), ValidatorGui.BorderColor);
            EditorGUI.DrawRect(rect.AlignTop(1).AddY(-1), ValidatorGui.BorderColor);
            var clicked = ValidatorGui.ToolbarBtn(rect, false, icon, "", tooltip);
            EditorGUI.DrawRect(rect.AlignLeft(1).AddX(-1), ValidatorGui.BorderColor);
            return clicked;
        }

        private void DrawToolbar(Rect toolbarRect)
        {
            var totalRect = toolbarRect;
            Rect prevBtnRect = default;

            EditorGUI.DrawRect(toolbarRect.TakeFromBottom(1), ValidatorGui.BorderColor);

            // Right
            {
                var col = this.ValidationSession.Results.ErrorCount == 0 ? ValidatorGui.GrayIconColor : ValidatorGui.RedErrorColor;
                if (Button(ref toolbarRect, false, SdfIconType.ExclamationOctagonFill, this.ValidationSession.Results.ShowErrors, this.ValidationSession.Results.ErrorCount.ToString(), "Show errors", col))
                {
                    InvokeStartOfNextFrame(() =>
                    {
                        this.ValidationSession.Results.ShowErrors = !this.ValidationSession.Results.ShowErrors;
                    });
                }

                col = this.ValidationSession.Results.WarningCount == 0 ? ValidatorGui.GrayIconColor : ValidatorGui.YellowWarningColor;
                if (Button(ref toolbarRect, false, SdfIconType.ExclamationTriangleFill, this.ValidationSession.Results.ShowWarnings, this.ValidationSession.Results.WarningCount.ToString(), "Show warnings", col))
                {
                    InvokeStartOfNextFrame(() =>
                    {
                        this.ValidationSession.Results.ShowWarnings = !this.ValidationSession.Results.ShowWarnings;
                    });
                }

                col = this.ValidationSession.Results.ValidCount == 0 ? ValidatorGui.GrayIconColor : ValidatorGui.GreenValidColor;
                if (Button(ref toolbarRect, false, SdfIconType.CheckCircleFill, this.ValidationSession.Results.ShowValid, this.ValidationSession.Results.ValidCount.ToString(), "Show fixed results", col))
                {
                    InvokeStartOfNextFrame(() =>
                    {
                        this.ValidationSession.Results.ShowValid = !this.ValidationSession.Results.ShowValid;
                    });
                }

                var isBulkFixing = this.SelectedMenu == MenuOptions.BulkFixing && this.MenuVisibility == true;

                var enable = isBulkFixing || this.ValidationSession.Results.FixTypeFilters.OrderedItems.Count > 0;
                GUIHelper.PushGUIEnabled(enable);
                if (Button(ref toolbarRect, false, SdfIconType.UiChecks, isBulkFixing, "Bulk fix issues", "Fix multiple issues."))
                {
                    InvokeStartOfNextFrame(() =>
                    {
                        if (isBulkFixing)
                        {
                            this.MenuVisibility = false;
                        }
                        else
                        {
                            // Select the fix type of the current selected result.
                            if (this.SelectedResult != null)
                            {
                                var fix = this.SelectedResult.HighestSeverityResult.Data.MangledFix;
                                if (fix != null)
                                {
                                    var fixType = fix.FixIdentifier;
                                    foreach (var item in this.ValidationSession.Results.FixTypeFilters.OrderedItems)
                                    {
                                        item.Enabled = fixType == item.Value;
                                    }
                                }
                            }

                            this.SelectedMenu = MenuOptions.BulkFixing;
                            this.MenuVisibility = true;
                        }
                    });
                }
                GUIHelper.PopGUIEnabled();
            }

            // Left
            {
                //var on = this.ValidationSession.IsWatching;
                //var eyeIcon = on ? SdfIconType.EyeFill : SdfIconType.EyeSlashFill;

                GUIHelper.PushGUIEnabled(!Application.isPlaying);
                {
                    //if (!this.ValidationSession.IsValidatingInBackground)
                    //{
                    //    if (IsValidatingButton(toolbarRect.TakeFromLeft(ValidatorGui.IconButtonWidth), "Enable validator"))
                    //    {
                    //        if (this.ValidationSession.IsValidatingInBackground)
                    //            this.ValidationSession.StopSession(false, true);
                    //        else
                    //            this.ValidationSession.StartSession(false, true);
                    //    }
                    //}

                    //if (!this.ValidationSession.IsWatching)
                    //{
                    //    if (Button(ref toolbarRect, true, eyeIcon, on, null, "Enable project watching"))
                    //    {
                    //        if (this.ValidationSession.IsWatching)
                    //            this.ValidationSession.StopSession(true, false);
                    //        else
                    //            this.ValidationSession.StartSession(true, false);
                    //    }
                    //}

                    var isValidating = this.ValidationSession.ShouldDisplayProgressBar;

                    if (isValidating)
                    {
                        GUIHelper.PushGUIEnabled(false);
                    }

                    if (Button(ref toolbarRect, true, SdfIconType.PlayFill, false, "Validate", "Validate open scenes, and assets in background."))
                    {
                        SceneView.RepaintAll();

                        this.ValidationSession.PopulateQueue(false, false);
                        // TODO: Push visible issues.

                        if (!this.ValidationSession.IsValidatingInBackground)
                            this.ValidationSession.StartSession();
                    }

                    if (isValidating)
                    {
                        GUIHelper.PopGUIEnabled();
                    }

                    if (Event.current.type == EventType.Repaint && isValidating)
                    {
                        var t = this.ValidationSession.CalculateCurrentValidationProgress();
                        var r = prevBtnRect;
                        var bg = ValidatorGui.EditorWindowBgColor;

                        EditorGUI.DrawRect(r, bg);
                        ValidatorGui.ProgressBar(r.Padding(2), t, null);
                    }

                    GUIHelper.PushGUIEnabled(isValidating);

                    if (Button(ref toolbarRect, true, SdfIconType.SkipForwardFill, false, null, "Complete validating queued up work now."))
                    {
                        InvokeStartOfNextFrame(() =>
                        {
                            this.ValidationSession.ValidateQueuedUpWorkNow();
                            SceneView.RepaintAll();
                        });
                    }

                    if (Button(ref toolbarRect, true, SdfIconType.StopFill, false, null, "Stop validating / Clear queued up work."))
                    {
                        InvokeStartOfNextFrame(() =>
                        {
                            this.ValidationSession.Clear(false, true);
                            SceneView.RepaintAll();
                        });
                    }

                    GUIHelper.PopGUIEnabled();

                    if (Button(ref toolbarRect, true, SdfIconType.SkipEndFill, false, "Validate everything", "Validate the entire session now."))
                    {
                        InvokeStartOfNextFrame(() =>
                        {
                            this.ValidationSession.ValidateEverythingNow(false, true, true);
                            SceneView.RepaintAll();
                        });
                    }

                    if (Button(ref toolbarRect, true, SdfIconType.TrashFill, false, "Reset", "Clears all results and the current validation queue."))
                    {
                        InvokeStartOfNextFrame(() =>
                        {
                            this.ValidationSession.Clear(true, true);
                            ProjectWatcher.RestartWatching(true);
                            SceneView.RepaintAll();
                        });
                    }
                }
                GUIHelper.PopGUIEnabled();

            }
            // Search
            {
                Rect searchFieldRect = toolbarRect.TakeFromRight(toolbarRect.width).HorizontalPadding(ValidatorGui.ContentPadding).AlignCenterY(EditorGUIUtility.singleLineHeight);
                searchFieldRect.yMin += 1;
                var oldSearchTerm = this.ValidationSession.Results.SearchTerm;
                var newSearchTerm = searchField.OnGUI(searchFieldRect, oldSearchTerm);
                if (oldSearchTerm != newSearchTerm)
                {
                    this.selectionToRecover = this.SelectedResult;
                    this.ValidationSession.Results.SearchTerm = newSearchTerm;
                }
            }

            bool Button(ref Rect rectIn, bool fromLeft, SdfIconType? icon, bool isOn, string name, string tooltip, Color? color = null)
            {
                Rect rect;

                var textWidth = 0f;
                var iconWidth = 0f;

                var style = ValidatorGui.LabelVerticalCentered;
                var content = name == null ? null : new GUIContent(name);

                if (icon != null)
                {
                    iconWidth = rectIn.height + 8;
                }

                if (content != null)
                {
                    // Dirty hack
                    if (name == "On")
                        textWidth = style.CalcSize(new GUIContent("Off")).x;
                    else
                        textWidth = style.CalcSize(content).x;

                    if (!icon.HasValue)
                    {
                        textWidth += 10;
                    }
                }

                if (fromLeft)
                {
                    rect = rectIn.TakeFromLeft(iconWidth + textWidth);
                    EditorGUI.DrawRect(rectIn.TakeFromLeft(1), ValidatorGui.BorderColor);
                }
                else
                {
                    rect = rectIn.TakeFromRight(iconWidth + textWidth);
                    EditorGUI.DrawRect(rectIn.TakeFromRight(1), ValidatorGui.BorderColor);
                }

                prevBtnRect = rect;

                var clicked = GUI.Button(rect, new GUIContent("", tooltip), GUIStyle.none);
                var bg = ValidatorGui.ToolbarBgColor;
                var mouseOver = rect.Contains(Event.current.mousePosition);
                var iconCol = ValidatorGui.BtnContentColor;

                if (isOn || mouseOver)
                {
                    var hColor = icon.HasValue && icon.Value == SdfIconType.UiChecks ? ValidatorGui.BtnActiveBgColor : ValidatorGui.HighlightedBgColor;
                    bg = mouseOver && !isOn ? ValidatorGui.BtnMouseOverBgColor : hColor;
                    EditorGUI.DrawRect(rect, bg);
                    iconCol = ValidatorGui.BtnMouseOverContentColor;
                    style = ValidatorGui.ActiveLabelVerticalCentered;
                }

                if (icon.HasValue)
                {
                    if (color.HasValue)
                    {
                        iconCol = color.Value;
                    }

                    var pad = 4;
                    var iconRect = rect.TakeFromLeft(iconWidth);

                    if (icon.Value == SdfIconType.CheckCircleFill)
                    {
                        pad += 1;
                    }
                    else if (icon.Value == SdfIconType.TrashFill || icon.Value == SdfIconType.UiChecks)
                    {
                        iconRect.y += 1;
                    }

                    SdfIcons.DrawIcon(iconRect.VerticalPadding(pad - 1, pad), icon.Value, iconCol, bg);
                }

                if (content != null)
                {
                    var labelRect = rect.TakeFromRight(textWidth);
                    if (icon.HasValue)
                    {
                        labelRect.x -= 5;
                        GUI.Label(labelRect, content, style);
                    }
                    else
                    {
                        labelRect.x += 5;
                        GUI.Label(labelRect, content, style);
                    }
                }

                return clicked;
            }
        }

        private void InvokeStartOfNextFrame(Action action)
        {
            this.delayedAction += () =>
            {
                action();
            };
            this.Window.Repaint();
        }

        private bool IsValidatingButton(Rect rect, string tooltip)
        {
            EditorGUI.DrawRect(rect.TakeFromRight(1), ValidatorGui.BorderColor);

            var clicked = GUI.Button(rect, GUIHelper.TempContent("", tooltip), GUIStyle.none);

            if (Event.current.type == EventType.Repaint)
            {
                var on = this.ValidationSession.IsValidatingInBackground;
                var mouseOver = rect.Contains(Event.current.mousePosition);
                var bg = ValidatorGui.ToolbarBgColor;

                if (on || mouseOver)
                {
                    bg = mouseOver && !on ? ValidatorGui.BtnMouseOverBgColor : ValidatorGui.HighlightedBgColor;
                    EditorGUI.DrawRect(rect, bg);
                }

                EditorGUI.DrawRect(rect, bg);
                guiSpinner.DrawOdinSpinner(rect.Padding(2).AlignCenterX(rect.height - 4), false, false, on);
            }

            return clicked;
        }

        private Texture GetFilterItemIcon<T>(ValidationSessionResultCollector.Filter<T>.FilteredItem item, out bool highlightIcon)
        {
            if (typeof(T) == typeof(SceneReference))
            {
                highlightIcon = true;
                //var scene = (SceneReference)(object)item.Value;
                //highlightIcon = scene.IsLoaded;
                return ValidatorGui.SceneAssetIcon;
            }

            if (typeof(T) == typeof(Type))
            {
                highlightIcon = true;
                return GUIHelper.GetAssetThumbnail(null, (Type)(object)item.Value, false);
            }

            if (typeof(T) == typeof(FixIdentifier))
            {
                highlightIcon = false;
                return null;
            }

            highlightIcon = false;

            throw new NotImplementedException();
        }

        public void Dispose()
        {
            //this.ValidationSession.OnResult -= CollectTimings;
            this.ValidationSession.Results.OnResultsChanged -= RepaintWindow;
            this.currentResultTree?.Dispose();
            this.metaDataTree?.Dispose();
            this.issueFixerTree?.Dispose();
            this.metaDataTree = null;
            this.currentResultTree = null;
            this.issueFixerTree = null;
            this.currentFix = null;

            ActiveEditors.Remove(this);
        }

        private class RuleDataDrawer
        {
            [OnInspectorGUI(nameof(OnBefore), nameof(OnAfter))]
            [ShowInInspector, HideLabel, HideReferenceObjectPicker]
            private Validator data;
            private Action saveChanges;
            private string name;

            public RuleDataDrawer(string name, Validator data, Action saveChanges)
            {
                this.data = data;
                this.saveChanges = saveChanges;
                this.name = name;
            }

            private void OnBefore()
            {
                var r = ValidatorGui.Header("", 44);
                GUI.Label(r.Padding(5).AlignCenterY(EditorGUIUtility.singleLineHeight), this.name + " config", SirenixGUIStyles.BoldLabelCentered);
                GUILayout.BeginVertical(padding);
                GUIHelper.PushLabelWidth(160);
            }

            private void OnAfter()
            {
                GUIHelper.PopLabelWidth();
                GUILayout.EndVertical();
                GUILayout.Space(5);
                GUILayout.FlexibleSpace();
                var r = GUILayoutUtility.GetRect(0, 40);
                EditorGUI.DrawRect(r, SirenixGUIStyles.DarkEditorBackground);
                EditorGUI.DrawRect(r.TakeFromTop(1), SirenixGUIStyles.BorderColor);
                r = r.Padding(5);

                GUI.color = Color.green;
                if (GUI.Button(r.Split(0, 2), "Save Changes"))
                    this.saveChanges();

                GUI.color = Color.white;
                if (GUI.Button(r.Split(1, 2), "Cancel"))
                    GUIHelper.CurrentWindow.Close();
            }
        }

        private class AssetSelector
        {
            [OnInspectorGUI, PropertyOrder(-10)]
            private void DrawHeader()
            {
                var rect = GUILayoutUtility.GetRect(0, 19);

                if (Event.current.type == EventType.Repaint)
                {
                    var outerRect = GUIHelper.GetCurrentLayoutRect();
                    rect.yMin = outerRect.y;
                    rect.xMin = outerRect.x;
                    rect.width = outerRect.width;
                    EditorStyles.toolbar.Draw(rect, GUIContent.none, 0);

                    SirenixGUIStyles.BoldLabelCentered.Draw(rect, new GUIContent("Select a folder or a file path"), 0);
                }
            }

            public AssetSelector(Action<AssetSelector> confirm)
            {
                this.confirm = confirm;
            }

            private Action<AssetSelector> confirm;

            [HorizontalGroup]
            [ValidateInput("IsValidPath")]
            [PlaceholderLabel("* Path (file or folder)", SdfIconType.FolderFill)]
            public string Path;

            [HorizontalGroup(150)]
            [DisableIf("PathIsFile")]
            [PlaceholderLabel("Filter (t: ExampleType)", SdfIconType.Search)]
            public string Filter;

            private bool IsValidPath()
            {
                if (string.IsNullOrEmpty(this.Path))
                {
                    return true;
                }

                if (Directory.Exists(this.Path))
                {
                    return true;
                }

                if (File.Exists(this.Path))
                {
                    return true;
                }

                return false;
            }

            private string[] GetAllAssets() => AssetDatabase.GetAllAssetPaths();

            private bool PathIsFile()
            {
                if (string.IsNullOrEmpty(this.Path))
                    return false;

                return File.Exists(this.Path);
            }

            [ButtonGroup, Button(ButtonSizes.Medium)]
            [DisableIf("@string.IsNullOrEmpty(this.Path) || !IsValidPath()")]
            public void Ok()
            {
                confirm(this);
            }
        }

        private class Timings
        {
            private Dictionary<Type, AverageSampler> sampleBuckets = new Dictionary<Type, AverageSampler>();

            public List<(Type type, AverageSampler sampler)> Samples = new List<(Type type, AverageSampler sampler)>();

            public void Reset()
            {
                this.sampleBuckets.Clear();
                this.Samples.Clear();
            }

            public void SampleResult(PersistentValidationResult result)
            {
                if (result != null)
                {
                    var validatorType = result.ValidatorType;
                    if (validatorType == null)
                    {
                        validatorType = typeof(NoValidator);
                    }

                    if (!sampleBuckets.TryGetValue(validatorType, out var sampler))
                    {
                        sampleBuckets[validatorType] = sampler = new AverageSampler();
                        this.Samples.Add((validatorType, sampler));

                        if (!GlobalValidationConfig.SkipFirstSample)
                        {
                            sampler.Add(result.ValidationTimeMS);
                        }
                    }
                    else
                    {
                        sampler.Add(result.ValidationTimeMS);
                    }
                }
            }
        }

        public enum MenuOptions
        {
            FilterResults,
            FilterAssets,
            Rules,
            Events,
            Config,
            Profiler,
            BulkFixing,
            About,
            None,
        }
    }
}
#endif