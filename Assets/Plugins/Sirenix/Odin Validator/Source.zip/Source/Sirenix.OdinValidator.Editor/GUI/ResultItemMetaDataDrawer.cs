//-----------------------------------------------------------------------
// <copyright file="ValidationSessionEditor.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor.Validation;

    internal class ResultItemMetaDataDrawer
    {
        public ResultItemMetaData[] MetaData;

        public ResultItemMetaDataDrawer(ResultItemMetaData[] metaData)
        {
            this.MetaData = metaData;
        }
    }
}
#endif