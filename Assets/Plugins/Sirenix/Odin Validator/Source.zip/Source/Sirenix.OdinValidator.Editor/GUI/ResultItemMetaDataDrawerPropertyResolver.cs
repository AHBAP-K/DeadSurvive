//-----------------------------------------------------------------------
// <copyright file="ValidationSessionEditor.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector;
    using Sirenix.OdinInspector.Editor;
    using System;

    internal class ResultItemMetaDataDrawerPropertyResolver : BaseMemberPropertyResolver<ResultItemMetaDataDrawer>
    {
        protected override InspectorPropertyInfo[] GetPropertyInfos()
        {
            var array = this.ValueEntry.SmartValue.MetaData;

            var result = new InspectorPropertyInfo[array.Length];

            for (int i = 0; i < array.Length; i++)
            {
                var item = array[i];

                if (item.Value is Delegate d)
                {
                    result[i] = InspectorPropertyInfo.CreateForDelegate(item.Key, i, typeof(ResultItemMetaDataDrawer), d,
                        new ResultItemMetaDataValueAttribute(),
                        new ButtonAttribute() { Expanded = true });
                }
                else
                {
                    result[i] = InspectorPropertyInfo.CreateValue(item.Key, i, SerializationBackend.None, MakeGetterSetter(i),
                        new ReadOnlyAttribute(),
                        new EnableGUIAttribute(),
                        new ResultItemMetaDataValueAttribute(),
                        new HideReferenceObjectPickerAttribute());
                }
            }

            return result;
        }

        private IValueGetterSetter MakeGetterSetter(int i)
        {
            return new GetterSetter<ResultItemMetaDataDrawer, object>(
                (ref ResultItemMetaDataDrawer parent) => parent.MetaData[i].Value,
                null
            );
        }
    }
}
#endif