//-----------------------------------------------------------------------
// <copyright file="RectUtils.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.Utilities;
    using System;
    using UnityEngine;

    internal static class RectUtils
    {
        public static Rect TakeFromLeft(this ref Rect rect, float width)
        {
            var toTake = Math.Min(rect.width, width);
            var result = rect;
            result.width = toTake;
            rect.x += toTake;
            rect.width -= toTake;
            return result;
        }

        public static Rect TakeFromRight(this ref Rect rect, float width)
        {
            var toTake = Math.Min(rect.width, width);
            var result = rect.AlignRight(toTake);
            rect.width -= toTake;
            return result;
        }

        public static Rect TakeFromTop(this ref Rect rect, float height)
        {
            var toTake = Math.Min(rect.height, height);
            var result = rect;
            result.height = toTake;
            rect.y += toTake;
            rect.height -= toTake;
            return result;
        }

        public static Rect TakeFromBottom(this ref Rect rect, float height)
        {
            var toTake = Math.Min(rect.height, height);
            var result = rect.AlignBottom(toTake);
            rect.height -= height;
            return result;
        }
    }
}
#endif