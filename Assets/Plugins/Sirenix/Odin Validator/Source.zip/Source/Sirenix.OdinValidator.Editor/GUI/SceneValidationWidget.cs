//-----------------------------------------------------------------------
// <copyright file="SceneValidationWidget.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor;
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using System;
    using System.Linq;
    using UnityEditor;
    using UnityEngine;

    public static class SceneValidationWidget
    {
        private static Vector2 handleDragStartMousePosition;
        private static Vector2 handleDragStartWidgetOffset;
        private static bool mouseWasInWidgetLastFrame;
        private static GUISpinner spinner;
        private static int warnings;
        private static int errors;
        private static bool isScanning;
        private static float scanT;
        private static bool isEnabled;
        private static bool showContextMenuNextFrame;
        private static GUIStyle warningText;
        private static GUIStyle WarningText => (warningText = warningText ?? new GUIStyle(SirenixGUIStyles.WhiteLabel) { alignment = TextAnchor.UpperLeft });
        private static GUIStyle errorText;
        private static GUIStyle ErrorText => (errorText = errorText ?? new GUIStyle(SirenixGUIStyles.WhiteLabel) { alignment = TextAnchor.LowerLeft });

        [InitializeOnLoadMethod]
        private static void Init()
        {
            UnityEditorEventUtility.DuringSceneGUI += OnSceneGUI;
        }

        private static void DrawWidget(ref Rect rect, bool calcSize)
        {
            var padding = 4;
            var height = 25;
            var totalRect = rect;
            var isMouseOver = !calcSize && rect.Contains(Event.current.mousePosition);

            if (isMouseOver && Event.current.rawType == EventType.MouseUp && Event.current.button == 1)
            {
                showContextMenuNextFrame = true;
            }

            if (showContextMenuNextFrame && Event.current.type == EventType.Layout)
            {
                showContextMenuNextFrame = false;

                if (!Application.isPlaying)
                {
                    GenericMenu m = new GenericMenu();

                    m.AddItem(new GUIContent("Revalidate"), false, () =>
                    {
                        foreach (var item in ValidationSession.ActiveValidationSessions)
                        {
                            if (item.IsValidatingInBackground)
                            {
                                item.RestartBackgroundValidation();
                            }
                        }
                    });

                    if (ValidationSession.ActiveValidationSessions.Any(x => x.RemainingWorkCountSample > 0))
                    {
                        m.AddItem(new GUIContent("Complete now"), false, () =>
                        {
                            foreach (var item in ValidationSession.ActiveValidationSessions)
                            {
                                item.ValidateQueuedUpWorkNow();
                            }
                        });

                        m.AddItem(new GUIContent("Reset"), false, () =>
                        {
                            ProjectWatcher.RestartWatching(true);
                            foreach (var session in ValidationSession.ActiveValidationSessions)
                            {
                                session.Clear(true, true);
                            }
                        });
                    }
                    else
                    {
                        m.AddDisabledItem(new GUIContent("Complete now"));
                        m.AddDisabledItem(new GUIContent("Reset"));
                    }

                    if (ValidationSession.ActiveValidationSessions.Count > 1)
                    {
                        m.AddSeparator("");

                        foreach (var item in ValidationSession.ActiveValidationSessions)
                        {
                            m.AddItem(new GUIContent("Show " + item.Name), false, () =>
                            {
                                item.OpenEditor();
                            });
                        }
                    }

                    m.AddSeparator("");

                    m.AddItem(new GUIContent("Config"), false, () =>
                    {
                        var editor = ValidationSession.GlobalValidationSession.OpenEditor();
                        editor.MenuVisibility = true;
                        editor.SelectedMenu = ValidationSessionEditor.MenuOptions.Config;
                    });

                    m.ShowAsContext();
                }
            }

            // Draw bg
            {
                if (calcSize)
                {
                    rect.height = height + padding * 2;
                    rect.width += padding * 2;
                }
                else
                {
                    GUI.DrawTexture(rect, Texture2D.whiteTexture, ScaleMode.StretchToFill, true, 0, new Color(0.13f, 0.13f, 0.13f, 1), 0, 5);

                    rect.y += padding;
                    rect.x += padding;
                    rect.width -= padding * 2;
                    rect.height -= padding * 2;
                }
            }

            // Draw Spinner
            {
                if (calcSize)
                {
                    rect.width += height;
                }
                else
                {
                    var iconRect = rect.TakeFromLeft(rect.height);
                    //rect.TakeFromLeft(padding);

                    if (errors > 0)
                        spinner.DrawSceneWidgetSpinner(iconRect, GUISpinner.IconType.Error, isScanning, isMouseOver, scanT);
                    else if (warnings > 0)
                        spinner.DrawSceneWidgetSpinner(iconRect, GUISpinner.IconType.Warning, isScanning, isMouseOver, scanT);
                    else
                        spinner.DrawSceneWidgetSpinner(iconRect, GUISpinner.IconType.Valid, isScanning, isMouseOver, scanT);
                }
            }

            if (errors > 0 || warnings > 0)
            {
                // Draw errors
                var textWidth = Math.Max(
                    WarningText.CalcSize(GUIHelper.TempContent(errors.ToString())).x + padding,
                    WarningText.CalcSize(GUIHelper.TempContent(warnings.ToString())).x + padding);

                if (calcSize)
                {
                    rect.width += textWidth;
                }
                else
                {
                    var r = rect.TakeFromLeft(textWidth);
                    r.x += padding;

                    GUIHelper.PushColor(ValidatorGui.DarkSkinRedErrorColor);
                    if (UnityVersion.IsVersionOrGreater(2019, 3))
                    {
                        GUI.Label(r.SplitVertical(0, 2), errors.ToString(), ErrorText);
                    }
                    else
                    {
                        GUI.Label(r.SplitVertical(0, 2).AddYMax(2), errors.ToString(), ErrorText);
                    }
                    GUIHelper.PopColor();
                    GUIHelper.PushColor(ValidatorGui.DarkSkinYellowWarningColor);
                    if (UnityVersion.IsVersionOrGreater(2019, 3))
                    {
                        GUI.Label(r.SplitVertical(1, 2), warnings.ToString(), WarningText);
                    }
                    else
                    {
                        GUI.Label(r.SplitVertical(1, 2).AddYMin(-2), warnings.ToString(), WarningText);
                    }
                    GUIHelper.PopColor();
                }
            }
        }

        private static void OnSceneGUI(SceneView sceneView)
        {
            if (!GlobalValidationConfig.ShowWidget || Application.isPlaying)
                return;

            if (!sceneView.wantsMouseMove)
            {
                sceneView.wantsMouseMove = true;
            }

            GetSessionsState(out warnings, out errors, out isScanning, out isEnabled, out scanT);

            if (!isEnabled)
                return;

            if (warnings == 0 && errors == 0 && GlobalValidationConfig.ShowWidgetOnlyWhenErrorOrWarnings)
                return;

            if (isScanning)
            {
                GUIHelper.RequestRepaint();
            }

            Handles.BeginGUI();

            var windowArea = sceneView.position;
            windowArea.position = Vector2.zero;
            windowArea.height -= 18f; // Adjust for bottom bar

            var widgetOffsetX = GlobalValidationConfig.WidgetOffsetX;
            var widgetOffsetY = GlobalValidationConfig.WidgetOffsetY;
            var anchor = GlobalValidationConfig.WidgetAnchor;

            var rect = new Rect(widgetOffsetX, widgetOffsetY, 0, 0);

            DrawWidget(ref rect, true);
            if (rect.width == 0) Debug.Log("1");
            var mouseInWidget = rect.Contains(Event.current.mousePosition);

            rect = TransformToAnchor(windowArea, rect, anchor);
            if (rect.width == 0) Debug.Log("2");

            var widget = rect;
            DrawWidget(ref rect, false);

            // Drag handle
            {
                var dragHandleId = GUIUtility.GetControlID(FocusType.Passive);

                if (Event.current.OnMouseDown(widget, 0))
                {
                    GUIUtility.hotControl = dragHandleId;
                    handleDragStartMousePosition = Event.current.mousePosition;
                    handleDragStartWidgetOffset.x = widgetOffsetX;
                    handleDragStartWidgetOffset.y = widgetOffsetY;
                    GUIHelper.RequestRepaint();
                }
                else if (GUIUtility.hotControl == dragHandleId)
                {
                    var closestAnchor = GetClosestAnchor(windowArea, Event.current.mousePosition);
                    var anchorRect = TransformToAnchor(windowArea, new Rect(0, 0, 15, 15), closestAnchor);

                    if (handleDragStartMousePosition != Event.current.mousePosition)
                    {
                        SirenixEditorGUI.DrawSolidRect(anchorRect, new Color(1f, 1f, 1f, 0.3f));
                    }

                    bool onMouseUp = Event.current.OnMouseUp(0);

                    if (onMouseUp || Event.current.OnMouseDown(0, false) || EditorWindow.focusedWindow != sceneView)
                    {
                        GUIUtility.hotControl = 0;

                        if (onMouseUp && handleDragStartMousePosition == Event.current.mousePosition)
                        {
                            var highestPrioritySession = ValidationSession.ActiveValidationSessions.Where(n => n.Results != null).OrderBy(n => n.Results.ErrorCount).ThenBy(n => n.Results.WarningCount).FirstOrDefault();

                            if (highestPrioritySession != null)
                            {
                                ValidationSessionEditor.OpenOrFocusWindowForSession(highestPrioritySession);
                            }
                        }
                        else if (anchor != closestAnchor)
                        {
                            var newOffset = GetOffsetForAnchorOfWidgetRectInArea(windowArea, widget, closestAnchor);

                            widgetOffsetX.Value = newOffset.x;
                            widgetOffsetY.Value = newOffset.y;
                            anchor.Value = closestAnchor;
                        }

                    }
                    else if (Event.current.type == EventType.MouseDrag)
                    {
                        var delta = Event.current.mousePosition - handleDragStartMousePosition;
                        delta = TransformToAnchor(delta, anchor);

                        var offset = handleDragStartWidgetOffset + delta;

                        offset.x = Mathf.Clamp(offset.x, 0, windowArea.width - widget.width);
                        offset.y = Mathf.Clamp(offset.y, 0, windowArea.height - widget.height);

                        widgetOffsetX.Value = offset.x;
                        widgetOffsetY.Value = offset.y;
                        Event.current.Use();
                        GUIHelper.RequestRepaint();
                    }
                }
            }

            // Handle general case repainting
            if (Event.current.isMouse)
            {
                if (mouseInWidget || mouseWasInWidgetLastFrame)
                {
                    sceneView.Repaint();
                }
                mouseWasInWidgetLastFrame = mouseInWidget;
            }

            GUIHelper.RepaintIfRequested(sceneView);

            Handles.EndGUI();
        }

        private static void GetSessionsState(out int warnings, out int errors, out bool isScanning, out bool isEnabled, out float t)
        {
            warnings = 0;
            errors = 0;
            isScanning = false;
            isEnabled = false;
            t = 1;

            foreach (var session in ValidationSession.ActiveValidationSessions)
            {
                if (session.Results == null) continue;

                warnings += session.Results.WarningCount;
                errors += session.Results.ErrorCount;

                isEnabled = isEnabled || session.IsValidatingInBackground;

                if (session.RemainingWorkCountSample > 0 && session.IsValidatingInBackground)
                {
                    t = Mathf.Min(session.CalculateCurrentValidationProgress(), t);
                }

                if (!isScanning)
                {
                    foreach (var validationSession in ValidationSession.ActiveValidationSessions)
                    {
                        if (validationSession.ShouldDisplayProgressBar)
                        {
                            isScanning = true;
                            break;
                        }
                    }
                }
            }
        }

        public static WidgetAnchor GetClosestAnchor(Rect area, Vector2 position)
        {
            position -= area.position;
            area.position = Vector2.zero;

            position.x /= area.width;
            position.y /= area.height;

            if (position.x <= 0.5f)
            {
                if (position.y <= 0.5f)
                {
                    return WidgetAnchor.TopLeft;
                }
                else
                {
                    return WidgetAnchor.BottomLeft;
                }
            }
            else
            {
                if (position.y <= 0.5f)
                {
                    return WidgetAnchor.TopRight;
                }
                else
                {
                    return WidgetAnchor.BottomRight;
                }
            }
        }

        public static Rect TransformFromToAnchor(Rect area, Rect rect, WidgetAnchor from, WidgetAnchor to)
        {
            switch (from)
            {
                case WidgetAnchor.BottomLeft:
                    rect.y = area.height - (rect.y + rect.height);
                    break;
                case WidgetAnchor.TopRight:
                    rect.x = area.width - (rect.x + rect.width);
                    break;
                case WidgetAnchor.BottomRight:
                    rect.x = area.width - (rect.x + rect.width);
                    rect.y = area.height - (rect.y + rect.height);
                    break;
                case WidgetAnchor.TopLeft: break;
                default: throw new NotImplementedException();
            }

            return TransformToAnchor(area, rect, to);
        }

        public static Vector2 TransformToAnchor(Vector2 vector, WidgetAnchor anchor)
        {
            switch (anchor)
            {
                case WidgetAnchor.TopLeft:
                    return vector;
                case WidgetAnchor.TopRight:
                    return new Vector2(-vector.x, vector.y);
                case WidgetAnchor.BottomRight:
                    return new Vector2(-vector.x, -vector.y);
                case WidgetAnchor.BottomLeft:
                    return new Vector2(vector.x, -vector.y);
                default: throw new NotImplementedException();
            }
        }

        public static Rect TransformToAnchor(Rect area, Rect rect, WidgetAnchor anchor)
        {
            switch (anchor)
            {
                case WidgetAnchor.BottomLeft:
                    rect.y = area.height - (rect.y + rect.height);
                    rect.position += area.position;
                    return rect;

                case WidgetAnchor.BottomRight:
                    rect.x = area.width - (rect.x + rect.width);
                    rect.y = area.height - (rect.y + rect.height);
                    rect.position += area.position;
                    return rect;
                case WidgetAnchor.TopRight:
                    rect.x = area.width - (rect.x + rect.width);
                    rect.position += area.position;
                    return rect;
                case WidgetAnchor.TopLeft:
                    rect.position += area.position;
                    return rect;
                default: throw new NotImplementedException();
            }
        }

        public static Vector2 GetOffsetForAnchorOfWidgetRectInArea(Rect area, Rect widget, WidgetAnchor anchor)
        {
            switch (anchor)
            {
                case WidgetAnchor.BottomLeft:
                    return new Vector2(widget.x, area.height - widget.yMax);
                case WidgetAnchor.TopLeft:
                    return widget.position;
                case WidgetAnchor.TopRight:
                    return new Vector2(area.width - widget.xMax, widget.y);
                case WidgetAnchor.BottomRight:
                    return new Vector2(area.width - widget.xMax, area.height - widget.yMax);
                default: throw new NotImplementedException();
            }
        }

        public static bool IsAnchorLeft(WidgetAnchor anchor)
        {
            return anchor == WidgetAnchor.BottomLeft || anchor == WidgetAnchor.TopLeft;
        }

        public static WidgetAnchor InvertAnchor(WidgetAnchor anchor)
        {
            return (WidgetAnchor)((((int)anchor) + 2) % 4);
        }

        public enum WidgetAnchor
        {
            BottomLeft,
            TopLeft,
            TopRight,
            BottomRight,
        }
    }
}
#endif