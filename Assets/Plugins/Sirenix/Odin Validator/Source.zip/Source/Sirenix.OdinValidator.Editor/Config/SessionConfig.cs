//-----------------------------------------------------------------------
// <copyright file="SessionConfig.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
using Sirenix.OdinInspector;
using Sirenix.OdinInspector.Editor;
using Sirenix.OdinInspector.Editor.Validation;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace Sirenix.OdinValidator.Editor
{
    public interface ISessionConfigData
    {
        string Name { get; }
        string Description { get; }
        SdfIconType Icon { get; }
        IList<ValidationItem> Include { get; }
        IList<ValidationItem> Exclude { get; }
        void SaveChanges();
    }

    public class SessionConfig
    {
        // Optimization: Avoid string allocations in hashsets.
        [NonSerialized] private HashSet<string> assetsToValidate = new HashSet<string>();
        [NonSerialized] private HashSet<string> sceneGuidsToValidate = new HashSet<string>();
        [NonSerialized] private HashSet<string> sceneGuidsNotToValidate = new HashSet<string>();
        [NonSerialized] private HashSet<UnityEngine.Object> unityObjectsToValidate = new HashSet<UnityEngine.Object>();

        public bool IsDirty = true;
        public List<ISessionConfigData> SessionData = new List<ISessionConfigData>();

        public SessionConfig(params ISessionConfigData[] configDataContainers)
        {
            foreach (var data in configDataContainers)
            {
                this.SessionData.Add(data);
            }
        }

        public SessionConfig(List<ValidationItem> include, List<ValidationItem> exclude)
        {
            this.SessionData.Add(new SerializableSessionConfigData(include, exclude));
        }

        public IEnumerable<ValidationItem> Include => SessionData.SelectMany(x => x.Include) ?? Enumerable.Empty<ValidationItem>();

        public IEnumerable<ValidationItem> Exclude => SessionData.SelectMany(x => x.Exclude) ?? Enumerable.Empty<ValidationItem>();

        public void SaveChanges()
        {
            foreach (var item in SessionData)
            {
                item.SaveChanges();
            }
        }

        public void MarkDirty()
        {
            this.IsDirty = true;
        }

        public HashSet<string> GetAssetsToValidate()
        {
            if (this.IsDirty)
            {
                this.UpdateAll();
            }

            return this.assetsToValidate;
        }

        public HashSet<UnityEngine.Object> GetObjectsToValidate()
        {
            if (this.IsDirty)
            {
                this.UpdateAll();
            }

            return this.unityObjectsToValidate;
        }

        public HashSet<string> GetSceneGuidsToValidate()
        {
            if (this.IsDirty)
            {
                this.UpdateAll();
            }

            return this.sceneGuidsToValidate;
        }

        public bool ShouldValidateScene(string guid)
        {
            if (this.IsDirty)
            {
                this.UpdateAll();
            }

            if (this.sceneGuidsToValidate.Contains(guid))
            {
                return true;
            }
            else if (this.sceneGuidsNotToValidate.Contains(guid))
            {
                return false;
            }

            // We didn't know whether to validate the scene. Lets update and try again!
            this.UpdateScenes();

            if (this.sceneGuidsToValidate.Contains(guid))
            {
                return true;
            }
            else if (this.sceneGuidsNotToValidate.Contains(guid))
            {
                return false;
            }

            // No one told us whether to include or exclude. So we'll add it to exclude.
            this.sceneGuidsNotToValidate.Add(guid);
            return false;
        }

        public void Optimize()
        {
            //UnityEditorInternal.InternalEditorUtility.GetLoadedObjectFromInstanceID;
            // TODO...
        }

        public void UpdateAll()
        {
            UpdateAssets();
            UpdateScenes();
            UpdateUnityObjects();

            this.IsDirty = false;
        }

        private void UpdateUnityObjects()
        {
            this.unityObjectsToValidate.Clear();

            foreach (var item in this.Include.Where(x => x.Enabled && x.Type == ValidationItem.ValidationItemType.Object && x.Object))
            {
                this.unityObjectsToValidate.Add(item.Object);
            }

            foreach (var item in this.Exclude.Where(x => x.Enabled && x.Type == ValidationItem.ValidationItemType.Object && x.Object))
            {
                this.unityObjectsToValidate.Remove(item.Object);
            }
        }

        public void UpdateScenes()
        {
            this.sceneGuidsToValidate.Clear();
            this.sceneGuidsNotToValidate.Clear();

            // Include
            {
                var inlcude = this.Include.Where(x => x.Enabled && x.Type == ValidationItem.ValidationItemType.Scene);

                foreach (var s in inlcude)
                {
                    if (s.Scene.Type == ValidationItem.SceneIncludeType.OpenScenes)
                    {
                        var setupScenes = EditorSceneManager.GetSceneManagerSetup();
                        foreach (var scene in setupScenes)
                        {
                            if (!string.IsNullOrEmpty(scene.path))
                            {
                                var guid = AssetDatabase.AssetPathToGUID(scene.path);
                                if (!string.IsNullOrEmpty(guid))
                                    this.sceneGuidsToValidate.Add(guid);
                            }
                        }
                    }
                    else if (s.Scene.Type == ValidationItem.SceneIncludeType.SceneGuid)
                    {
                        if (!string.IsNullOrEmpty(s.Scene.Value) && s.Scene.Value.Length == 32)
                        {
                            var guid = s.Scene.Value;
                            if (!string.IsNullOrEmpty(guid))
                                this.sceneGuidsToValidate.Add(guid);
                        }
                    }
                    else if (s.Scene.Type == ValidationItem.SceneIncludeType.ScenesInBuildOptions)
                    {
                        foreach (var scene in EditorBuildSettings.scenes)
                        {
                            if (scene.enabled)
                            {
                                var guid = AssetDatabase.AssetPathToGUID(scene.path);
                                if (!string.IsNullOrEmpty(guid))
                                    this.sceneGuidsToValidate.Add(guid);
                            }
                        }
                    }
                    else if (s.Scene.Type == ValidationItem.SceneIncludeType.ScenesInFolder)
                    {
                        foreach (var guid in AssetDatabase.FindAssets("t:Scene", new string[] { s.Scene.Value }))
                        {
                            if (!string.IsNullOrEmpty(guid))
                                this.sceneGuidsToValidate.Add(guid);
                        }
                    }
                }
            }

            // Exclude
            {
                var exclude = this.Exclude.Where(x => x.Enabled && x.Type == ValidationItem.ValidationItemType.Scene);

                foreach (var s in exclude)
                {
                    if (s.Scene.Type == ValidationItem.SceneIncludeType.OpenScenes)
                    {
                        // TODO: Get playmode version of Open scenes.
                        var setupScenes = EditorSceneManager.GetSceneManagerSetup();
                        foreach (var scene in setupScenes)
                        {
                            if (!string.IsNullOrEmpty(scene.path))
                            {
                                var guid = AssetDatabase.AssetPathToGUID(scene.path);
                                this.sceneGuidsToValidate.Remove(guid);
                                this.sceneGuidsNotToValidate.Add(guid);
                            }
                        }
                    }
                    else if (s.Scene.Type == ValidationItem.SceneIncludeType.SceneGuid)
                    {
                        if (!string.IsNullOrEmpty(s.Scene.Value) && s.Scene.Value.Length == 32)
                        {
                            this.sceneGuidsToValidate.Remove(s.Scene.Value);
                            this.sceneGuidsNotToValidate.Add(s.Scene.Value);
                        }
                    }
                    else if (s.Scene.Type == ValidationItem.SceneIncludeType.ScenesInBuildOptions)
                    {
                        foreach (var scene in EditorBuildSettings.scenes)
                        {
                            if (scene.enabled)
                            {
                                var guid = AssetDatabase.AssetPathToGUID(scene.path);
                                this.sceneGuidsToValidate.Remove(guid);
                                this.sceneGuidsNotToValidate.Add(guid);
                            }
                        }
                    }
                    else if (s.Scene.Type == ValidationItem.SceneIncludeType.ScenesInFolder)
                    {
                        foreach (var guid in AssetDatabase.FindAssets("t:Scene", new string[] { s.Scene.Value }))
                        {
                            this.sceneGuidsToValidate.Remove(guid);
                            this.sceneGuidsNotToValidate.Add(guid);
                        }
                    }
                }
            }
        }

        public void UpdateAssets()
        {
            this.assetsToValidate.Clear();

            var assetBundleNames = AssetDatabase.GetAllAssetBundleNames().ToHashSet();

            // Include
            {
                var includePaths = this.Include
                    .Where(x => x.Enabled && x.Type == ValidationItem.ValidationItemType.Asset && x.Asset.IsValid)
                    .GroupBy(x => x.Asset.Filter);

                foreach (var filterGroup in includePaths)
                {
                    var folderPaths = filterGroup.Where(x => System.IO.Directory.Exists(x.Asset.Path)).Select(x => x.Asset.Path).ToArray();
                    var filePaths = filterGroup.Where(x => System.IO.File.Exists(x.Asset.Path)).Select(x => x.Asset.Path).ToArray();
                    var filter = filterGroup.Key;

                    if (folderPaths.Length > 0)
                    {
                        string[] guids = AssetDatabase.FindAssets(filter, folderPaths);
                        foreach (var guid in guids)
                        {
                            this.assetsToValidate.Add(guid);
                        }
                    }

                    if (filePaths.Length > 0)
                    {
                        foreach (var path in filePaths)
                        {
                            var guid = AssetDatabase.AssetPathToGUID(path);
                            if (!string.IsNullOrEmpty(guid))
                            {
                                this.assetsToValidate.Add(guid);
                            }
                        }
                    }
                }

                var bundlePaths = this.Include
                    .Where(x => x.Enabled && x.Type == ValidationItem.ValidationItemType.AssetBundle && x.AssetBundle != null && assetBundleNames.Contains(x.AssetBundle));

                foreach (var assetBundle in bundlePaths)
                {
                    foreach (var path in AssetDatabase.GetAssetPathsFromAssetBundle(assetBundle.AssetBundle))
                    {
                        var guid = AssetDatabase.AssetPathToGUID(path);
                        if (!string.IsNullOrEmpty(guid))
                        {
                            this.assetsToValidate.Add(guid);
                        }
                    }
                }

                if (AddressablesUtility.AddressablesAvailable)
                {
                    var addressableGroups = AddressablesUtility.GetAddressableGroupNames().ToHashSet();

                    var addressables = this.Include
                        .Where(x => x.Enabled && x.Type == ValidationItem.ValidationItemType.AddressableGroup && x.AddressableGroup != null && addressableGroups.Contains(x.AddressableGroup));

                    foreach (var group in addressables)
                    {
                        foreach (var path in AddressablesUtility.GetAssetPathsInGroup(group.AddressableGroup))
                        {
                            var guid = AssetDatabase.AssetPathToGUID(path);
                            if (!string.IsNullOrEmpty(guid))
                            {
                                this.assetsToValidate.Add(guid);
                            }
                        }
                    }
                }
            }

            // Exclude
            {
                var excludePaths = this.Exclude
                    .Where(x => x.Enabled && x.Type == ValidationItem.ValidationItemType.Asset && x.Asset.IsValid)
                    .GroupBy(x => x.Asset.Filter);

                foreach (var filterGroup in excludePaths)
                {
                    var folderPaths = filterGroup.Where(x => System.IO.Directory.Exists(x.Asset.Path)).Select(x => x.Asset.Path).ToArray();
                    var filePaths = filterGroup.Where(x => System.IO.File.Exists(x.Asset.Path)).Select(x => x.Asset.Path).ToArray();
                    var filter = filterGroup.Key;

                    if (folderPaths.Length > 0)
                    {
                        string[] guids = AssetDatabase.FindAssets(filter, folderPaths);
                        foreach (var guid in guids)
                        {
                            this.assetsToValidate.Remove(guid);
                        }
                    }

                    if (filePaths.Length > 0)
                    {
                        foreach (var path in filePaths)
                        {
                            var guid = AssetDatabase.AssetPathToGUID(path);
                            if (!string.IsNullOrEmpty(guid))
                            {
                                this.assetsToValidate.Remove(guid);
                            }
                        }
                    }
                }

                var bundlePaths = this.Exclude
                    .Where(x => x.Enabled && x.Type == ValidationItem.ValidationItemType.AssetBundle && x.AssetBundle != null && assetBundleNames.Contains(x.AssetBundle))
                    .SelectMany(x => AssetDatabase.GetAssetPathsFromAssetBundle(x.AssetBundle));

                foreach (var path in bundlePaths)
                {
                    var guid = AssetDatabase.AssetPathToGUID(path);
                    if (!string.IsNullOrEmpty(guid))
                    {
                        this.assetsToValidate.Remove(guid);
                    }
                }

                if (AddressablesUtility.AddressablesAvailable)
                {
                    var addressableGroups = AddressablesUtility.GetAddressableGroupNames().ToHashSet();

                    var addressables = this.Exclude
                        .Where(x => x.Enabled && x.Type == ValidationItem.ValidationItemType.AddressableGroup && x.AddressableGroup != null && addressableGroups.Contains(x.AddressableGroup));

                    foreach (var group in addressables)
                    {
                        foreach (var path in AddressablesUtility.GetAssetPathsInGroup(group.AddressableGroup))
                        {
                            var guid = AssetDatabase.AssetPathToGUID(path);
                            if (!string.IsNullOrEmpty(guid))
                            {
                                this.assetsToValidate.Remove(guid);
                            }
                        }
                    }
                }
            }
        }

        [Serializable]
        public class SerializableSessionConfigData : ISessionConfigData
        {
            public List<ValidationItem> Include;
            public List<ValidationItem> Exclude;

            [NonSerialized]
            public Action OnSaveChanges;

            public SerializableSessionConfigData(IList<ValidationItem> include, IList<ValidationItem> exclude, Action onSaveChanges = null)
            {
                if (include != null)
                    this.Include = include.ToList();
                else 
                    this.Include = new List<ValidationItem>();

                if (exclude != null)
                    this.Exclude = exclude.ToList();
                else
                    this.Exclude = new List<ValidationItem>();

                this.OnSaveChanges = onSaveChanges;
            }

            public string Name => "Config";

            public string Description => null;

            public SdfIconType Icon => SdfIconType.FolderFill;

            IList<ValidationItem> ISessionConfigData.Include => this.Include;

            IList<ValidationItem> ISessionConfigData.Exclude => this.Exclude;

            void ISessionConfigData.SaveChanges()
            {
                if (this.OnSaveChanges != null)
                {
                    this.OnSaveChanges();
                }
            }
        }
    }

    [Serializable]
    public struct ValidationItem
    {
        public bool Enabled;
        public ValidationItemType Type;
        public AssetToValidate Asset;
        public UnityEngine.Object Object;
        public SceneToValidate Scene;
        public string AssetBundle;
        public string AddressableGroup;

        public static ValidationItem FromSceneGuid(string guid, bool includeAssetDeps = false) => new ValidationItem()
        {
            Type = ValidationItemType.Scene,
            Enabled = true,
            Scene = new SceneToValidate()
            {
                Type = SceneIncludeType.SceneGuid,
                Value = guid,
                IncludeAssetDependencies = includeAssetDeps,
            },
        };

        public static ValidationItem FromSceneFolderPath(string path, bool includeAssetDeps = false) => new ValidationItem()
        {
            Type = ValidationItemType.Scene,
            Enabled = true,
            Scene = new SceneToValidate()
            {
                Type = SceneIncludeType.ScenesInFolder,
                Value = path,
                IncludeAssetDependencies = includeAssetDeps,
            },
        };

        public static ValidationItem FromScenePath(string path, bool includeAssetDeps = false) => new ValidationItem()
        {
            Type = ValidationItemType.Scene,
            Enabled = true,
            Scene = new SceneToValidate()
            {
                Type = SceneIncludeType.SceneGuid,
                IncludeAssetDependencies = includeAssetDeps,
                Value = AssetDatabase.AssetPathToGUID(path),
            },
        };

        public static ValidationItem FromOpenScenes(bool includeAssetDeps = false) => new ValidationItem()
        {
            Type = ValidationItemType.Scene,
            Enabled = true,
            Scene = new SceneToValidate()
            {
                Type = SceneIncludeType.OpenScenes,
                IncludeAssetDependencies = includeAssetDeps,
            },
        };

        public static ValidationItem FromScenesInBuildOptions(bool includeAssetDeps = false) => new ValidationItem()
        {
            Type = ValidationItemType.Scene,
            Enabled = true,
            Scene = new SceneToValidate()
            {
                Type = SceneIncludeType.ScenesInBuildOptions,
                IncludeAssetDependencies = includeAssetDeps,
            },
        };

        public static ValidationItem FromUnityObjectReference(UnityEngine.Object obj) => new ValidationItem()
        {
            Type = ValidationItemType.Object,
            Enabled = true,
            Object = obj,
        };

        public static ValidationItem FromAssetPath(string path) => new ValidationItem()
        {
            Type = ValidationItemType.Asset,
            Enabled = true,
            Asset = new AssetToValidate()
            {
                Path = path,
            }
        };

        public static ValidationItem FromAssetPath(string path, string filter = null) => new ValidationItem()
        {
            Type = ValidationItemType.Asset,
            Enabled = true,
            Asset = new AssetToValidate()
            {
                Path = path,
                Filter = filter
            }
        };

        public static ValidationItem FromAssetBundle(string assetBundle) => new ValidationItem()
        {
            Type = ValidationItemType.AssetBundle,
            Enabled = true,
            AssetBundle = assetBundle,
        };

        public static ValidationItem FromAddressableGroup(string addressableGroup) => new ValidationItem()
        {
            Type = ValidationItemType.AddressableGroup,
            Enabled = true,
            AddressableGroup = addressableGroup,
        };

        [Serializable]
        public struct AssetToValidate
        {
            public string Path;
            public string Filter;

            public bool IsValid => !string.IsNullOrEmpty(this.Path);
        }

        [Serializable]
        public struct SceneToValidate
        {
            public SceneIncludeType Type;
            public string Value;
            public bool IncludeAssetDependencies;
        }

        public enum ValidationItemType
        {
            Asset,
            Object,
            Scene,
            AssetBundle,
            AddressableGroup,
        }

        public enum SceneIncludeType
        {
            ScenesInFolder,
            ScenesInBuildOptions,
            OpenScenes,
            SceneGuid
        }
    }
}
#endif