//-----------------------------------------------------------------------
// <copyright file="GlobalSessionConfigData.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
using Sirenix.OdinInspector;
using Sirenix.OdinInspector.Editor;
using Sirenix.Serialization;
using Sirenix.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace Sirenix.OdinValidator.Editor
{
    [OdinValidatorConfig]
    public class GlobalSessionConfigData : GlobalConfig<GlobalSessionConfigData>, ISessionConfigData
    {
        public List<ValidationItem> Include = new List<ValidationItem>();
        public List<ValidationItem> Exclude = new List<ValidationItem>();

        public string Name => "For everyone";

        public string Description => "TODO";

        public SdfIconType Icon => SdfIconType.PeopleFill;

        IList<ValidationItem> ISessionConfigData.Include => this.Include;
        IList<ValidationItem> ISessionConfigData.Exclude => this.Exclude;

        public void SaveChanges()
        {
            EditorUtility.SetDirty(this);
        }

        protected override void OnConfigAutoCreated()
        {
            this.Include = new List<ValidationItem>()
            {
                ValidationItem.FromOpenScenes(),
                ValidationItem.FromScenesInBuildOptions(),
                ValidationItem.FromSceneFolderPath("Assets"),
                ValidationItem.FromAssetPath("Assets"),
            };
        }
    }

    public class LocalSessionConfigData : ISessionConfigData
    {
        private static EditorPrefString localDataPath;
        private static LocalSessionConfigData instance;

        public static string DefaultLocalDataPath => Application.persistentDataPath.TrimEnd('/', '\\') + "/Odin Validator/localconfig.data";

        public static LocalSessionConfigData Instance
        {
            get
            {
                if (instance == null)
                {
                    if (File.Exists(LocalDataPath))
                    {
                        var bytes = File.ReadAllBytes(LocalDataPath);

                        try
                        {
                            instance = SerializationUtility.DeserializeValue<LocalSessionConfigData>(bytes, DataFormat.Binary);
                        }
                        catch (Exception ex)
                        {
                            Debug.LogError($"Error while deserializing local validation datas from file '{LocalDataPath}'. Local validation datas have been lost. The exception thrown was: {ex}");
                            Debug.LogException(ex);
                            instance = new LocalSessionConfigData();
                        }
                    }
                    else
                    {
                        instance = new LocalSessionConfigData();
                    }
                }

                return instance;
            }
        }

        public static EditorPrefString LocalDataPath
        {
            get
            {
                if (localDataPath == null)
                {
                    localDataPath = new EditorPrefString("SIRENIX_ODINVALIDATOR_LOCALDATAPATH", DefaultLocalDataPath);
                }

                if (string.IsNullOrEmpty(localDataPath.Value))
                {
                    localDataPath.Value = DefaultLocalDataPath;
                }

                return localDataPath;
            }
        }

        public List<ValidationItem> Include = new List<ValidationItem>();
        public List<ValidationItem> Exclude = new List<ValidationItem>();

        IList<ValidationItem> ISessionConfigData.Include => this.Include;
        IList<ValidationItem> ISessionConfigData.Exclude => this.Exclude;

        public string Name => "For this machine";

        public string Description => "TODO";

        public SdfIconType Icon => SdfIconType.DisplayFill;

        public void SaveChanges()
        {
            var bytes = SerializationUtility.SerializeValue(this, DataFormat.Binary);
            var dir = Path.GetDirectoryName(LocalDataPath);
            Directory.CreateDirectory(dir);
            File.WriteAllBytes(LocalDataPath, bytes);
        }

        private LocalSessionConfigData()
        {

        }
    }
}
#endif