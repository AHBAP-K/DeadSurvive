//-----------------------------------------------------------------------
// <copyright file="GlobalValidationConfig.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor;
    using static SceneValidationWidget;

    public static class GlobalValidationConfig
    {
        public static readonly EditorPrefBool EnableOnLoad = new EditorPrefBool("Odin_Validator_" + nameof(EnableOnLoad), true);
        public static readonly EditorPrefBool ValidateOnLoad = new EditorPrefBool("Odin_Validator_" + nameof(ValidateOnLoad), true);
        public static readonly EditorPrefBool DeepValidation = new EditorPrefBool("Odin_Validator_" + nameof(DeepValidation), false);
        public static readonly EditorPrefBool ContinuouslyValidateVisibleIssues = new EditorPrefBool("Odin_Validator_" + nameof(ContinuouslyValidateVisibleIssues), false);
        public static readonly EditorPrefBool PauseValidationWhileWorkingInSceneView = new EditorPrefBool("Odin_Validator_" + nameof(PauseValidationWhileWorkingInSceneView), true);
        public static readonly EditorPrefBool PingOnDoubleClick = new EditorPrefBool("Odin_Validator_" + nameof(PingOnDoubleClick), true);
        public static readonly EditorPrefBool FocusObjectOnDoubleClick = new EditorPrefBool("Odin_Validator_" + nameof(FocusObjectOnDoubleClick), true);
        public static readonly EditorPrefBool FrameSelection = new EditorPrefBool("Odin_Validator_" + nameof(FrameSelection), true);
        public static readonly EditorPrefBool OpenComponentInInspectorAndCloseOthers = new EditorPrefBool("Odin_Validator_" + nameof(OpenComponentInInspectorAndCloseOthers), true);
        public static readonly EditorPrefBool SkipFirstSample = new EditorPrefBool("Odin_Validator_" + nameof(SkipFirstSample), true);
        public static readonly EditorPrefBool ShowWidget = new EditorPrefBool("Odin_Validator_" + nameof(ShowWidget), true);
        public static readonly EditorPrefBool DebugMode = new EditorPrefBool("Odin_Validator_" + nameof(DebugMode), false);
        public static readonly EditorPrefBool ShowFeedbackButton = new EditorPrefBool("Odin_Validator_" + nameof(ShowFeedbackButton), true);
        public static readonly EditorPrefBool ShowWidgetOnlyWhenErrorOrWarnings = new EditorPrefBool("Odin_Validator_" + nameof(ShowWidgetOnlyWhenErrorOrWarnings), false);
        public static readonly EditorPrefEnum<WidgetAnchor> WidgetAnchor = new EditorPrefEnum<WidgetAnchor>("Odin_Validator_" + nameof(WidgetAnchor), SceneValidationWidget.WidgetAnchor.BottomLeft);
        public static readonly EditorPrefFloat WidgetOffsetX = new EditorPrefFloat("Odin_Validator_" + nameof(WidgetOffsetX), 20);
        public static readonly EditorPrefFloat WidgetOffsetY = new EditorPrefFloat("Odin_Validator_" + nameof(WidgetOffsetY), 20);
        public static readonly EditorPrefBool EnableLeakDetection = new EditorPrefBool("Odin_Validator_" + nameof(EnableLeakDetection), true);
    }
}
#endif