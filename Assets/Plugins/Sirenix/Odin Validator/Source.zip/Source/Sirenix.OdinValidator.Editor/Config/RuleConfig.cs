//-----------------------------------------------------------------------
// <copyright file="RuleConfig.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor;
    using Sirenix.OdinInspector.Editor.Internal;
    using Sirenix.OdinInspector.Editor.Validation;
    using Sirenix.Serialization;
    using Sirenix.Serialization.Utilities;
    using Sirenix.Utilities;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using UnityEditor;
    using UnityEngine;
    using SerializationUtility = Serialization.SerializationUtility;

    [OdinValidatorConfig]
    public class RuleConfig : GlobalConfig<RuleConfig>, ISerializedRulesContainer
    {
        [SerializeField]
        private List<SerializedRule> projectRules;

        [NonSerialized]
        private List<SerializedRule> localRules;

        [NonSerialized]
        private bool hasLoadedRules = false;

        private Dictionary<Type, InstantiationData> instantiationLookup;

        private static EditorPrefString localRulePath;
        private static List<SerializedRule> defaultRules;

        public static EditorPrefString LocalRulePath
        {
            get
            {
                if (localRulePath == null)
                {
                    localRulePath = new EditorPrefString("SIRENIX_ODINVALIDATOR_LOCALRULEPATH", DefaultLocalRulePath);
                }

                if (string.IsNullOrEmpty(localRulePath.Value))
                {
                    localRulePath.Value = DefaultLocalRulePath;
                }

                return localRulePath;
            }
        }

        public static string DefaultLocalRulePath => Application.persistentDataPath.TrimEnd('/', '\\') + "/Odin Validator/localrules.data";

        public void SaveRules()
        {
            if (!this.hasLoadedRules) return;

            if (this.projectRules != null)
            {
                foreach (var rule in this.projectRules)
                {
                    rule.Save();
                }

                for (int i = this.projectRules.Count - 1; i >= 0; i--)
                {
                    if (this.projectRules[i].ValidatorType == null)
                    {
                        this.projectRules.RemoveAt(i);
                    }
                }
            }

            EditorUtility.SetDirty(this);

            if (this.localRules == null || this.localRules.Count == 0)
            {
                if (File.Exists(LocalRulePath))
                {
                    File.Delete(LocalRulePath);
                }
            }
            else
            {
                foreach (var rule in this.localRules)
                {
                    rule.Save();
                }

                for (int i = this.localRules.Count - 1; i >= 0; i--)
                {
                    if (this.localRules[i].ValidatorType == null)
                    {
                        this.localRules.RemoveAt(i);
                    }
                }

                var bytes = SerializationUtility.SerializeValue(this.localRules, DataFormat.Binary);
                var dir = Path.GetDirectoryName(LocalRulePath);
                Directory.CreateDirectory(dir);
                File.WriteAllBytes(LocalRulePath, bytes);
            }

            if (this.instantiationLookup != null)
                this.RebuildInstantiationLookup();
        }

        public void LoadRules()
        {
            if (this.projectRules != null)
            {
                foreach (var rule in this.projectRules)
                {
                    rule.Load();
                }

                for (int i = this.projectRules.Count - 1; i >= 0; i--)
                {
                    if (this.projectRules[i].ValidatorType == null)
                    {
                        this.projectRules.RemoveAt(i);
                    }
                }
            }

            if (File.Exists(LocalRulePath))
            {
                var bytes = File.ReadAllBytes(LocalRulePath);

                try
                {
                    this.localRules = SerializationUtility.DeserializeValue<List<SerializedRule>>(bytes, DataFormat.Binary);

                    if (this.localRules != null)
                    {
                        foreach (var rule in this.localRules)
                        {
                            rule.Load();
                        }

                        for (int i = this.localRules.Count - 1; i >= 0; i--)
                        {
                            if (this.localRules[i].ValidatorType == null)
                            {
                                this.localRules.RemoveAt(i);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"Error while deserializing local validation rules from file '{LocalRulePath}'. Local validation rules have been lost. The exception thrown was: {ex}");
                    Debug.LogException(ex);
                }
            }
            else
            {
                this.localRules = null;
            }

            this.hasLoadedRules = true;
        }

        public RuleDataWrapper GetRuleDataWrapper()
        {
            if (!this.hasLoadedRules)
            {
                this.LoadRules();
            }

            return new RuleDataWrapper(this, this.projectRules, this.localRules, GetDefaultRules());
        }

        public static Validator InstantiateValidator(Type validatorType)
        {
            var instance = Instance;

            if (instance.instantiationLookup == null)
            {
                instance.RebuildInstantiationLookup();
            }

            var lookup = instance.instantiationLookup;

            InstantiationData data;

            if (!lookup.TryGetValue(validatorType, out data))
            {
                Debug.LogError("Tried to instantiate rule '" + validatorType.GetNiceName() + "' which does not exist in the RuleConfig.");
                return null;
            }

            if (!data.Enabled) return null;

            return FastDeepCopier.DeepCopy(data.Prototype);
        }

        private class InstantiationData
        {
            public bool Enabled;
            public Validator Prototype;
        }

        private void RebuildInstantiationLookup()
        {
            if (!this.hasLoadedRules)
            {
                this.LoadRules();
            }

            if (this.instantiationLookup == null)
                this.instantiationLookup = new Dictionary<Type, InstantiationData>();
            else this.instantiationLookup.Clear();

            var localRules = this.localRules;
            var projectRules = this.projectRules;
            var defaultRules = GetDefaultRules();

            foreach (var rule in defaultRules)
            {
                this.instantiationLookup[rule.ValidatorType] = new InstantiationData()
                {
                    Enabled = rule.Enabled,
                    Prototype = rule.DataOverride,
                };
            }

            if (projectRules != null)
            {
                foreach (var rule in projectRules)
                {
                    InstantiationData data;

                    if (rule.ValidatorType == null || !this.instantiationLookup.TryGetValue(rule.ValidatorType, out data))
                        continue;

                    if (rule.EnabledOverridden)
                    {
                        data.Enabled = rule.Enabled;
                    }

                    if (rule.DataOverride != null)
                    {
                        data.Prototype = rule.DataOverride;
                    }
                }
            }

            if (localRules != null)
            {
                foreach (var rule in localRules)
                {
                    InstantiationData data;

                    if (rule.ValidatorType == null || !this.instantiationLookup.TryGetValue(rule.ValidatorType, out data))
                        continue;

                    if (rule.EnabledOverridden)
                    {
                        data.Enabled = rule.Enabled;
                    }

                    if (rule.DataOverride != null)
                    {
                        data.Prototype = rule.DataOverride;
                    }
                }
            }
        }

        public static List<SerializedRule> GetDefaultRules()
        {
            if (defaultRules == null)
            {
                defaultRules = InstantiateDefaultRules();
            }

            return defaultRules;
        }

        public static List<SerializedRule> InstantiateDefaultRules()
        {
            List<SerializedRule> defaults = new List<SerializedRule>();

            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                foreach (var attr in assembly.GetAttributes<RegisterValidationRuleAttribute>()
                    //.OrderByDescending(x => x.Category)
                    .OrderByDescending(x => x.Name))
                {
                    if (attr.ValidatorType == null) continue;

                    if (!typeof(Validator).IsAssignableFrom(attr.ValidatorType))
                    {
                        Debug.LogError($"Registered validator rule type '{attr.ValidatorType.GetNiceFullName()}' does not implement IRuleValidator; did you inherit from the wrong type?");
                        continue;
                    }

                    if (attr.ValidatorType.IsGenericType)
                    {
                        Debug.LogError($"Registered validator rule type '{attr.ValidatorType.GetNiceFullName()}' is generic! Generic rules are not allowed, as they cannot be configured for all variants.");
                        continue;
                    }

                    if (attr.ValidatorType.GetConstructor(Type.EmptyTypes) == null)
                    {
                        Debug.LogError($"Registered validator rule type '{attr.ValidatorType.GetNiceFullName()}' must have a public parameterless constructor.");
                        continue;
                    }

                    var instance = Activator.CreateInstance(attr.ValidatorType) as Validator;

                    var rule = new SerializedRule(attr.ValidatorType, attr)
                    {
                        Enabled = attr.EnabledByDefault,
                        ValidatorType = attr.ValidatorType,
                        Attr = attr,
                        DataOverride = instance,
                    };

                    defaults.Add(rule);
                }
            }

            return defaults;
            //return defaults.OrderBy(n => n.ValidatorType.FullName).ToList();
        }

        public void SetProjectRules(List<SerializedRule> rules)
        {
            this.projectRules = rules;
        }

        public void SetLocalRules(List<SerializedRule> rules)
        {
            this.localRules = rules;
        }
    }
}
#endif