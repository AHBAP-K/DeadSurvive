//-----------------------------------------------------------------------
// <copyright file="AutomationConfig.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector;
    using Sirenix.Utilities;
    using System;
    using UnityEditor;
    using UnityEngine;
    using UnityEditor.Build.Reporting;
    using UnityEditor.Build;
    using Sirenix.OdinInspector.Editor;
    using System.Collections.Generic;
    using Sirenix.OdinInspector.Editor.Validation;

    [OdinValidatorConfig]
    public class AutomationConfig : GlobalConfig<AutomationConfig>
    {
        [ToggleGroup("OnPlayMode", "On Play Mode", CollapseOthersOnExpand = false)]
        public bool OnPlayMode;

        [ToggleGroup("OnPlayMode"), LabelText("If Warnings")]
        public OnPlayModeActions OnPlayModeIfWarnings;

        [ToggleGroup("OnPlayMode"), LabelText("If Errors")]
        public OnPlayModeActions OnPlayModeIfErrors = OnPlayModeActions.OpenValidator | OnPlayModeActions.StopPlayMode;

        [ToggleGroup("OnPlayMode"), LabelText("Always Complete Validation")]
        public bool OnPlayModeAlwaysCompleteValidationFully;

        [ToggleGroup("OnPlayMode"), LabelText("Flash Screen")]
        public bool OnPlayModeFlashScreen;

        [ToggleGroup("OnPlayMode")]
        public ValidationSetup OnPlayModeSetup;

        [ToggleGroup("OnBuild", "On Build", CollapseOthersOnExpand = false)]
        public bool OnBuild;

        [ToggleGroup("OnBuild"), LabelText("If Warnings")]
        public OnBuildActions OnBuildIfWarnings;

        [ToggleGroup("OnBuild"), LabelText("If Errors")]
        public OnBuildActions OnBuildIfErrors = OnBuildActions.OpenValidator | OnBuildActions.StopBuild;

        [ToggleGroup("OnBuild"), LabelText("Always Complete Validation")]
        public bool OnBuildAlwaysCompleteValidationFully;

        [ToggleGroup("OnBuild"), LabelText("Flash Screen")]
        public bool OnBuildFlashScreen;

        [ToggleGroup("OnBuild")]
        public ValidationSetup OnBuildSetup;

        [ToggleGroup("OnProjectStartup", "On Project Startup", CollapseOthersOnExpand = false)]
        public bool OnProjectStartup;

        [ToggleGroup("OnProjectStartup"), LabelText("If Warnings")]
        public OnProjectStartupActions OnProjectStartupIfWarnings;

        [ToggleGroup("OnProjectStartup"), LabelText("If Errors")]
        public OnProjectStartupActions OnProjectStartupIfErrors = OnProjectStartupActions.OpenValidator;

        [ToggleGroup("OnProjectStartup"), LabelText("Always Complete Validation")]
        public bool OnProjectStartupAlwaysCompleteValidationFully;

        [ToggleGroup("OnProjectStartup"), LabelText("Flash Screen")]
        public bool OnProjectStartupFlashScreen;

        [ToggleGroup("OnProjectStartup")]
        public ValidationSetup OnProjectStartupSetup;

        public static bool HasReloadedBeforeThisSession
        {
            get
            {
                return SessionState.GetBool("OdinValidator_HasReloadedBeforeThisSession", false);
            }
            set
            {
                SessionState.SetBool("OdinValidator_HasReloadedBeforeThisSession", value);
            }
        }

        [Flags]
        public enum OnPlayModeActions
        {
            None = 0,
            OpenValidator = 1 << 0,
            StopPlayMode = 1 << 1,
            LogToConsole = 1 << 2,
        }

        [Flags]
        public enum OnBuildActions
        {
            None = 0,
            OpenValidator = 1 << 0,
            StopBuild = 1 << 1,
            LogToConsole = 1 << 2,
        }

        [Flags]
        public enum OnProjectStartupActions
        {
            None = 0,
            OpenValidator = 1 << 0,
            LogToConsole = 1 << 1,
        }

        [Serializable]
        [InlineProperty]
        [HideLabel]
        public struct ValidationSetup
        {
            public enum RunKind
            {
                GlobalValidation,
                Custom,
            }

            [HideLabel]
            public RunKind Profile;

            [ShowIf("@Profile == RunKind.Custom"), InfoBox("Nicer GUI for the Custom option is coming soon!", InfoMessageType.Warning)]
            public SessionConfig.SerializableSessionConfigData SessionConfigData;
        }

        private static bool IsHeadlessOrBatchMode => SystemInfo.graphicsDeviceType == UnityEngine.Rendering.GraphicsDeviceType.Null || UnityEditorInternal.InternalEditorUtility.inBatchMode;

        [InitializeOnLoadMethod]
        private static void InitHooks()
        {
            if (IsHeadlessOrBatchMode)
            {
                if (!HasInstanceLoaded)
                {
                    LoadInstanceIfAssetExists();
                }

                if (!HasInstanceLoaded)
                {
                    Debug.LogError("Odin's validation config asset could not be loaded during batch mode or headless run of the Unity Editor. No validation has taken place, whether it was configured to do so or not.");
                    return;
                }

                ActuallyInitHooks();
            }
            else
            {
                UnityEditorEventUtility.DelayAction(ActuallyInitHooks);
            }

        }

        private static void ActuallyInitHooks()
        {
            EditorApplication.playModeStateChanged += OnPlayModeStateChanged;

            var inst = Instance;

            if (inst.OnProjectStartup && !HasReloadedBeforeThisSession)
            {
                RunValidationScan(
                    name: "On Project Startup",
                    setup: inst.OnProjectStartupSetup,
                    allowOpenClosedScenes: true,
                    stopEvent: null,
                    logErrors: (inst.OnProjectStartupIfErrors & OnProjectStartupActions.LogToConsole) != 0,
                    logWarnings: (inst.OnProjectStartupIfWarnings & OnProjectStartupActions.LogToConsole) != 0,
                    stopOnErrors: false,
                    stopOnWarnings: false,
                    openValidatorIfErrors: (inst.OnProjectStartupIfErrors & OnProjectStartupActions.OpenValidator) != 0,
                    openValidatorIfWarnings: (inst.OnProjectStartupIfWarnings & OnProjectStartupActions.OpenValidator) != 0,
                    completeValidationFully: inst.OnProjectStartupAlwaysCompleteValidationFully,
                    flashScreen: inst.OnProjectStartupFlashScreen
                );
            }

            HasReloadedBeforeThisSession = true;
        }

        private static void OnPlayModeStateChanged(PlayModeStateChange change)
        {
            var inst = Instance;

            if (inst.OnPlayMode && change == PlayModeStateChange.ExitingEditMode)
            {
                RunValidationScan(
                    name: "On Play Mode",
                    setup: inst.OnPlayModeSetup,
                    allowOpenClosedScenes: false,
                    stopEvent: () => EditorApplication.isPlaying = false,
                    logErrors: (inst.OnPlayModeIfErrors & OnPlayModeActions.LogToConsole) != 0,
                    logWarnings: (inst.OnPlayModeIfWarnings & OnPlayModeActions.LogToConsole) != 0,
                    stopOnErrors: (inst.OnPlayModeIfErrors & OnPlayModeActions.StopPlayMode) != 0,
                    stopOnWarnings: (inst.OnPlayModeIfWarnings & OnPlayModeActions.StopPlayMode) != 0,
                    openValidatorIfErrors: (inst.OnPlayModeIfErrors & OnPlayModeActions.OpenValidator) != 0,
                    openValidatorIfWarnings: (inst.OnPlayModeIfWarnings & OnPlayModeActions.OpenValidator) != 0,
                    completeValidationFully: inst.OnPlayModeAlwaysCompleteValidationFully,
                    flashScreen: inst.OnPlayModeFlashScreen
                );
            }
        }

        public static void TriggerOnBuild()
        {
            var inst = Instance;

            if (inst.OnBuild)
            {
                RunValidationScan(
                    name: "On Build",
                    setup: inst.OnBuildSetup,
                    allowOpenClosedScenes: true,
                    stopEvent: () => throw new BuildFailedException("'On Build' validation hook throwing exception to stop build process"),
                    logErrors: (inst.OnBuildIfErrors & OnBuildActions.LogToConsole) != 0,
                    logWarnings: (inst.OnBuildIfWarnings & OnBuildActions.LogToConsole) != 0,
                    stopOnErrors: (inst.OnBuildIfErrors & OnBuildActions.StopBuild) != 0,
                    stopOnWarnings: (inst.OnBuildIfWarnings & OnBuildActions.StopBuild) != 0,
                    openValidatorIfErrors: (inst.OnBuildIfErrors & OnBuildActions.OpenValidator) != 0,
                    openValidatorIfWarnings: (inst.OnBuildIfWarnings & OnBuildActions.OpenValidator) != 0,
                    completeValidationFully: inst.OnBuildAlwaysCompleteValidationFully,
                    flashScreen: inst.OnBuildFlashScreen
                );
            }
        }

        private static void RunValidationScan(string name, ValidationSetup setup, bool allowOpenClosedScenes, Action stopEvent, bool logErrors, bool logWarnings, bool stopOnErrors, bool stopOnWarnings, bool openValidatorIfErrors, bool openValidatorIfWarnings, bool completeValidationFully, bool flashScreen)
        {
            if (!logErrors 
                && !logWarnings
                && !stopOnErrors
                && !stopOnWarnings
                && !openValidatorIfErrors
                && !openValidatorIfWarnings)
            {
                // We are supposed to do nothing at all
                // Might as well not validate
                return;
            }

            ValidationSession session = null;
            IEnumerable<PersistentValidationResult> enumerator;

            Debug.Log("Running " + name + " validation hook...");
            bool shouldDisposeSession = false;

            try
            {
                if (setup.Profile == ValidationSetup.RunKind.GlobalValidation)
                {
                    session = ValidationSession.GlobalValidationSession;
                    enumerator = session.ValidateEverythingEnumerator(true, allowOpenClosedScenes, true, !IsHeadlessOrBatchMode);
                }
                else
                {
                    shouldDisposeSession = true;
                    var config = new SessionConfig(setup.SessionConfigData);
                    session = new ValidationSession(name, config);
                    enumerator = session.ValidateEverythingEnumerator(true, allowOpenClosedScenes, false, !IsHeadlessOrBatchMode);
                }

                bool hadErrors = false;
                bool hadWarnings = false;

                foreach (var result in enumerator)
                {
                    if (result.Count == 0) continue;
                    ref var actualResult = ref result.HighestSeverityResult;

                    if (actualResult.ResultType == ValidationResultType.Error)
                    {
                        hadErrors = true;

                        if (logErrors)
                        {
                            Debug.LogError(result.ToNiceLogString());
                        }

                        if (!completeValidationFully && (logErrors || stopOnErrors || openValidatorIfErrors))
                            break;
                    }
                    else if (actualResult.ResultType == ValidationResultType.Warning)
                    {
                        hadWarnings = true;

                        if (logWarnings)
                        {
                            Debug.LogWarning(result.ToNiceLogString());
                        }

                        if (!completeValidationFully && (logWarnings || stopOnWarnings || openValidatorIfWarnings))
                            break;
                    }
                }

                bool shouldStopEvent = false;
                bool openValidator = false;

                if (hadErrors)
                {
                    shouldStopEvent |= stopOnErrors;
                    openValidator |= openValidatorIfErrors;
                }

                if (hadWarnings)
                {
                    shouldStopEvent |= stopOnWarnings;
                    openValidator |= openValidatorIfWarnings;
                }

                if (openValidator && !IsHeadlessOrBatchMode)
                {
                    ValidationSessionEditor.OpenOrFocusWindowForSession(session);
                }

                if (shouldStopEvent)
                {
                    Debug.LogError("Stopping " + name + " because validation failed!");

                    stopEvent();

                    if (!IsHeadlessOrBatchMode && flashScreen)
                    {
                        FlashScreen(); 
                    }
                }
            }
            finally
            {
                if (shouldDisposeSession && session != null)
                {
                    session.Dispose();
                }
            }
        }

        private static void FlashScreen()
        {
            Color color = new Color(1, 0, 0, 0.5f);
            Action<SceneView> flashScreen = null;

            double timeStarted = EditorApplication.timeSinceStartup;
            double flashSpeed = 0.3;
            int flashCount = 3;

            var windowsToRepaint = Resources.FindObjectsOfTypeAll<EditorWindow>();

            flashScreen = (sceneView) =>
            {
                var time = EditorApplication.timeSinceStartup;

                if (time - timeStarted >= flashSpeed * flashCount)
                {
                    UnityEditorEventUtility.DuringSceneGUI -= flashScreen;
                }
                else
                {
                    var timePassed = (time - timeStarted);
                    var distanceToFullColor = 1 - Math.Abs((timePassed % flashSpeed) - flashSpeed * 0.5) / (flashSpeed / 2);

                    var currentColor = color;
                    currentColor.a *= (float)distanceToFullColor;

                    var windowArea = sceneView.position;
                    windowArea.position = Vector2.zero;
                    windowArea.height -= 18f; // Adjust for bottom bar

                    Handles.BeginGUI();
                    Utilities.Editor.SirenixEditorGUI.DrawSolidRect(windowArea, currentColor);
                    Handles.EndGUI();
                }

                sceneView.Repaint();
            };

            UnityEditorEventUtility.DuringSceneGUI += flashScreen;

            foreach (var view in SceneView.sceneViews)
            {
                if (view is SceneView sceneView && sceneView != null)
                {
                    sceneView.Repaint();
                }
            }
        }
    }
    
    public class BuildEventHookTrigger : IPreprocessBuildWithReport
    {
        public int callbackOrder { get { return -2000; } }

        public void OnPreprocessBuild(BuildReport report)
        {
            AutomationConfig.TriggerOnBuild();
        }
    }
}
#endif