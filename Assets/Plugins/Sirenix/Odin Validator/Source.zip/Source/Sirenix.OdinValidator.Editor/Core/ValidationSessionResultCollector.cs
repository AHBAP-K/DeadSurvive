//-----------------------------------------------------------------------
// <copyright file="ValidationSessionResultCollector.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor;
    using Sirenix.OdinInspector.Editor.Validation;
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using UnityEditor;
    using UnityEngine;
    using static Sirenix.OdinValidator.Editor.ValidationSession;


    internal class ValidationSessionResultCollector : IDisposable
    {
        private string searchTerm;
        private bool isDisposed = false;
        private bool applyFilters = true;
        private int filteredItemsVersion = 1;
        private BackgroundTaskHandle populatorTask;
        private EditorPrefBool showErrors = new EditorPrefBool("Odin_Validator_" + nameof(showErrors), true);
        private EditorPrefBool showWarnings = new EditorPrefBool("Odin_Validator_" + nameof(showWarnings), true);
        private EditorPrefBool showValid = new EditorPrefBool("Odin_Validator_" + nameof(showValid), true);
        private ResizableColumn[] resizableColumns;
        private ResultItem[] filteredItems;
        private ResultItem[] allItems = new ResultItem[0];
        private HashSet<PersistentValidationResult> resultObjects = new HashSet<PersistentValidationResult>(new PersistentValidationResult.Comparer());
        private List<ValidationSessionResult> queue = new List<ValidationSessionResult>();
        private HashSet<BatchKey> queuedAddresses = new HashSet<BatchKey>();
        private MiniPool<ResultItem[]> resultItemPool = new MiniPool<ResultItem[]>(() => new ResultItem[100]);
        private List<int> toGiveTimeUpdate = new List<int>();
        private List<ResultItem> nextResultList = new List<ResultItem>(100);
        private List<ResultItem> toAdd = new List<ResultItem>(100);
        private HashSet<ValidationWorkItem> toRemove = new HashSet<ValidationWorkItem>();
        private Dictionary<PersistentValidationResult, ResultItem> toReplace = new Dictionary<PersistentValidationResult, ResultItem>(new PersistentValidationResult.Comparer());
        private List<int> toReplaceIfNotDirty = new List<int>();
        private ValidationSession validationSession;

        public Filter<SceneReference> SceneFilters = new Filter<SceneReference>();
        public Filter<Type> ObjectTypeFilters = new Filter<Type>();
        public Filter<Type> ValidatorTypeFilters = new Filter<Type>();
        public Filter<FixIdentifier> FixTypeFilters = new Filter<FixIdentifier>();

        public static event Action<ValidationSession> OnAnyResultsChanged;
        public event Action OnResultsChanged;

        public int QueuedItems => queue.Count;
        public int Length => GetFilteredItems().Length;
        public ref ResultItem this[int index] { get { return ref GetFilteredItems()[index]; } }

        public int WarningCount { get; private set; }
        public int ErrorCount { get; private set; }
        public int ValidCount { get; private set; }

        public ValidationSessionResultCollector(ValidationSession session)
        {
            this.validationSession = session;
            this.populatorTask = BackgroundTaskRunner.StartTask("Result view population for " + this.validationSession.Name, PopulateResultQueue());
        }

        private IEnumerator PopulateResultQueue()
        {
            while (true)
            {
                var p = this.ProcessQueueEnumerator();

                while (p.MoveNext())
                {
                    yield return p.Current;
                }

                yield return BackgroundTaskRunner.Relax;
            }
        }

        public string SearchTerm
        {
            get
            {
                return this.searchTerm;
            }
            set
            {
                if (this.searchTerm != value)
                {
                    this.MarkFiltersDirty();
                    this.searchTerm = value;
                }
            }
        }

        public bool ShowErrors
        {
            get => this.showErrors.Value;
            set
            {
                if (this.showErrors.Value != value)
                {
                    this.MarkFiltersDirty();
                    this.showErrors.Value = value;
                }
            }
        }

        public bool ShowWarnings
        {
            get => this.showWarnings.Value;
            set
            {
                if (this.showWarnings.Value != value)
                {
                    this.MarkFiltersDirty();
                    this.showWarnings.Value = value;
                }
            }
        }

        public bool ShowValid
        {
            get => this.showValid.Value;
            set
            {
                if (this.showValid.Value != value)
                {
                    this.MarkFiltersDirty();
                    this.showValid.Value = value;
                }
            }
        }

        internal bool ApplyFilters
        {
            get => this.applyFilters;
            set
            {
                if (this.applyFilters != value)
                {
                    this.MarkFiltersDirty();
                    this.applyFilters = value;
                }
            }
        }

        internal ResultItem[] GetFilteredItems()
        {
            if (this.filteredItems == null)
            {
                if (this.allItems.Length == 0)
                {
                    this.filteredItemsVersion++;
                    this.filteredItems = this.allItems.ToArray();
                }
                else
                {
                    var showAll = (!this.ShowErrors & !this.ShowWarnings & !this.ShowValid) || (this.ShowErrors & this.ShowWarnings & this.ShowValid)
                        && this.SceneFilters.HasFilter()
                        && this.ObjectTypeFilters.HasFilter()
                        && this.ValidatorTypeFilters.HasFilter()
                        && this.FixTypeFilters.HasFilter();

                    if (showAll)
                    {
                        this.filteredItems = ExplodeAndFinalize(this.allItems);
                        this.filteredItemsVersion++;
                    }
                    else
                    {
                        var partitioner = System.Collections.Concurrent.Partitioner.Create(0, this.allItems.Length);
                        var warnings = this.ShowWarnings;
                        var errors = this.ShowErrors;
                        var valids = this.ShowValid;
                        var strSearch = !string.IsNullOrEmpty(this.searchTerm);
                        var searchTerm = this.searchTerm;
                        var partitionResults = new System.Collections.Concurrent.ConcurrentBag<(int start, int len, ResultItem[] buffer)>();
                        var filter = this.applyFilters;

                        partitioner.AsParallel().ForAll(range =>
                        {
                            var count = 0;
                            var end = range.Item2;
                            var start = range.Item1;
                            var len = (end - start);

                            var partition = resultItemPool.Get();

                            if (partition.Length < len)
                            {
                                Array.Resize(ref partition, len * 2);
                            }

                            for (int i = start; i < end; i++)
                            {
                                ref var item = ref this.allItems[i];
                                var highestSeverityResult = item.Result.HighestSeverityResult;
                                var rType = highestSeverityResult.ResultType;

                                if (rType == ValidationResultType.Error && !errors)
                                    continue;

                                if (rType == ValidationResultType.Warning && !warnings)
                                    continue;

                                if (!valids && (rType == ValidationResultType.Valid || rType == ValidationResultType.IgnoreResult))
                                    continue;

                                if (strSearch && !FuzzySearch.Contains(searchTerm, item.SearchText, out item.Score))
                                    continue;

                                if (filter)
                                {
                                    if (this.FixTypeFilters.Enabled)
                                    {
                                        var fix = item.Result.HighestSeverityResult.Data.MangledFix;
                                        if (fix == null)
                                        {
                                            continue;
                                        }
                                        else if (!this.FixTypeFilters.ShouldInclude(fix.FixIdentifier))
                                        {
                                            continue;
                                        }
                                    }

                                    if (!this.ValidatorTypeFilters.ShouldInclude(item.Result.GetGenericValidatorType()))
                                        continue;

                                    if (!this.SceneFilters.ShouldInclude(item.Result.GetSceneReference()))
                                        continue;

                                    if (!this.ObjectTypeFilters.ShouldInclude(item.Result.GetObjectType()))
                                        continue;
                                }

                                partition[count++] = item;
                            }

                            partitionResults.Add((start, count, partition));
                        });

                        var partitions = partitionResults.OrderBy(x => x.start).ToArray();
                        var combined = new ResultItem[partitions.Sum(x => x.len)];
                        var offset = 0;

                        for (int i = 0; i < partitions.Length; i++)
                        {
                            Array.Copy(partitions[i].buffer, 0, combined, offset, partitions[i].len);
                            offset += partitions[i].len;
                            this.resultItemPool.Return(partitions[i].buffer);
                        }

                        this.filteredItems = ExplodeAndFinalize(combined);
                        this.filteredItemsVersion++;
                    }
                }
            }

            return this.filteredItems;
        }

        private ResultItem[] ExplodeAndFinalize(ResultItem[] src)
        {
            var result = new List<ResultItem>(this.allItems.Length);
            for (int i = 0; i < src.Length; i++)
            {
                ResultItem item = src[i];
                var iStart = result.Count;
                var explodeCount = item.Result.Count;

                if (explodeCount > 1)
                {
                    int j = 0;
                    foreach (var r in item.Result.Explode())
                    {
                        result.Add(new ResultItem()
                        {
                            LastSceneSetupChangeId = item.LastSceneSetupChangeId,
                            LastStateChangeTime = item.LastStateChangeTime,
                            Result = r,
                            Score = item.Score,
                            WorkItem = item.WorkItem,
                            ExplodeCount = explodeCount,
                            ExplodedIndex = j++,
                        });
                    }
                }
                else
                {
                    result.Add(item);
                }

                allItems[item.AllItemsIndex].FinalizeId = this.filteredItemsVersion;
                allItems[item.AllItemsIndex].FilteredIndex = iStart;

            }
            return result.ToArray();
        }

        internal void Enqueue(ArraySlice<ValidationSessionResult> batch)
        {
            this.queuedAddresses.Add(new BatchKey(batch[0].Result));

            foreach (var item in batch)
            {
                this.queue.Add(item);
            }
        }

        internal void Enqueue(ValidationSessionResult item)
        {
            this.queue.Add(item);
        }

        public void ProcessQueue()
        {
            this.populatorTask.Kill();
            this.populatorTask = BackgroundTaskRunner.StartTask("Result view population for " + this.validationSession.Name, PopulateResultQueue());
            var p = this.ProcessQueueEnumerator();
            while (p.MoveNext())
            {
            }
        }

        public IEnumerator ProcessQueueEnumerator()
        {
            if (this.queue.Count == 0)
                yield break;

            var qCopy = this.queue.ToArray();
            var qAddressesCopy = new HashSet<BatchKey>(this.queuedAddresses);

            this.queue.Clear();
            this.queuedAddresses.Clear();
            this.nextResultList.Clear();
            this.toRemove.Clear();
            this.toReplace.Clear();
            this.toReplaceIfNotDirty.Clear();
            this.toAdd.Clear();
            this.toGiveTimeUpdate.Clear();
            this.resultObjects.Clear();

            foreach (var item in this.allItems)
            {
                if (item.Result != null)
                {
                    this.resultObjects.Add(item.Result);
                }
            }


            // Build queue
            foreach (var item in qCopy)
            {
                if (item.Type == ValidationSession.ValidationSessionResult.ValidationSessionResultType.ObjectDeleted)
                {
                    toRemove.Add(item.WorkItem);
                }
                else if (item.Type == ValidationSession.ValidationSessionResult.ValidationSessionResultType.ResultAddedOrChanged)
                {
                    if (item.Result == null) throw new NullReferenceException();

                    var replace = this.resultObjects.Contains(item.Result);
                    if (replace)
                    {
                        toReplace[item.Result] = new ResultItem()
                        {
                            Result = item.Result,
                            WorkItem = item.WorkItem,
                            LastSceneSetupChangeId = UnitySceneSetupChangeId.SceneSetupChangeId,
                        };
                    }
                    else
                    {
                        toAdd.Add(new ResultItem()
                        {
                            Result = item.Result,
                            WorkItem = item.WorkItem,
                            LastSceneSetupChangeId = UnitySceneSetupChangeId.SceneSetupChangeId,
                        });
                    }
                }
                else if (item.Type == ValidationSession.ValidationSessionResult.ValidationSessionResultType.Ignore)
                {
                    // ...
                }
                else
                {
                    throw new NotImplementedException();
                }

                yield return null;
            }

            var isDirty = false;

            // Replace changed results.
            this.resultObjects.Clear();
            for (int i = 0; i < this.allItems.Length; i++)
            {
                var item = allItems[i];

                if (toRemove.Count > 0)
                {
                    if (toRemove.Contains(item.WorkItem))
                    {
                        isDirty = true;
                        toReplace.Remove(item.Result);
                        continue;
                    }
                }

                if (toReplace.TryGetValue(item.Result, out var replacement))
                {
                    if (this.resultObjects.Add(replacement.Result))
                    {
                        var old = item.Result;
                        var _new = replacement.Result;
                        var _newHighestSeverityResult = _new.HighestSeverityResult;
                        var oldHighestSeverityResult = old.HighestSeverityResult;

                        if (_newHighestSeverityResult.ResultType != oldHighestSeverityResult.ResultType)
                        {
                            isDirty = true;
                            this.toGiveTimeUpdate.Add(this.nextResultList.Count);
                        }

                        if (_newHighestSeverityResult.ResultType == ValidationResultType.Valid)
                        {
                            // Copy old fix.
                            _newHighestSeverityResult.Data = oldHighestSeverityResult.Data;
                            replacement.Result.HighestSeverityResult = _newHighestSeverityResult;
                        }

                        if (string.IsNullOrEmpty(_newHighestSeverityResult.Message))
                        {
                            _newHighestSeverityResult.Message = oldHighestSeverityResult.Message;
                            replacement.Result.HighestSeverityResult = _newHighestSeverityResult;
                        }

                        if (_new.Count != old.Count)
                        {
                            isDirty = true;
                        }

                        if (!isDirty)
                        {
                            isDirty = _newHighestSeverityResult.Message != oldHighestSeverityResult.Message;
                        }

                        if (!isDirty)
                        {
                            replacement.FilteredIndex = item.FilteredIndex;
                            replacement.FinalizeId = item.FinalizeId;
                            this.toReplaceIfNotDirty.Add(i);
                        }

                        //isDirty = true
                        replacement.AllItemsIndex = this.nextResultList.Count;
                        this.nextResultList.Add(replacement);
                    }
                }

                if (this.resultObjects.Add(item.Result))
                {
                    // If a batch of results has been queued up, that means that we want to
                    // remove all previous results from that batch, as we expect to 
                    // add all of them again. And any missing results should be delted as result.
                    // (Unless there is a bug).
                    if (qAddressesCopy.Contains(new BatchKey(item.Result)))
                    {
                        isDirty = true;
                    }
                    else
                    {
                        item.AllItemsIndex = this.nextResultList.Count;
                        this.nextResultList.Add(item);
                    }
                }

                yield return null;
            }

            for (int i = 0; i < toAdd.Count; i++)
            {
                var item = toAdd[i];
                var type = item.Result.HighestSeverityResult.ResultType;

                if (type == ValidationResultType.Valid || type == ValidationResultType.IgnoreResult) continue;

                if (this.resultObjects.Add(item.Result))
                {
                    isDirty = true;
                    this.toGiveTimeUpdate.Add(this.nextResultList.Count);

                    item.AllItemsIndex = this.nextResultList.Count;
                    this.nextResultList.Add(item);
                }

                yield return null;
            }

            if (isDirty)
            {
                var errorCount = 0;
                var warningCount = 0;
                var validCount = 0;

                foreach (var item in this.ObjectTypeFilters.OrderedItems)
                    item.NextCount = 0;

                foreach (var item in this.SceneFilters.OrderedItems)
                    item.NextCount = 0;

                foreach (var item in this.ValidatorTypeFilters.OrderedItems)
                    item.NextCount = 0;

                foreach (var item in this.FixTypeFilters.OrderedItems)
                    item.NextCount = 0;

                foreach (var item in this.nextResultList)
                {
                    var highestSeverityResult = item.Result.HighestSeverityResult;
                    var resultType = highestSeverityResult.ResultType;

                    if (highestSeverityResult.Data.MangledFix != null)
                    {
                        this.FixTypeFilters.GetOrCreate(highestSeverityResult.Data.MangledFix.FixIdentifier).NextCount++;
                    }

                    this.ValidatorTypeFilters.GetOrCreate(item.Result.GetGenericValidatorType()).NextCount++;
                    this.SceneFilters.GetOrCreate(item.Result.GetSceneReference()).NextCount++;
                    this.ObjectTypeFilters.GetOrCreate(item.Result.GetObjectType()).NextCount++;

                    if (resultType == ValidationResultType.Error) errorCount++;
                    else if (resultType == ValidationResultType.Warning) warningCount++;
                    else validCount++;

                    yield return null;
                }

                foreach (var item in this.ObjectTypeFilters.OrderedItems)
                    item.Count = item.NextCount;

                foreach (var item in this.SceneFilters.OrderedItems)
                    item.Count = item.NextCount;

                foreach (var item in this.ValidatorTypeFilters.OrderedItems)
                    item.Count = item.NextCount;

                foreach (var item in this.FixTypeFilters.OrderedItems)
                    item.Count = item.NextCount;

                var items = this.nextResultList.ToArray();

                var time = (float)EditorApplication.timeSinceStartup;
                foreach (var i in this.toGiveTimeUpdate)
                {
                    items[i].LastStateChangeTime = time;
                }

                this.allItems = items;
                this.ErrorCount = errorCount;
                this.WarningCount = warningCount;
                this.ValidCount = validCount;
                this.MarkFiltersDirty();

                if (this.OnResultsChanged != null)
                    OnResultsChanged();

                if (OnAnyResultsChanged != null)
                    OnAnyResultsChanged(this.validationSession);
            }
            else
            {
                foreach (var i in toReplaceIfNotDirty)
                {
                    var replacement = this.nextResultList[i];

                    // TODO: Why is the -1 needed. That seems like a bug.
                    if (replacement.FinalizeId == this.filteredItemsVersion - 1 || replacement.FinalizeId == this.filteredItemsVersion)
                    {
                        if (replacement.Result.Count == 1)
                        {
                            // THIS IS A PROBLEM:!!!!
                            // Hmmm
                            this.filteredItems[replacement.FilteredIndex] = replacement;
                        }
                        else
                        {
                            // TODO: Replace exploded results...
                        }
                    }
                }
            }

            this.toReplaceIfNotDirty.Clear();
            this.nextResultList.Clear();
            this.toRemove.Clear();
            this.toReplace.Clear();
            this.toAdd.Clear();
            this.toGiveTimeUpdate.Clear();
            this.resultObjects.Clear();
        }

        public void Clear()
        {
            this.ErrorCount = 0;
            this.WarningCount = 0;
            this.ValidCount = 0;
            this.queue.Clear();
            this.queuedAddresses.Clear();
            this.resultObjects.Clear();
            this.allItems = new ResultItem[0];
            this.SceneFilters.Clear();
            this.ObjectTypeFilters.Clear();
            this.ValidatorTypeFilters.Clear();
            this.FixTypeFilters.Clear();
            this.populatorTask.Kill();
            this.populatorTask = BackgroundTaskRunner.StartTask("Result view population for " + this.validationSession.Name, PopulateResultQueue());
            this.MarkFiltersDirty();
        }

        public void MarkFiltersDirty()
        {
            this.filteredItemsVersion++;
            this.filteredItems = null;
        }

        public void Dispose()
        {
#if SIRENIX_INTERNAL
            if (isDisposed)
            {
                throw new Exception(nameof(ValidationSessionResultCollector) + " is already disposed.");
            }
#endif
            isDisposed = true;
            this.Clear();
            this.populatorTask.Kill();
            this.populatorTask = null;
        }

        public struct ResultItem
        {
            private string searchText;

            public int Score;
            public PersistentValidationResult Result;
            public ValidationWorkItem WorkItem;
            public int LastSceneSetupChangeId;

            public float LastStateChangeTime;
            public int ExplodeCount;
            public int ExplodedIndex;

            internal int Skip;
            internal int AllItemsIndex;
            internal int FilteredIndex;
            internal int FinalizeId;

            public string SearchText
            {
                get
                {
                    // TODO optimize this bull.

                    var sb = new System.Text.StringBuilder();

                    for (int i = 0; i < this.Result.Count; i++)
                        sb.Append(this.Result[i].Message);

                    return sb.ToString();
                }
            }

            internal void Update()
            {
                var id = UnitySceneSetupChangeId.SceneSetupChangeId /*+ CurrentSelectionHashset.SelectionChangedId*/;

                if (this.LastSceneSetupChangeId != id)
                {
                    this.LastSceneSetupChangeId = id;
                    GUIHelper.RequestRepaint();
                    this.Result.DynamicObjectAddress.Refresh();
                }
            }
        }

        public class Filter<T>
        {
            private Dictionary<T, FilteredItem> items = new Dictionary<T, FilteredItem>();

            public bool Enabled = true;
            public List<FilteredItem> OrderedItems = new List<FilteredItem>();

            public FilteredItem GetOrCreate(T val)
            {
                if (!items.TryGetValue(val, out var item))
                {
                    item = items[val] = new FilteredItem(val)
                    {
                        NextCount = 0,
                        Enabled = true,
                    };
                    OrderedItems.Add(item);
                }

                return item;
            }

            public bool ShouldInclude(T item)
            {
                if (!this.Enabled)
                    return true;

                if (this.items.TryGetValue(item, out var result))
                {
                    return result.Enabled;
                }

                return false;
            }

            public void Clear()
            {
                this.items.Clear();
                this.OrderedItems.Clear();
                this.Enabled = true;
            }

            public bool HasFilter()
            {
                if (this.Enabled)
                    foreach (var item in OrderedItems)
                    {
                        if (!item.Enabled)
                        {
                            return true;
                        }
                    }

                return false;
            }

            public class FilteredItem
            {
                public int Count;
                public bool Enabled;
                public T Value;

                internal int NextCount;

                private string name;

                public string Name
                {
                    get
                    {
                        if (name == null)
                        {
                            if (this.Value is SceneReference scene)
                            {
                                if (scene.GUID == null)
                                {
                                    this.name = "Assets";
                                }
                                else
                                {
                                    this.name = scene.Name;
                                }
                            }
                            else if (this.Value is Type t)
                            {
                                if (t == typeof(System.NullReferenceException))
                                {
                                    this.name = "Broken references";
                                }
                                else
                                {
                                    this.name = t.GetNiceValidatorTypeName();
                                }
                            }
                            else if (this.Value is FixIdentifier fixId)
                            {
                                var valName = fixId.ValidatorType?.GetNiceValidatorTypeName();

                                if (valName != null)
                                {
                                    valName = valName.SplitPascalCase();
                                    var gen = fixId.ValidatorType.GenericTypeArguments;
                                    if (gen != null)
                                    {
                                        if (gen.Length == 1)
                                        {
                                            valName += $" ({gen[0].GetNiceName().SplitPascalCase()})";
                                        }
                                        else if (gen.Length > 1)
                                        {
                                            valName += $" ({string.Join(", ", gen.Select(c => c.GetNiceName().SplitPascalCase()))})";
                                        }
                                    }

                                    this.name = valName;
                                }
                                else
                                {
                                    this.name = "Invalid Fix Id";
                                }
                            }
                            else
                            {
                                throw new NotImplementedException();
                            }
                        }

                        return this.name;
                    }
                }
                public FilteredItem(T item)
                {
                    this.Value = item;
                }
            }
        }

        internal struct BatchKey : IEquatable<BatchKey>
        {
            public DynamicObjectAddress DynamicObjectAddress;
            public bool IsSceneValidatorBatch;

            public BatchKey(PersistentValidationResult result)
            {
                this.DynamicObjectAddress = result.DynamicObjectAddress;
                this.IsSceneValidatorBatch = typeof(SceneValidator).IsAssignableFrom(result.ValidatorType);
            }

            public override bool Equals(object obj) => obj is BatchKey key && Equals(key);
            public bool Equals(BatchKey other) => DynamicObjectAddress == other.DynamicObjectAddress && IsSceneValidatorBatch == other.IsSceneValidatorBatch;
            public override int GetHashCode() => DynamicObjectAddress.GetHashCode() + IsSceneValidatorBatch.GetHashCode();
            public static bool operator ==(BatchKey left, BatchKey right) => left.Equals(right);
            public static bool operator !=(BatchKey left, BatchKey right) => !(left == right);
        }
    }
}
#endif