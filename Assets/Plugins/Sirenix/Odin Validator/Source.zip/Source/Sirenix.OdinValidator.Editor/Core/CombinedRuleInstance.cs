//-----------------------------------------------------------------------
// <copyright file="CombinedRuleInstance.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor.Internal;
    using Sirenix.OdinInspector.Editor.Validation;
    using System;

    public class CombinedRuleInstance
    {
        public SerializedRule Project;
        public SerializedRule Local;
        public SerializedRule Default;

        public string Description => this.Default.Attr.Description;
        public string Name => this.Default.Attr.Name;

        public bool Enabled
        {
            get
            {
                if (this.Local != null && this.Local.EnabledOverridden)
                    return this.Local.Enabled;

                if (this.Project != null && this.Project.EnabledOverridden)
                    return this.Project.Enabled;

                return this.Default.Enabled;
            }
        }

        public ConfigSourceType EnabledOverrideState
        {
            get
            {
                if (this.Local != null && this.Local.EnabledOverridden)
                    return ConfigSourceType.Local;

                if (this.Project != null && this.Project.EnabledOverridden)
                    return ConfigSourceType.Project;

                return ConfigSourceType.Default;
            }
        }

        public ConfigSourceType DataOverrideState
        {
            get
            {
                if (this.Local != null && this.Local.DataOverride != null)
                    return ConfigSourceType.Local;

                if (this.Project != null && this.Project.DataOverride != null)
                    return ConfigSourceType.Project;

                return ConfigSourceType.Default;
            }
        }

        public void SetEnabledOverrideState(ConfigSourceType type, bool value)
        {
            if (type == ConfigSourceType.Local)
            {
                this.Local = this.Local ?? new SerializedRule(this.Default.ValidatorType, this.Default.Attr);
                this.Local.EnabledOverridden = true;
                this.Local.Enabled = value;
            }
            else if (type == ConfigSourceType.Project)
            {
                this.Project = this.Project ?? new SerializedRule(this.Default.ValidatorType, this.Default.Attr);
                this.Project.EnabledOverridden = true;
                this.Project.Enabled = value;
            }
            else
            {
                throw new Exception("Default is immutable.");
            }
        }

        public Validator ValidatorData
        {
            get
            {
                return this.Local?.DataOverride ?? this.Project?.DataOverride ?? this.Default.DataOverride;
            }
        }

        public Validator GetOverrideDataOrDefaultCopy(ConfigSourceType type)
        {
            if (type == ConfigSourceType.Local)
            {
                if (this.Local == null || this.Local.DataOverride == null)
                {
                    return FastDeepCopier.DeepCopy(this.Project?.DataOverride ?? this.Default.DataOverride);
                }

                return this.Local.DataOverride;
            }
            else if (type == ConfigSourceType.Project)
            {
                if (this.Project == null || this.Project.DataOverride == null) 
                {
                    return FastDeepCopier.DeepCopy(this.Default.DataOverride);
                }

                return this.Project.DataOverride;
            }
            else
            {
                throw new Exception("Default is immutable.");
            }
        }

        public void SetOverrideData(ConfigSourceType type, Validator data)
        {
            if (type == ConfigSourceType.Local)
            {
                if (data == null)
                {
                    if (this.Local != null)
                    {
                        this.Local.DataOverride = null;
                    }
                }
                else
                {
                    if (this.Local == null)
                    {
                        this.Local = (this.Project ?? this.Default).CreateCopy();
                    }

                    this.Local.EnabledOverridden = true;
                    this.Local.DataOverride = data;
                }
            }
            else if (type == ConfigSourceType.Project)
            {

                if (data == null)
                {
                    if (this.Project != null)
                    {
                        this.Project.DataOverride = null;
                    }
                }
                else
                {
                    if (this.Project == null)
                    {
                        this.Project = this.Default.CreateCopy();
                    }

                    this.Project.EnabledOverridden = true;
                    this.Project.DataOverride = data;
                }
            }
            else
            {
                throw new Exception("Default is immutable.");
            }
        }

        public bool IsEnabledIn(ConfigSourceType configSourceType)
        {
            if (configSourceType.HasFlag(ConfigSourceType.Local) && this.Local != null && this.Local.EnabledOverridden)
                return this.Local.Enabled;

            if (configSourceType.HasFlag(ConfigSourceType.Project) && this.Project != null && this.Project.EnabledOverridden)
                return this.Project.Enabled;

            if (configSourceType.HasFlag(ConfigSourceType.Default))
                return this.Default.Enabled;

            return false;
        }

        public bool IsEnabledOverriddenIn(ConfigSourceType configSourceType)
        {
            if (configSourceType.HasFlag(ConfigSourceType.Local))
                return this.Local != null && this.Local.EnabledOverridden;

            if (configSourceType.HasFlag(ConfigSourceType.Project))
                return this.Project != null && this.Project.EnabledOverridden;

            throw new Exception();
        }

        public bool IsDataOverriddenIn(ConfigSourceType configSourceType)
        {
            if (configSourceType.HasFlag(ConfigSourceType.Local))
                return this.Local != null && this.Local.DataOverride != null;

            if (configSourceType.HasFlag(ConfigSourceType.Project))
                return this.Project != null && this.Project.DataOverride != null;

            throw new Exception();
        }

        public SerializedRule GetSerializedRule(ConfigSourceType value)
        {
            if (value == ConfigSourceType.Local)
                return this.Local;

            if (value == ConfigSourceType.Project)
                return this.Project;

            if (value == ConfigSourceType.Default)
                return this.Default;

            throw new Exception();
        }

        // all the stuff
    }
}
#endif