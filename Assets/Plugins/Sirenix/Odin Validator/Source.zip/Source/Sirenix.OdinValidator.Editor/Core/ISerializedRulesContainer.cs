//-----------------------------------------------------------------------
// <copyright file="ISerializedRulesContainer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using System.Collections.Generic;

    public interface ISerializedRulesContainer
    {
        void SetProjectRules(List<SerializedRule> rules);
        void SetLocalRules(List<SerializedRule> rules);
        void SaveRules();
    }
}
#endif