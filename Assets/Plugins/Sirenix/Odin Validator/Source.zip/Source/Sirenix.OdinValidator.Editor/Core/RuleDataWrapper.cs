//-----------------------------------------------------------------------
// <copyright file="RuleDataWrapper.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using System.Collections.Generic;
    using System.Linq;
    using UnityEngine;

    public class RuleDataWrapper
    {
        [HideInInspector]
        public ISerializedRulesContainer RulesContainer;

        [HideInInspector]
        public CombinedRuleInstance[] Rules;

        public RuleDataWrapper(ISerializedRulesContainer rulesContainer, List<SerializedRule> projectRules, List<SerializedRule> localRules, List<SerializedRule> defaultRules)
        {
            this.RulesContainer = rulesContainer;

            this.Rules = new CombinedRuleInstance[defaultRules.Count];

            for (int i = 0; i < defaultRules.Count; i++)
            {
                var rule = defaultRules[i];

                this.Rules[i] = new CombinedRuleInstance()
                {
                    Default = rule,
                    Project = projectRules?.FirstOrDefault(n => n.ValidatorType == rule.ValidatorType),
                    Local = localRules?.FirstOrDefault(n => n.ValidatorType == rule.ValidatorType),
                };
            }
        }

        public void SaveChanges()
        {
            this.RulesContainer.SetLocalRules(this.Rules.Where(n => n.Local != null && (n.Local.EnabledOverridden || n.Local.DataOverride != null)).Select(n => n.Local).ToList());
            this.RulesContainer.SetProjectRules(this.Rules.Where(n => n.Project != null && (n.Project.EnabledOverridden || n.Project.DataOverride != null)).Select(n => n.Project).ToList());
            this.RulesContainer.SaveRules();
        }
    }
}
#endif