//-----------------------------------------------------------------------
// <copyright file="PersistentValidationResult.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
using Sirenix.OdinInspector.Editor.Validation;
using Sirenix.OdinInspector.Editor.Validation.Internal;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using UnityEditor;

namespace Sirenix.OdinValidator.Editor
{

    public struct PersistentResultItem
    {
        public string Message;
        public ValidationResultType ResultType;
        public PersistenceData Data;

        public PersistentResultItem(string message, ValidationResultType type)
        {
            this.Message = message;
            this.ResultType = type;
            this.Data = default;
        }
    }

    public struct PersistenceData
    {
        public Fix MangledFix;
        public ResultItemMetaData[] MangledMetaData;
        public Entry[] RestoreEntries;

        public struct Entry
        {
            public int Id;
            public PersistenceDataType Type;
            public DynamicObjectAddress UnityObjectReferenceAddress;
        }
    }

    public enum PersistenceDataType
    {
        Validator,
        InspectorProperty,
        ValueEntry,
        BaseValueEntry,
        PropertyTree,
        Root,
        Value,
        UnityObjectReference
    }


    public class PersistentValidationResult
    {
        public static readonly PersistentValidationResult Ignore = new PersistentValidationResult() { firstItem = new PersistentResultItem() { ResultType = ValidationResultType.IgnoreResult } };

        public DynamicObjectAddress DynamicObjectAddress;
        public string Path;
        public Type ValidatorType;
        public int ValidatorIndex;
        public double ValidationTimeMS;
        public int ErrorCount;
        public int WarningCount;

        internal int highestSeverityIndex;

        private PersistentResultItem firstItem;
        private PersistentResultItem[] items;
        private int itemsCount;
        private bool firstItemExist;
        private int countOffset;

        private Type getGenericValidatorType_Cached;

        private static PersistentResultItem[] SingleResultBuffer = new PersistentResultItem[1];

        public ref PersistentResultItem HighestSeverityResult
        {
            get
            {
                if (this.Count == 0)
                {
#if SIRENIX_INTERNAL
                    if (this.firstItem.ResultType != ValidationResultType.IgnoreResult)
                    {
                        throw new Exception(this.firstItem.ResultType + " needs to be ignore.");
                    }
#endif
                    return ref this.firstItem;
                }

                return ref this[this.highestSeverityIndex];
            }
        }

        public int Count
        {
            get
            {
                return this.itemsCount + this.countOffset;
            }
        }

        public ref PersistentResultItem this[int index]
        {
            get
            {
                if (this.firstItemExist)
                {
                    if (index == 0) return ref this.firstItem;
                    if (this.items == null)
                    {
                        throw new IndexOutOfRangeException();
                    }
                    return ref this.items[index - 1];
                }
                else
                {
                    if (this.items == null) throw new IndexOutOfRangeException();
                    return ref this.items[index];
                }
            }
        }

        private PersistentValidationResult()
        {
        }

        public PersistentValidationResult(string path, string message, Type validatorType, int validatorIndex, ValidationResultType resultType)
            : this(path, message, validatorType, validatorIndex, resultType, DynamicObjectAddress.Unknown)
        {
        }

        public PersistentValidationResult(string path, string message, Type validatorType, int validatorIndex, ValidationResultType resultType, DynamicObjectAddress objectAddress)
        {
            this.Path = path;
            this.ValidatorType = validatorType;
            this.ValidatorIndex = validatorIndex;
            this.DynamicObjectAddress = objectAddress;

            this.firstItem.Message = message;
            this.firstItem.ResultType = resultType;
            this.highestSeverityIndex = 0;
            this.firstItemExist = true;
            this.countOffset = 1;

            if (resultType == ValidationResultType.Warning)
                this.WarningCount = 1;

            if (resultType == ValidationResultType.Error)
                this.ErrorCount = 1;
        }

        public PersistentValidationResult(ValidationResult result, DynamicObjectAddress address)
        {
            this.Path = result.Path;
            this.ValidatorType = result.Setup.Validator.GetType();
            this.ValidationTimeMS = result.ValidationTimeMS;

            var attrValidator = result.Setup.Validator as IAttributeValidator;
            if (attrValidator != null)
                this.ValidatorIndex = attrValidator.AttributeNumber;

            var resultCount = result.Count;

            if (resultCount == 1)
            {
                ResultItemPersistor.CreatePersistentResultItems(result, ref SingleResultBuffer);

                this.firstItem = SingleResultBuffer[0];
                this.firstItemExist = true;
                this.countOffset = 1;
            }
            else
            {
                this.items = ResultItemPersistor.CreatePersistentResultItems(result);
                this.itemsCount = resultCount;
                this.firstItemExist = false;
                this.countOffset = 0;
            }

            //if (result.FirstItemExists())
            //{
            //    this.firstItem.Message = result.Message;
            //    this.firstItem.ResultType = result.ResultType;
            //    //this.firstItem.ValidationActions = result.ValidationActions?.ToArray();
            //    this.firstItemExist = true;
            //    this.countOffset = 1;
            //}
            //else
            //{
            //    this.items = new ResultItem[resultCount];
            //    for (int i = 0; i < resultCount; i++)
            //    {
            //        this.items[i] = result[i];
            //    }
            //    this.itemsCount = resultCount;
            //    this.firstItemExist = false;
            //    this.countOffset = 0;
            //}

            if (address == null)
            {
                if (result.Setup.Validator is SceneValidator)
                {
                    var sceneValidator = result.Setup.Validator as SceneValidator;
                    this.DynamicObjectAddress = DynamicObjectAddress.GetOrCreate(
                        AssetDatabase.LoadAssetAtPath<SceneAsset>(sceneValidator.ValidatedScene.Path), 
                        new ObjectAddress(sceneValidator.ValidatedScene)
                    );
                }
                else
                {
                    throw new Exception("No dynamic object address was passed.");
                }
            }
            else
            {
                this.DynamicObjectAddress = address;
            }

            var warningIndex = -1;
            var errorIndex = -1;
            for (int i = 0; i < this.Count; i++)
            {
                ref var item = ref this[i];

                if (item.ResultType == ValidationResultType.Error)
                {
                    this.ErrorCount++;
                    warningIndex = i;
                }
                else if (item.ResultType == ValidationResultType.Warning)
                {
                    this.WarningCount++;
                    errorIndex = i;
                }
            }

            if (errorIndex != -1)
            {
                this.highestSeverityIndex = errorIndex;
            }
            else if (warningIndex != -1)
            {
                this.highestSeverityIndex = warningIndex;
            }
            else if (this.Count > 0)
            {
                this.highestSeverityIndex = 0;
            }
            else
            {
                this.highestSeverityIndex = -1;
            }
        }

        public string ToNiceLogString()
        {
            if (this.Count == 0) return "Ignore";
            ref var highestSeverity = ref this.HighestSeverityResult;

            if (this.Count == 1 && highestSeverity.ResultType == ValidationResultType.IgnoreResult)
            {
                return "Ignore";
            }

            string result = $"{highestSeverity.ResultType}: {highestSeverity.Message}\n\nFrom member '{this.Path}' in Unity object: \n{this.DynamicObjectAddress.LatestAddress.ToString(true)}";

            if (this.Count > 1)
            {
                var sb = new StringBuilder(result);

                bool hasAddedMessage = false;

                for (int i = 0; i < this.Count; i++)
                {
                    ref var subResult = ref this[i];

                    if (i == this.highestSeverityIndex || subResult.ResultType == ValidationResultType.IgnoreResult) continue;

                    if (!hasAddedMessage)
                    {
                        sb.AppendLine();
                        sb.AppendLine("Extra messages:");
                        hasAddedMessage = true;
                    }

                    sb.Append("    - ");
                    sb.AppendLine($"{subResult.ResultType}: {subResult.Message}");
                }

                if (hasAddedMessage)
                {
                    result = sb.ToString();
                }
            }

            return result;
        }

        public void Explode(PersistentValidationResult[] dst, int index)
        {
            var count = this.Count;
            if (count == 0) return;

            var msSplit = this.ValidationTimeMS / count;

            for (int i = 0; i < count; i++)
            {
                dst[i + index] = new PersistentValidationResult()
                {
                    firstItem = this[i],
                    firstItemExist = true,
                    countOffset = 1,
                    DynamicObjectAddress = this.DynamicObjectAddress,
                    Path = this.Path,
                    ValidationTimeMS = msSplit,
                    ValidatorType = this.ValidatorType,
                    ValidatorIndex = this.ValidatorIndex,
                };
            }
        }

        public IEnumerable<PersistentValidationResult> Explode()
        {
            var count = this.Count;
            if (count == 0) yield break;

            var msSplit = this.ValidationTimeMS / count;

            for (int i = 0; i < count; i++)
            {
                yield return new PersistentValidationResult()
                {
                    firstItem = this[i],
                    firstItemExist = true,
                    countOffset = 1,
                    DynamicObjectAddress = this.DynamicObjectAddress,
                    Path = this.Path,
                    ValidationTimeMS = msSplit,
                    ValidatorType = this.ValidatorType,
                    ValidatorIndex = this.ValidatorIndex,
                };
            }
        }

        public void Explode(List<PersistentValidationResult> results)
        {
            var count = this.Count;
            if (count == 0) return;

            var msSplit = this.ValidationTimeMS / count;

            for (int i = 0; i < count; i++)
            {
                results.Add(new PersistentValidationResult()
                {
                    firstItem = this[i],
                    firstItemExist = true,
                    countOffset = 1,
                    DynamicObjectAddress = this.DynamicObjectAddress,
                    Path = this.Path,
                    ValidationTimeMS = msSplit,
                    ValidatorType = this.ValidatorType,
                    ValidatorIndex = this.ValidatorIndex,
                });
            }
        }

        internal SceneReference GetSceneReference()
        {
            var objType = this.DynamicObjectAddress.LatestAddress.Type;
            if (objType == ObjectAddress.AddressType.SceneComponent || 
                objType == ObjectAddress.AddressType.SceneGameObject)
            {
                return new SceneReference(this.DynamicObjectAddress.LatestAddress.AssetGUID);
            }
            else if (objType == ObjectAddress.AddressType.Asset)
            {
                if (this.DynamicObjectAddress.LatestAddress.IsSceneAsset())
                {
                    return new SceneReference(this.DynamicObjectAddress.LatestAddress.AssetGUID);
                }

                return new SceneReference();
            }
            else
            {
                return new SceneReference();
            }
        }

        internal Type GetGenericValidatorType()
        {
            // We use a cached type as IsGenericType and GetGenericTypeDefinition can be quite expensive.
            if (this.getGenericValidatorType_Cached == null)
            {
                if (this.ValidatorType == null)
                {
                    return typeof(NullReferenceException);
                }

                if (this.ValidatorType.IsGenericType)
                {
                    this.getGenericValidatorType_Cached = this.ValidatorType.GetGenericTypeDefinition();
                }
                else
                {
                    this.getGenericValidatorType_Cached = this.ValidatorType;
                }
            }

            return this.getGenericValidatorType_Cached;
        }

        internal Type GetObjectType()
        {
            return DynamicObjectAddress.LatestAddress.ObjectType.Type ?? typeof(NullReferenceException);
        }

        /*
         * Comparing PersistantValidationReuslts depends on whether you're matching in order to remove, or matching in order to replace, or find.
         * For instance, if a UnityObject is deleted, you'll get a result where DynamicObjectAdress is representing a destroyed object.
         */

        public class Comparer : IEqualityComparer<PersistentValidationResult>
        {
            public bool Equals(PersistentValidationResult x, PersistentValidationResult y)
            {
                if (x == null || y == null)
                    return ReferenceEquals(x, y);

                if (x.DynamicObjectAddress != y.DynamicObjectAddress)
                    return false;

                if (x.Path != y.Path)
                    return false;

                if (x.ValidatorIndex != y.ValidatorIndex)
                    return false;

                var t1 = x.GetGenericValidatorType();
                var t2 = y.GetGenericValidatorType();

                if (t1 != t2)
                    return false;

                return true;
            }

            public int GetHashCode(PersistentValidationResult obj)
            {
                int hashCode = -1202384790;
                hashCode = hashCode * -1521134295 + EqualityComparer<DynamicObjectAddress>.Default.GetHashCode(obj.DynamicObjectAddress);
                hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(obj.Path);
                hashCode = hashCode * -1521134295 + EqualityComparer<Type>.Default.GetHashCode(obj.GetGenericValidatorType());
                hashCode = hashCode * -1521134295 + obj.ValidatorIndex.GetHashCode();
                return hashCode;
            }
        }
    }
}
#endif