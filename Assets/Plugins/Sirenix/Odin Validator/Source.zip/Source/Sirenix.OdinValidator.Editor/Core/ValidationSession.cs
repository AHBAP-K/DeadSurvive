//-----------------------------------------------------------------------
// <copyright file="ValidationSession.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor;
    using Sirenix.OdinInspector.Editor.Validation;
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using UnityEditor;
    using UnityEditor.SceneManagement;
    using UnityEngine;
    using UnityEngine.SceneManagement;
    using Debug = UnityEngine.Debug;

    public class ValidationSession : IDisposable
    {

#if !SIRENIX_INTERNAL && !ODIN_BETA
#error Shouldn't this be weak references so we can't leak sessions permanently?
#endif
        public static List<ValidationSession> ActiveValidationSessions = new List<ValidationSession>();

        private static ValidationSession globalValidationSession;

#if !SIRENIX_INTERNAL && !ODIN_BETA
#error Dont forget to make EnableLeakDetection a setting somewhere!
#endif

        public static ValidationSession GlobalValidationSession
        {
            get
            {
                InitGlobalValidation();
                return globalValidationSession;
            }
        }

        private static void InitGlobalValidation()
        {
            if (globalValidationSession == null)
            {
                var config = new SessionConfig();
                config.SessionData.Add(GlobalSessionConfigData.Instance);
                config.SessionData.Add(LocalSessionConfigData.Instance);
                globalValidationSession = new ValidationSession("Global Validation Session", config);
            }
        }

        [InitializeOnLoadMethod]
        private static void Init()
        {
            EditorApplication.playModeStateChanged -= ToggleBackgroundValidation;
            EditorApplication.playModeStateChanged += ToggleBackgroundValidation;
            AssemblyReloadEvents.beforeAssemblyReload += () =>
            {
                if (globalValidationSession != null)
                {
                    globalValidationSession.Dispose();
                }
            };

            InitGlobalValidation();
            ToggleBackgroundValidation(PlayModeStateChange.EnteredEditMode);
        }

        private static void ToggleBackgroundValidation(PlayModeStateChange change)
        {
            if (Application.isPlaying && globalValidationSession != null)
            {
                foreach (var session in ValidationSession.ActiveValidationSessions)
                {
                    session.Clear(false, true);
                    session.StopSession();
                }
            }
            else if (GlobalValidationConfig.EnableOnLoad && change == PlayModeStateChange.EnteredEditMode)
            {
                foreach (var session in ValidationSession.ActiveValidationSessions)
                {
                    session.Clear(false, true);

                    if (GlobalValidationConfig.ValidateOnLoad)
                        session.PopulateQueue(true, false);

                    session.StartSession();
                }
            }
        }

        private bool disposed;
        private bool shouldDisplayProgressBar;
        private System.Diagnostics.StackTrace allocationStackTrace;
        private BackgroundTaskHandle backgroundTaskHandle;
        private IEnumerator<ValidationSessionResult> currentlyBackgroundProcessingWorkItemEnumerator;
        internal ValidationWorkItem? currentlyProcessingWorkItem;
        internal ValidationWorkItem prevProcessedWorkItem;

        public readonly string Name;
        public OdinValidationRunner Runner;
        public readonly ValidationWorkItemQueue WorkQueue = new ValidationWorkItemQueue();
        public readonly HashSet<ValidationWorkItem> WorkDone = new HashSet<ValidationWorkItem>(new ValidationWorkItem.Comparer());
        public readonly Queue<ValidationSessionResult> RemovedObjectResults = new Queue<ValidationSessionResult>();
        public readonly SessionConfig Config;

        // TODO: OnResult is not needed for what we need to do.
        // Instead of having it as a config. "Should Invoke On Result" just always invoke it. Most of the time it will be null.
        //public Action<ValidationSessionResult> OnResult;

        internal ValidationSessionResultCollector Results; // TODO: Polish and expose this.

        public uint WorkDoneCountSample { get; private set; }
        public uint RemainingWorkCountSample { get; private set; }
        public bool IsValidatingInBackground { get; private set; }
        public bool IsWatching { get; private set; }

        public bool ShouldDisplayProgressBar
        {
            get
            {
                if (this.shouldDisplayProgressBar)
                {
                    if (this.WorkQueue.Count > 0)
                        return true;

                    if (this.currentlyProcessingWorkItem.HasValue)
                        return true;

                    // Stop progress bar if we are not working.
                    this.PrepareNextProgressBar(false);
                }
                else
                {
                    // Early out.
                    if (this.WorkQueue.Count == 0 && this.currentlyProcessingWorkItem.HasValue == false)
                    {
                        return false;
                    }

                    // Start a new progress bar if:
                    if (
                        // we think a lot of work is queued up.
                        (this.WorkQueue.TotalResultsEstimate > 1500) ||

                        // queue contians a scene.
                        (this.WorkQueue.AllQueuedSceneReferences.Count > 0) ||

                        // current work item is a scene.
                        (this.currentlyProcessingWorkItem.HasValue && this.currentlyProcessingWorkItem.Value.SceneContent.HasValue)
                    )
                    {
                        this.PrepareNextProgressBar(true);
                    }
                }

                return false;
            }
        }

        public ValidationSessionEditor OpenEditor()
        {
            foreach (var item in ValidationSessionEditor.ActiveEditors)
            {
                if (item.ValidationSession == this)
                {
                    item.Window.Show();
                    item.Window.Focus();
                    return item;
                }
            }

            return OdinValidatorWindow.OpenWindow(this, false);
        }

        public ValidationSession(string sessionName, params ValidationItem[] include)
            : this(sessionName, new SessionConfig(new SessionConfig.SerializableSessionConfigData(include, null)))
        {
        }

        public ValidationSession(string sessionName, IList<ValidationItem> include, IList<ValidationItem> exclude)
            : this(sessionName, new SessionConfig(new SessionConfig.SerializableSessionConfigData(include, exclude)))
        {
        }

        public ValidationSession(string sessionName, SessionConfig config)
        {
            if (config == null) throw new ArgumentNullException(nameof(config));

            this.Runner = new OdinValidationRunner();
            this.Name = sessionName;
            this.Config = config;
            this.Results = new ValidationSessionResultCollector(this);

            if (GlobalValidationConfig.EnableLeakDetection)
            {
                this.allocationStackTrace = new System.Diagnostics.StackTrace(true);
            }

            ActiveValidationSessions.Add(this);
        }

        public void ValidateQueuedUpWorkNow(bool showProgressBar = true, bool processResultQueue = true)
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            var enableWatchingAgain = this.IsWatching;

            try
            {
                if (this.IsWatching)
                {
                    this.StopSession(true, false);
                }

                PersistentValidationResult latest = default;
                while (this.RemovedObjectResults.Count != 0 || this.WorkQueue.Count != 0 || this.currentlyBackgroundProcessingWorkItemEnumerator != null)
                {
                    while (this.RemovedObjectResults.Count > 0)
                    {
                        var e = this.RemovedObjectResults.Dequeue();
                        latest = e.Result ?? latest;
                        this.Results.Enqueue(e);
                    }

                    if (this.currentlyBackgroundProcessingWorkItemEnumerator == null && this.WorkQueue.Count > 0)
                    {
                        this.currentlyBackgroundProcessingWorkItemEnumerator = this.ProcessWorkItem(this.WorkQueue.Dequeue(), true);
                    }

                    if (this.currentlyBackgroundProcessingWorkItemEnumerator != null)
                    {
                        if (this.currentlyBackgroundProcessingWorkItemEnumerator.MoveNext())
                        {
                            var e = this.currentlyBackgroundProcessingWorkItemEnumerator.Current;
                            latest = e.Result ?? latest;
                        }
                        else
                        {
                            this.currentlyBackgroundProcessingWorkItemEnumerator?.Dispose();
                            this.currentlyBackgroundProcessingWorkItemEnumerator = null;
                        }
                    }

                    if (showProgressBar && GUIHelper.ShouldDisplaySmartCancellableProgressBar())
                    {
                        var title =
                            $"Validating:{this.WorkDoneCountSample} / {this.RemainingWorkCountSample} " +
                            $"per second: {(int)(this.WorkDoneCountSample / sw.Elapsed.TotalSeconds)}";
                        var name = latest?.DynamicObjectAddress?.LatestAddress?.Name;
                        var t = CalculateCurrentValidationProgress();
                        var details = $"Object: {name}";

                        if (GUIHelper.DisplaySmartUpdatingCancellableProgressBar(title, details, t))
                            break;
                    }
                }
            }
            finally
            {
                if (showProgressBar)
                {
                    EditorUtility.ClearProgressBar();
                }

                this.currentlyBackgroundProcessingWorkItemEnumerator?.Dispose();
                this.currentlyBackgroundProcessingWorkItemEnumerator = null;

                this.StartSession(enableWatchingAgain, false);

                if (this.Results != null && processResultQueue)
                {
                    this.Results.ProcessQueue();
                }
            }
        }

        public void ValidateEverythingNow(bool openClosedScenes, bool showProgressBar) => ValidateEverythingNow(true, openClosedScenes, showProgressBar);

        public IEnumerable<PersistentValidationResult> ValidateEverythingEnumerator(bool openClosedScenes, bool showProgressBar) =>
            ValidateEverythingEnumerator(true, openClosedScenes, true, showProgressBar);

        internal void ValidateEverythingNow(bool explodeMultiResults, bool openClosedScenes, bool showProgressBar)
        {
            var e = ValidateEverythingEnumerator(explodeMultiResults, openClosedScenes, true, showProgressBar).GetEnumerator();
            while (e.MoveNext())
            {
            }
        }

        internal IEnumerable<PersistentValidationResult> ValidateEverythingEnumerator(bool explodeMultiResults, bool openClosedScenes, bool populateResults, bool showProgressBar)
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            var enableValidationAgain = this.IsValidatingInBackground;
            var enableWatchingAgain = this.IsWatching;
            int ignoreCount = 0;
            var errorCount = 0;
            var warningCount = 0;
            try
            {
                this.StopSession();
                this.PopulateQueue(true, openClosedScenes);

                foreach (var item in this.ValidateCurrentWorkQueueEnumerator(populateResults, openClosedScenes))
                {
                    if (item.Type == ValidationSessionResult.ValidationSessionResultType.Ignore)
                    {
                        ignoreCount++;
                    }

                    if (item.Result == null)
                        continue;

                    warningCount += item.Result.WarningCount;
                    errorCount += item.Result.ErrorCount;

                    if (item.Result.Count > 1 && explodeMultiResults)
                    {
                        foreach (var result in item.Result.Explode())
                        {
                            yield return result;
                        }
                    }
                    else
                    {
                        yield return item.Result;
                    }

                    if (showProgressBar && GUIHelper.ShouldDisplaySmartCancellableProgressBar())
                    {
                        var title = $"Validating: {this.WorkDoneCountSample} / {this.RemainingWorkCountSample}, per second: {(int)(this.WorkDoneCountSample / sw.Elapsed.TotalSeconds)}";
                        var name = item.Result?.DynamicObjectAddress?.LatestAddress?.Name;
                        var t = Mathf.Clamp01(this.WorkDoneCountSample / (float)this.RemainingWorkCountSample);

                        if (t > 0.98f)
                        {
                            title = $"Discovering new objects to validate: {this.WorkDoneCountSample} / {this.RemainingWorkCountSample}, per second: {(int)(this.WorkDoneCountSample / sw.Elapsed.TotalSeconds)}";
                        }

                        var details = $"Errors: {errorCount}, warnings: {warningCount}, object: {name}";
                        if (GUIHelper.DisplaySmartUpdatingCancellableProgressBar(title, details, t))
                            break;
                    }
                }


                if (this.Results != null)
                {
                    this.Results.ProcessQueue();
                }
            }
            finally
            {
                sw.Stop();
                Debug.Log($"Completed validating {this.WorkDoneCountSample} values in {sw.Elapsed.TotalSeconds} seconds.");

                this.Clear(false, true);

                if (showProgressBar)
                {
                    EditorUtility.ClearProgressBar();
                }

                this.StartSession(enableWatchingAgain, enableValidationAgain);

                ProjectWatcher.RestartWatching(true);
            }
        }

        public void Clear(bool clearResults, bool clearQueue)
        {
            if (clearQueue)
            {
                this.WorkQueue.Clear();
                this.WorkDone.Clear();
                this.currentlyBackgroundProcessingWorkItemEnumerator?.Dispose();
                this.currentlyBackgroundProcessingWorkItemEnumerator = null;
                this.currentlyProcessingWorkItem = null;
                this.RemainingWorkCountSample = 0;
                this.WorkDoneCountSample = 0;
                this.shouldDisplayProgressBar = false;

                if (this.IsValidatingInBackground)
                {
                    this.StopSession(false, true);
                    this.StartSession(false, true);
                }
            }

            if (clearResults)
            {
                this.Results.Clear();
            }
        }

        public IEnumerable<ValidationSessionResult> ValidateCurrentWorkQueueEnumerator(bool populateResults, bool openClosedScenes)
        {
            while (this.RemovedObjectResults.Count > 0)
            {
                var e = this.RemovedObjectResults.Dequeue();

                if (populateResults)
                    this.Results?.Enqueue(e); // OK

                yield return e;
            }

            SceneSetup[] setupToRestore = null;

            foreach (var sceneRef in this.WorkQueue.AllQueuedSceneReferences)
            {
                if (!sceneRef.IsLoaded)
                {
                    if (EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                    {
                        break;
                    }
                    else
                    {
                        yield break;
                    }
                }
            }

            try
            {
                while (this.WorkQueue.Count > 0)
                {
                    var workItem = this.WorkQueue.Dequeue();
                    var sceneRefNullable = workItem.GetSceneReference();

                    // Try open Scene
                    if (sceneRefNullable.HasValue)
                    {
                        var sceneRef = sceneRefNullable.Value;

                        if (sceneRef.IsLoaded)
                        {
                            Scene scene;
                            if (!sceneRef.TryGetScene(out scene))
                            {
                                // wtf??
                                Debug.LogError($"Scene was loaded but could not be found: '{sceneRef.Path}'");
                                continue; // Bad scene
                            }
                        }
                        else
                        {
                            if (!openClosedScenes) continue;

                            if (setupToRestore == null)
                            {
                                setupToRestore = EditorSceneManager.GetSceneManagerSetup();
                            }

                            if (!sceneRef.TryOpenScene(OpenSceneMode.Single, out var scene))
                            {
                                continue; // Bad scene
                            }
                        }
                    }

                    using (var enumerator = ProcessWorkItem(workItem, populateResults))
                    {
                        while (enumerator.MoveNext())
                        {
                            yield return enumerator.Current;
                        }
                    }

                    while (this.RemovedObjectResults.Count > 0)
                    {
                        var e = this.RemovedObjectResults.Dequeue();

                        if (populateResults)
                        {
                            this.Results?.Enqueue(e);
                        }

                        yield return e;
                    }
                }

                while (this.RemovedObjectResults.Count > 0)
                {
                    var e = this.RemovedObjectResults.Dequeue();

                    if (populateResults)
                    {
                        this.Results?.Enqueue(e);
                    }

                    yield return e;
                }
            }
            finally
            {
                if (setupToRestore != null)
                {
                    if (setupToRestore.Length > 0)
                    {
                        EditorSceneManager.RestoreSceneManagerSetup(setupToRestore);
                    }
                }
            }
        }

        public void PopulateQueue(bool clearCurrentQueue, bool populateUnloadedScenes)
        {
            if (clearCurrentQueue)
            {
                this.Clear(false, true);
            }

            var sceneGuids = this.Config.GetSceneGuidsToValidate();
            foreach (var item in sceneGuids)
            {
                var sceneRef = new SceneReference(item);
                if (populateUnloadedScenes)
                {
                    this.AddToQueue(ValidationWorkItem.CreateForSceneValidators(sceneRef, ProjectEventSource.Other), false);
                    this.AddToQueue(ValidationWorkItem.CreateForSceneContent(sceneRef, ProjectEventSource.Other), false);
                }
                else if (sceneRef.IsLoaded)
                {
                    this.AddToQueue(ValidationWorkItem.CreateForSceneValidators(sceneRef, ProjectEventSource.Other), true);
                    this.AddToQueue(ValidationWorkItem.CreateForSceneContent(sceneRef, ProjectEventSource.Other), true);
                }
            }

            var objs = this.Config.GetObjectsToValidate();
            foreach (var uObj in objs)
            {
                if (!ReferenceEquals(uObj, null))
                {
                    var key = ValidationWorkItem.CreateForInstanceId(uObj.GetHashCode(), ProjectEventSource.Other);
                    this.AddToQueue(key, false);
                }
            }

            var assetsToValidate = this.Config.GetAssetsToValidate();
            foreach (var guid in assetsToValidate)
            {
                var key = ValidationWorkItem.CreateForAssetGuid(guid, ProjectEventSource.Other);
                this.AddToQueue(key, false);
            }

            this.PrepareNextProgressBar(true);
        }

        public void StartSession(bool startWatching = true, bool startBackgroundValidation = true)
        {
            if (startWatching && !this.IsWatching)
            {
                ProjectWatcher.OnProjectEvent += this.OnProjectEvent;
                this.IsWatching = true;
            }

            if (startBackgroundValidation && !this.IsValidatingInBackground)
            {
                if (this.backgroundTaskHandle != null)
                {
                    if (this.backgroundTaskHandle.IsPaused)
                    {
                        this.backgroundTaskHandle.Continue();
                    }
                }
                else
                {
                    this.backgroundTaskHandle = BackgroundTaskRunner.StartTask(this.Name, this.BackgroundValidationTicker());
                }

                this.IsValidatingInBackground = true;
            }
        }

        public void StopSession(bool stopWatching = true, bool stopBackgroundValidation = true)
        {
            if (stopWatching && this.IsWatching)
            {
                ProjectWatcher.OnProjectEvent -= this.OnProjectEvent;
                this.IsWatching = false;
            }

            if (stopBackgroundValidation && this.IsValidatingInBackground)
            {
                if (this.backgroundTaskHandle != null)
                {
                    if (this.backgroundTaskHandle.IsAlive)
                    {
                        this.backgroundTaskHandle.Kill();
                    }

                    this.backgroundTaskHandle = null;
                }

                this.IsValidatingInBackground = false;
            }
        }

        public void RestartBackgroundValidation()
        {
            this.Clear(true, true);
            this.PopulateQueue(true, false);
            if (!this.IsValidatingInBackground)
                this.StartSession();
        }

        public float CalculateCurrentValidationProgress()
        {
            var remaining = this.RemainingWorkCountSample;
            if (remaining <= 0)
                return 0;

            var workDone = this.WorkDoneCountSample;
            return Mathf.Clamp01(workDone / (float)remaining);
        }

        internal void Enqueue(ValidationWorkItem workItem, bool insert)
        {
            this.AddToQueue(workItem, insert);
        }

        internal void Enqueue(ProjectEvent e, bool insert)
        {
            if (e.Type == ProjectEventType.SceneLoaded)
            {
                var scenesToValidate = this.Config.GetSceneGuidsToValidate();
                if (scenesToValidate.Contains(e.AssetGuid))
                {
                    var sceneRef = new SceneReference(e.AssetGuid);
                    this.AddToQueue(ValidationWorkItem.CreateForSceneContent(sceneRef, ProjectEventSource.Other), insert);
                    this.AddToQueue(ValidationWorkItem.CreateForSceneValidators(sceneRef, ProjectEventSource.Other), insert);
                }
            }
            else if (
                e.Type == ProjectEventType.AssetImported ||
                e.Type == ProjectEventType.AssetModified ||
                e.Type == ProjectEventType.AssetMoved ||
                e.Type == ProjectEventType.AssetRemoved)
            {
                var workItem = ValidationWorkItem.CreateForAssetGuid(e.AssetGuid, e.InstanceID, e.Source);

                if ((e.Type == ProjectEventType.AssetImported) || e.Type == ProjectEventType.AssetModified || e.Type == ProjectEventType.AssetMoved)
                {
                    var assetsToValidate = this.Config.GetAssetsToValidate();
                    if (assetsToValidate.Contains(e.AssetGuid))
                    {
                        this.AddToQueue(workItem, insert);
                    }
                }
                else if (e.Type == ProjectEventType.AssetRemoved)
                {
                    bool wasRemoved = this.WorkDone.Remove(workItem) | this.WorkQueue.Remove(workItem); // Not supposed to be '||'! 

                    if (this.currentlyProcessingWorkItem.HasValue && this.currentlyProcessingWorkItem.Value == workItem)
                    {
                        this.currentlyProcessingWorkItem = null;
                        this.currentlyBackgroundProcessingWorkItemEnumerator?.Dispose();
                        this.currentlyBackgroundProcessingWorkItemEnumerator = null;
                        wasRemoved = true;
                    }

                    if (wasRemoved)
                    {
                        this.RemovedObjectResults.Enqueue(new ValidationSessionResult()
                        {
                            WorkItem = workItem,
                            Result = null,
                            Type = ValidationSessionResult.ValidationSessionResultType.ObjectDeleted,
                        });
                    }
                }
            }
            else if (
                e.Type == ProjectEventType.SceneObjectCreated ||
                e.Type == ProjectEventType.SceneObjectModified ||
                e.Type == ProjectEventType.SceneObjectDeleted)
            {
                var workItem = ValidationWorkItem.CreateForInstanceId(e.InstanceID, e.Source);

                if (e.Type == ProjectEventType.SceneObjectDeleted)
                {
                    bool wasRemoved = this.WorkDone.Remove(workItem) | this.WorkQueue.Remove(workItem); // Not supposed to be '||'! 

                    if (this.currentlyProcessingWorkItem.HasValue && this.currentlyProcessingWorkItem.Value == workItem)
                    {
                        this.currentlyProcessingWorkItem = null;
                        this.currentlyBackgroundProcessingWorkItemEnumerator?.Dispose();
                        this.currentlyBackgroundProcessingWorkItemEnumerator = null;
                        wasRemoved = true;
                    }

                    if (wasRemoved)
                    {
                        this.RemovedObjectResults.Enqueue(new ValidationSessionResult()
                        {
                            WorkItem = workItem,
                            Result = null,
                            Type = ValidationSessionResult.ValidationSessionResultType.ObjectDeleted,
                        });
                    }
                }
                else
                {
                    var uObj = e.UnityObject;
                    var go = uObj as GameObject;
                    var cmp = uObj as Component;

                    if (!go && cmp)
                    {
                        go = cmp.gameObject;
                    }

                    if (!go)
                    {
                        // Invalid scene object. Ignore. // Actually, don't we want to give an error if a component is broken?
                        return;
                    }
                    else if (!go.scene.IsValid() || string.IsNullOrEmpty(go.scene.path))
                    {
                        // Skipping unsaved scene!
                        return;
                    }

                    var guid = AssetDatabase.AssetPathToGUID(go.scene.path);

                    if (this.Config.ShouldValidateScene(guid))
                    {
                        if (e.Type == ProjectEventType.SceneObjectModified &&
                           (e.Source == ProjectEventSource.UndoOrRedoModification || e.Source == ProjectEventSource.UndoOrRedo) &&
                           cmp is Transform)
                        {
                            var transforms = go.GetComponentsInChildren<Transform>();

                            foreach (var trs in transforms)
                            {
                                foreach (var item in trs.GetComponents(typeof(Component)))
                                {
                                    if (item)
                                        this.AddToQueue(ValidationWorkItem.CreateForInstanceId(item.GetInstanceID(), e.Source), insert);
                                }

                                this.AddToQueue(ValidationWorkItem.CreateForInstanceId(trs.gameObject.GetInstanceID(), e.Source), insert);
                            }
                        }
                        else
                        {
                            this.AddToQueue(workItem, insert);
                        }
                    }
                }
            }
        }

        private void AddToQueue(ValidationWorkItem workItem, bool insertFirst)
        {
            if (this.currentlyProcessingWorkItem != workItem)
            {
                if (insertFirst)
                {
                    if (this.WorkQueue.InsertFirst(workItem))
                    {
                        this.RemainingWorkCountSample += workItem.ResultCountEstimate;
                    }
                }
                else
                {
                    if (this.WorkQueue.Enqueue(workItem))
                    {
                        this.RemainingWorkCountSample += workItem.ResultCountEstimate;
                    }
                }
            }
        }

        protected virtual void Dispose(bool finalizer)
        {
            if (!this.disposed)
            {
                if (finalizer)
                {
                    if (this.allocationStackTrace != null)
                    {
#if SIRENIX_INTERNAL
                        Debug.LogError(
#else
                        Debug.LogWarning(
#endif
                            "An Odin ValidationSession instance is being garbage collected without first having been disposed. ValidationSession instances must be disposed once they are no longer needed. This instance was allocated at the following location: \n\n" + this.allocationStackTrace.ToString());
                    }

                    // The session is being garbage collected, but has not yet been disposed.
                    // 
                    // This will "resurrect" the session once and put it back on the reachable heap
                    // while it is waiting to be disposed, through the subscribed action, which will be
                    // cleared after it runs. The second time the session is collected by the GC,
                    // it will have been disposed properly already, and will not be resurrected again.
                    UnityEditorEventUtility.DelayActionThreadSafe(this.ActuallyDispose);
                }
                else
                {
                    this.ActuallyDispose();
                }
            }
#if SIRENIX_INTERNAL
            else
            {
                throw new Exception("Trying to dispose session " + this.Name + ", but it has already been disposed!");
            }
#endif
        }

        private void OnProjectEvent(ProjectEvent[] projectEvent)
        {
            foreach (var item in projectEvent)
            {
                if (item.Type == ProjectEventType.AssetImported || item.Type == ProjectEventType.AssetRemoved)
                {
                    this.Config.UpdateAssets();
                    break;
                }
            }

            foreach (var e in projectEvent)
            {
                Enqueue(e, true);
            }
        }

        private void PrepareNextProgressBar(bool showProgressBar)
        {
            this.RemainingWorkCountSample = this.WorkQueue.TotalResultsEstimate;
            this.WorkDoneCountSample = 0;
            this.shouldDisplayProgressBar = showProgressBar;

            if (this.currentlyProcessingWorkItem.HasValue)
            {
                this.RemainingWorkCountSample += this.currentlyProcessingWorkItem.Value.ResultCountEstimate;
            }
        }

        private void ActuallyDispose()
        {
            if (this.disposed)
            {
#if SIRENIX_INTERNAL
                Debug.LogError("Trying to dispose a ValidationSession but it has already been disposed.");
#endif
                return;
            }

            ActiveValidationSessions.Remove(this);

            this.StopSession();
            this.Clear(true, true);

            this.Runner?.Dispose();
            this.Results?.Dispose();
            this.disposed = true;
            this.allocationStackTrace = null;
        }

        private IEnumerator<ValidationSessionResult> ProcessWorkItem(ValidationWorkItem workItem, bool populateResults)
        {
            var batch = new ValidationSessionResult[100];
            var batchIndex = 0;
            DynamicObjectAddress prevBatchObj = null;

            this.currentlyProcessingWorkItem = workItem;
            try
            {
                var workEstimate = workItem.ResultCountEstimate;
                uint currentWorkItemResultCountSoFar = 0;

                // NonUnityObjectValue
                if (!object.ReferenceEquals(workItem.NonUnityObjectValue, null))
                {
                    var enumerator = this.Runner.ValidateObject(workItem.NonUnityObjectValue).GetEnumerator();

                    while (true)
                    {
                        try
                        {
                            if (!enumerator.MoveNext()) break;
                        }
                        catch (OdinValidationRunner.AssetUnloadedWhileValidatingException ex)
                        {
                            UnityEngine.Debug.LogException(ex);
                            break;
                        }

                        IncrementWorkDone();

                        var result = enumerator.Current;

                        if (result == null || result.HighestSeverityResult.ResultType == ValidationResultType.IgnoreResult)
                        {
                            yield return new ValidationSessionResult()
                            {
                                Type = ValidationSessionResult.ValidationSessionResultType.Ignore,
                            };
                        }
                        else
                        {
                            var e = new ValidationSessionResult()
                            {
                                Result = enumerator.Current,
                                Type = ValidationSessionResult.ValidationSessionResultType.ResultAddedOrChanged,
                                WorkItem = workItem,
                            };

                            AddToBatch(e);
                            yield return e;
                        }
                    }

                    CompleteBatch();
                }
                // Assets
                else if (!object.ReferenceEquals(workItem.AssetGuid, null))
                {
                    var path = AssetDatabase.GUIDToAssetPath(workItem.AssetGuid);

                    if (this.WorkDone.Contains(workItem))
                    {

                    }

                    foreach (var result in this.Runner.ValidateAllAssetsAtPath(path))
                    {
                        IncrementWorkDone();

                        if (result == null || result.HighestSeverityResult.ResultType == ValidationResultType.IgnoreResult)
                        {
                            yield return new ValidationSessionResult()
                            {
                                Type = ValidationSessionResult.ValidationSessionResultType.Ignore,
                            };
                        }
                        else
                        {
                            var r = new ValidationSessionResult()
                            {
                                Result = result,
                                Type = ValidationSessionResult.ValidationSessionResultType.ResultAddedOrChanged,
                                WorkItem = workItem,
                            };

                            AddToBatch(r);
                            yield return r;
                        }
                    }

                    CompleteBatch();

                    //if (path.FastEndsWith(".prefab") || path.FastEndsWith(".fbx") || path.FastEndsWith(".asset") || path.FastEndsWith(".dll"))
                    {
                        WorkItemResultCountCache.RegisterWorkItemResultCount(workItem.AssetGuid, currentWorkItemResultCountSoFar);
                    }
                }
                // Scene Validators
                else if (workItem.SceneValidators.HasValue)
                {
                    if (workItem.SceneValidators.Value.IsLoaded)
                    {
                        var results = this.Runner.ValidateSceneValidators(workItem.SceneValidators.Value);

                        foreach (var result in results)
                        {
                            IncrementWorkDone();

                            if (result == null || result.HighestSeverityResult.ResultType == ValidationResultType.IgnoreResult)
                            {
                                yield return new ValidationSessionResult()
                                {
                                    Type = ValidationSessionResult.ValidationSessionResultType.Ignore,
                                };
                            }
                            else
                            {
                                var r = new ValidationSessionResult()
                                {
                                    Result = result,
                                    Type = ValidationSessionResult.ValidationSessionResultType.ResultAddedOrChanged,
                                    WorkItem = workItem,
                                };
                                AddToBatch(r);
                                yield return r;
                            }
                        }

                        CompleteBatch();
                    }
                    else
                    {
                        this.WorkDoneCountSample++;
                    }
                }
                // Scene Content
                else if (workItem.SceneContent.HasValue)
                {
                    if (workItem.SceneContent.Value.IsLoaded)
                    {
                        var results = this.Runner.ValidateSceneContent(workItem.SceneContent.Value);

                        foreach (var result in results)
                        {
                            IncrementWorkDone();

                            if (result == null || result.HighestSeverityResult.ResultType == ValidationResultType.IgnoreResult)
                            {
                                yield return new ValidationSessionResult()
                                {
                                    Type = ValidationSessionResult.ValidationSessionResultType.Ignore,
                                };
                            }
                            else
                            {
                                var r = new ValidationSessionResult()
                                {
                                    Result = result,
                                    Type = ValidationSessionResult.ValidationSessionResultType.ResultAddedOrChanged,
                                    WorkItem = workItem,
                                };
                                AddToBatch(r);
                                yield return r;
                            }
                        }

                        CompleteBatch();
                        WorkItemResultCountCache.RegisterWorkItemResultCount(workItem.SceneContent.Value.GUID, currentWorkItemResultCountSoFar);
                    }
                    else
                    {
                        // TODO: What happens with the progress bar here?
                        // Should we pretend we did all the work? That's what we do here:
                        if (WorkItemResultCountCache.TryGetLastWorkItemResultCount(workItem.SceneContent.Value.GUID, out var count))
                            this.WorkDoneCountSample += count;
                        else
                            this.WorkDoneCountSample++;
                        // Not loaded scenes will be skipped.
                    }
                }
                // Instance Id's
                else if (workItem.InstanceID != 0)
                {
                    var obj = EditorUtility.InstanceIDToObject(workItem.InstanceID);

                    if (!object.ReferenceEquals(obj, null))
                    {
                        foreach (var result in this.Runner.ValidateObject(obj))
                        {
                            IncrementWorkDone();

                            if (result == null || result.HighestSeverityResult.ResultType == ValidationResultType.IgnoreResult)
                            {
                                yield return new ValidationSessionResult()
                                {
                                    Type = ValidationSessionResult.ValidationSessionResultType.Ignore,
                                };
                            }
                            else
                            {
                                var r = new ValidationSessionResult()
                                {
                                    Result = result,
                                    Type = ValidationSessionResult.ValidationSessionResultType.ResultAddedOrChanged,
                                    WorkItem = workItem,
                                };
                                AddToBatch(r);
                                yield return r;
                            }
                        }

                        CompleteBatch();
                    }
                }
                else
                {
                    UnityEngine.Debug.LogError("There was no work to be done in a work item?");
                }

                void IncrementWorkDone()
                {
                    this.WorkDoneCountSample++;
                    currentWorkItemResultCountSoFar++;
                    if (currentWorkItemResultCountSoFar > workEstimate)
                        this.RemainingWorkCountSample++;
                }

                void AddToBatch(ValidationSessionResult r)
                {
                    if (populateResults && r.Type != ValidationSessionResult.ValidationSessionResultType.Ignore)
                    {
                        if (r.Type == ValidationSessionResult.ValidationSessionResultType.ObjectDeleted)
                        {
                            CompleteBatch();
                        }
                        else if (r.Result.DynamicObjectAddress != prevBatchObj)
                        {
                            CompleteBatch();
                        }

                        prevBatchObj = r.Result?.DynamicObjectAddress;

                        if (batchIndex >= batch.Length)
                            Array.Resize(ref batch, batchIndex * 2);

                        batch[batchIndex++] = r;
                    }
                }

                void CompleteBatch()
                {
                    if (populateResults && batchIndex > 0)
                    {
                        this.Results.Enqueue(new ArraySlice<ValidationSessionResult>(batch, 0, batchIndex));
                        batchIndex = 0;
                    }
                }
            }
            finally
            {
                this.WorkDone.Add(workItem);

                if (this.WorkQueue.Count == 0)
                {
                    this.PrepareNextProgressBar(false);
                }

                this.prevProcessedWorkItem = workItem;
                this.currentlyProcessingWorkItem = null;
            }
        }

        private IEnumerator BackgroundValidationTicker()
        {
            var batch = new ValidationSessionResult[100];
            var batchIndex = 0;
            DynamicObjectAddress prevBatchObj = null;

            while (true)
            {
                var relax = this.RemovedObjectResults.Count == 0 && this.WorkQueue.Count == 0 && this.currentlyBackgroundProcessingWorkItemEnumerator == null;

                if (relax)
                {
                    yield return BackgroundTaskRunner.Relax;
                }
                else
                {
                    while (this.RemovedObjectResults.Count > 0)
                    {
                        var removed = this.RemovedObjectResults.Dequeue();
                        this.Results?.Enqueue(removed); // OK
                        yield return null;
                    }

                    if (this.currentlyBackgroundProcessingWorkItemEnumerator == null && this.WorkQueue.Count > 0)
                    {
                        this.currentlyBackgroundProcessingWorkItemEnumerator = this.ProcessWorkItem(this.WorkQueue.Dequeue(), true);
                    }

                    if (this.currentlyBackgroundProcessingWorkItemEnumerator != null)
                    {
                        if (this.currentlyBackgroundProcessingWorkItemEnumerator.MoveNext())
                        {
                            yield return null;
                        }
                        else
                        {
                            this.currentlyBackgroundProcessingWorkItemEnumerator?.Dispose();
                            this.currentlyBackgroundProcessingWorkItemEnumerator = null;
                        }
                    }
                }
            }
        }

        public void Dispose()
        {
            Dispose(finalizer: false);
        }

        ~ValidationSession()
        {
            if (!this.disposed)
            {
                Dispose(finalizer: true);
            }
        }


        public struct ValidationSessionResult
        {
            public ValidationSessionResultType Type;
            public ValidationWorkItem WorkItem;
            public PersistentValidationResult Result;

            public enum ValidationSessionResultType
            {
                /// <summary>
                /// Result can be null.
                /// </summary>
                Ignore,
                ResultAddedOrChanged,

                /// <summary>
                /// Result will be null if the object is deleted.
                /// </summary>
                ObjectDeleted,
            }

            public bool Equals(ValidationSessionResult other)
            {
                if (other.Result != null && this.Result != null)
                {
                    return this.Result == other.Result;
                }

                return this.WorkItem == other.WorkItem;
            }
        }
    }
}
#endif