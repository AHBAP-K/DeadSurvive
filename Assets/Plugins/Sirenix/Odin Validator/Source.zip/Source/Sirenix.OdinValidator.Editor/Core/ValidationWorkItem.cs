//-----------------------------------------------------------------------
// <copyright file="ValidationSession.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor.Validation;
    using Sirenix.Utilities;
    using System;
    using System.Collections.Generic;
    using System.Text;
    using UnityEditor;
    using UnityEngine;

    public struct ValidationWorkItem : IEquatable<ValidationWorkItem>
    {
        public object NonUnityObjectValue;
        public string AssetGuid;
        public SceneReference? SceneContent;
        public SceneReference? SceneValidators;
        public int InstanceID;
        public ProjectEventSource Source;
        public uint ResultCountEstimate;

        public SceneReference? GetSceneReference() => SceneContent ?? SceneValidators;

        public static ValidationWorkItem CreateForNonUnityObject(object obj, ProjectEventSource projectEventSource)
        {
            var result = new ValidationWorkItem();
            result.Source = projectEventSource;
            result.NonUnityObjectValue = obj;
            return result;
        }

        public static ValidationWorkItem CreateForAssetGuid(string assetGuid, int instanceId, ProjectEventSource projectEventSource)
        {
            var result = new ValidationWorkItem();
            result.Source = projectEventSource;
            result.AssetGuid = assetGuid;
            result.InstanceID = instanceId;

            //#if !ODIN_BETA && !SIRENIX_INTERNAL
            //#error NONONONONONONOONONNOON
            //#endif
            if (AssetDatabase.GUIDToAssetPath(assetGuid).FastEndsWith(".unity"))
            {
                result.ResultCountEstimate = 1;
            }
            else
            {
                if (!WorkItemResultCountCache.TryGetLastWorkItemResultCount(assetGuid, out result.ResultCountEstimate))
                {
                    result.ResultCountEstimate = 1;
                }
            }
            return result;
        }

        public static ValidationWorkItem CreateForAssetGuid(string assetGuid, ProjectEventSource projectEventSource)
        {
            var result = new ValidationWorkItem();
            result.Source = projectEventSource;
            result.AssetGuid = assetGuid;

            //#if !ODIN_BETA && !SIRENIX_INTERNAL
            //#error NONONONONONONOONONNOON
            //#endif
            if (AssetDatabase.GUIDToAssetPath(assetGuid).FastEndsWith(".unity"))
            {
                result.ResultCountEstimate = 1;
            }
            else
            {
                if (!WorkItemResultCountCache.TryGetLastWorkItemResultCount(assetGuid, out result.ResultCountEstimate))
                {
                    result.ResultCountEstimate = 1;
                }
            }
            return result;
        }

        public static ValidationWorkItem CreateForSceneContent(SceneReference scene, ProjectEventSource projectEventSource)
        {
            var result = new ValidationWorkItem();
            result.Source = projectEventSource;
            result.SceneContent = scene;
            if (!WorkItemResultCountCache.TryGetLastWorkItemResultCount(scene.GUID, out result.ResultCountEstimate))
            {
                result.ResultCountEstimate = 1;
            }
            return result;
        }

        public static ValidationWorkItem CreateForSceneValidators(SceneReference scene, ProjectEventSource projectEventSource)
        {
            var result = new ValidationWorkItem();
            result.Source = projectEventSource;
            result.SceneValidators = scene;
            result.ResultCountEstimate = 1;
            return result;
        }

        public static ValidationWorkItem CreateForInstanceId(int instanceId, ProjectEventSource projectEventSource)
        {
            var result = new ValidationWorkItem();
            result.Source = projectEventSource;
            result.InstanceID = instanceId;
            result.ResultCountEstimate = 1;

            return result;
        }

        public bool IsValid() => 
            this.NonUnityObjectValue != null || 
            !string.IsNullOrEmpty(this.AssetGuid) || 
            this.InstanceID != 0 || 
            this.SceneContent.HasValue ||
            this.SceneValidators.HasValue;

        public static bool operator ==(ValidationWorkItem x, ValidationWorkItem y)
        {
            if (x.NonUnityObjectValue != null || y.NonUnityObjectValue != null)
            {
                if (x.NonUnityObjectValue == null || y.NonUnityObjectValue == null) return false;
                return object.ReferenceEquals(x.NonUnityObjectValue, y.NonUnityObjectValue) || x.NonUnityObjectValue.Equals(y.NonUnityObjectValue);
            }

            if (x.AssetGuid != null || y.AssetGuid != null)
                return x.AssetGuid == y.AssetGuid;

            if (x.SceneValidators.HasValue || y.SceneValidators.HasValue)
                return x.SceneValidators == y.SceneValidators;

            if (x.SceneContent.HasValue || y.SceneContent.HasValue)
                return x.SceneContent == y.SceneContent;

            return x.InstanceID == y.InstanceID;
        }

        public static bool operator !=(ValidationWorkItem x, ValidationWorkItem y)
        {
            return !(x == y);
        }

        public override int GetHashCode()
        {
            if (((object)this.NonUnityObjectValue) != null) return this.NonUnityObjectValue.GetHashCode();
            if (this.AssetGuid != null) return this.AssetGuid.GetHashCode();
            if (this.InstanceID != 0) return this.InstanceID;
            if (this.SceneValidators.HasValue) return (this.SceneValidators.Value.GUID ?? "").GetHashCode();
            if (this.SceneContent.HasValue) return (this.SceneContent.Value.GUID ?? "").GetHashCode();
            return 0;
        }

        public override bool Equals(object obj)
        {
            if (obj is ValidationWorkItem)
            {
                return this == (ValidationWorkItem)obj;
            }

            return false;
        }

        bool IEquatable<ValidationWorkItem>.Equals(ValidationWorkItem other)
        {
            return this == other;
        }

        public struct Comparer : IEqualityComparer<ValidationWorkItem>
        {
            public bool Equals(ValidationWorkItem x, ValidationWorkItem y)
            {
                return x == y;
            }

            public int GetHashCode(ValidationWorkItem key)
            {
                return key.GetHashCode();
            }
        }

        public string ToNiceString()
        {
            var sb = new StringBuilder();
            UnityEngine.Object uObj = null;

            if (this.InstanceID != 0)
            {
                uObj = EditorUtility.InstanceIDToObject(this.InstanceID);
                if (uObj)
                {
                    sb.Append($"Type name: {uObj.name}, ");
                    sb.Append($"Object name: {GetNiceBaseUnityObjectTypeName(uObj)}, ");
                }

                sb.Append($"Instance Id: {this.InstanceID}, ");
            }

            if (!string.IsNullOrEmpty(this.AssetGuid))
            {
                sb.Append($"Asset guid: {this.AssetGuid}, ");

                var assetPath = AssetDatabase.GUIDToAssetPath(this.AssetGuid);
                sb.Append($"Asset path: {assetPath}, ");

                if (!uObj)
                {
                    uObj = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(assetPath);
                    if (uObj)
                    {
                        sb.Append($"Type name: {uObj.name}, ");
                        sb.Append($"Object name: {GetNiceBaseUnityObjectTypeName(uObj)}, ");
                    }
                }
            }

            if (this.SceneValidators.HasValue)
            {
                sb.Append($"Scene Validators Name: {this.SceneValidators.Value.Name}, ");
            }

            if (this.SceneContent.HasValue)
            {
                sb.Append($"Scene Validators Name: {this.SceneContent.Value.Name}, ");
            }

            return sb.ToString();
        }

        private static string GetNiceBaseUnityObjectTypeName(UnityEngine.Object obj)
        {
            if (obj == null)
                throw new ArgumentNullException(nameof(obj));

            var isAsset = AssetDatabase.Contains(obj);
            var unityType = obj.GetType();
            if (isAsset)
            {
                if (unityType == typeof(GameObject))
                    return "Prefab";

                if (typeof(Component).IsAssignableFrom(unityType))
                    return "Prefab Component";

                if (typeof(ScriptableObject).IsAssignableFrom(unityType))
                    return "Scriptable Object";
            }
            else
            {
                if (unityType == typeof(GameObject))
                    return "GameObject";

                if (typeof(Component).IsAssignableFrom(unityType))
                    return "Component";
            }

            return unityType.GetNiceName();
        }

    }
}
#endif