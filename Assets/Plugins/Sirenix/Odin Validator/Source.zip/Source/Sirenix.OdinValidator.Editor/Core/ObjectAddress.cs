//-----------------------------------------------------------------------
// <copyright file="ObjectAddress.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
using Sirenix.OdinInspector.Editor;
using Sirenix.OdinInspector.Editor.Validation;
using Sirenix.Utilities;
using Sirenix.Utilities.Editor;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Sirenix.OdinValidator.Editor
{
    [Serializable]
    public class ObjectAddress : IEquatable<ObjectAddress>
    {
        public static readonly ObjectAddress Unknown = new ObjectAddress() { Type = AddressType.Unknown };

        [SerializeField]
        private string guid;

        public bool IsBroken;

        public AddressType Type;

        public string AssetGUID
        {
            get { return this.guid; }
            set
            {
                if (value == null || value.Length == 32)
                    this.guid = value;
                else
                    throw new Exception("Invalid asset guid");
            }
        }

        public string AssetPath;
        public SubAssetAddress SubAsset;
        public HierarchyAddress Hierarchy;
        public ComponentAddress Component;
        public string Name;
        public UnitySerializableType ObjectType;

        public bool IsSceneAsset()
        {
            if (this.Type == AddressType.Asset && this.AssetPath.FastEndsWith(".unity"))
            {
                return true;
            }

            return false;
        }

        private ObjectAddress()
        {
        }

        public static bool TryCreateObjectAddress(UnityEngine.Object obj, out ObjectAddress finalResult, out string errorMessage)
        {
            if (obj == null)
            {
                if (!ReferenceEquals(obj, null))
                {
                    if (AssetDatabase.Contains(obj.GetInstanceID()))
                    {
                        var path = AssetDatabase.GetAssetPath(obj.GetInstanceID());

                        if (!string.IsNullOrEmpty(path))
                        {

                            finalResult = new ObjectAddress()
                            {
                                ObjectType = obj.GetType(),
                                IsBroken = true,
                                AssetPath = path,
                                AssetGUID = AssetDatabase.AssetPathToGUID(path),
                                Name = path.GetObjectNameFromAssetPath(),
                                Type = AddressType.Asset,
                            };
                            errorMessage = null;
                            return true;
                        }
                        else
                        {
                            finalResult = null;
                            errorMessage = "No asset path was found for the asset with instance ID: " + obj.GetInstanceID();
                            return false;
                        }
                    }
                    else if ((obj is Component) || (obj is GameObject))
                    {
                        finalResult = null;
                        errorMessage = $"Cannot create ObjectAddress for unsaved gameobjects.";
                        return false;
                    }
                    else
                    {
                        finalResult = null;
                        errorMessage = $"Cannot create address for non-asset {obj.GetType().GetNiceName()} instance.";
                        return false;
                    }
                }

                finalResult = null;
                errorMessage = $"Cannot create ObjectAddress for null object.";
                return false;
            }
            else
            {
                GameObject go = null;
                Component cmp = null;

                if (obj is GameObject)
                {
                    go = obj as GameObject;
                }

                if (obj is Component)
                {
                    cmp = obj as Component;
                    go = cmp.gameObject;
                }

                if (!go)
                {
                    var isAsset = AssetDatabase.Contains(obj);

                    if (!isAsset)
                    {
                        finalResult = null;
                        errorMessage = $"Cannot create address for non-asset {obj.GetType().GetNiceName()} instance.";
                        return false;
                    }

                    var path = AssetDatabase.GetAssetPath(obj);
                    var guid = AssetDatabase.AssetPathToGUID(path);
                    var type = obj.GetType();
                    var isMainAsset = AssetDatabase.IsMainAsset(obj);

                    finalResult = new ObjectAddress()
                    {
                        ObjectType = obj.GetType(),
                        Name = obj.name,
                        AssetPath = path,
                        AssetGUID = guid,
                        Type = AddressType.Asset,
                        SubAsset = isMainAsset ? default(SubAssetAddress) : new SubAssetAddress(type, obj.GetInstanceID(), -1)
                    };
                    errorMessage = null;
                    return true;
                }
                else
                {
                    var isPrefab = AssetDatabase.Contains(go);

                    if (!isPrefab && (!go.scene.IsValid() || string.IsNullOrEmpty(go.scene.path)))
                    {
                        errorMessage = "Cannot create address for GameObject in unsaved scene or prefab stage.";
                        finalResult = null;
                        return false;
                    }

                    string path = isPrefab ? AssetDatabase.GetAssetPath(obj) : go.scene.path;
                    string guid = AssetDatabase.AssetPathToGUID(path);
                    HierarchyAddress hierarchy = GetHierarchyAddress(go);

                    if (cmp != null)
                    {
                        var components = go.GetComponents(cmp.GetType());
                        var componentIndex = -1;

                        for (int i = 0; i < components.Length; i++)
                        {
                            if (components[i] == cmp)
                            {
                                componentIndex = i;
                                break;
                            }
                        }

                        if (componentIndex < 0)
                        {
                            errorMessage = "Component was not in its own GameObject?!";
                            finalResult = null;
                            return false;
                        }

                        finalResult = new ObjectAddress()
                        {
                            ObjectType = cmp.GetType(),
                            AssetGUID = guid,
                            Name = cmp.gameObject.name,
                            AssetPath = path,
                            Type = isPrefab ? AddressType.PrefabComponent : AddressType.SceneComponent,
                            Hierarchy = hierarchy,
                            Component = new ComponentAddress(componentIndex, cmp.GetType())
                        };
                        errorMessage = null;
                        return true;
                    }
                    else
                    {
                        finalResult = new ObjectAddress()
                        {
                            ObjectType = obj.GetType(),
                            Name = go.name,
                            AssetGUID = guid,
                            AssetPath = path,
                            Type = isPrefab ? AddressType.PrefabGameObject : AddressType.SceneGameObject,
                            Hierarchy = hierarchy,
                        };
                        errorMessage = null;
                        return true;
                    }
                }
            }
        }

        public static HierarchyAddress GetHierarchyAddress(GameObject go)
        {
            var indices = new Stack<int>();
            var names = new Stack<string>();

            var transform = go.transform;

            if (go.scene.IsValid())
            {
                do
                {
                    indices.Push(transform.GetSiblingIndex());
                    names.Push(transform.name);

                    transform = transform.parent;
                } while (transform != null);
            }
            else
            {
                while (transform.parent != null)
                {
                    indices.Push(transform.GetSiblingIndex());
                    names.Push(transform.name);

                    transform = transform.parent;
                }
            }

            return new HierarchyAddress(names.ToArray(), indices.ToArray());
        }

        public ObjectAddress(SceneReference validatedScene)
        {
            this.Type = AddressType.Asset;
            this.AssetGUID = validatedScene.GUID;
            this.AssetPath = validatedScene.Path;
            this.ObjectType = typeof(SceneAsset);
            this.Name = validatedScene.Name;
        }

        public ObjectAddress(AddressType type, string assetGUID, string assetPath, SubAssetAddress subAsset, HierarchyAddress hierarchyAddress, ComponentAddress component, string niceObjectName, Type objectType, bool isBroken)
        {
            this.Type = type;
            this.AssetGUID = assetGUID;
            this.AssetPath = assetPath;
            this.SubAsset = subAsset;
            this.Hierarchy = hierarchyAddress;
            this.Component = component;
            this.IsBroken = isBroken;
            this.ObjectType = objectType;
            this.Name = niceObjectName;
        }

        public static ObjectAddress Parse(string json)
        {
            var slice = json.Slice().Trim();

            if (slice == "Unknown") return Unknown;
            if (slice == "Broken" || slice == "Invalid") return new ObjectAddress() { IsBroken = true, };

            return JsonUtility.FromJson<ObjectAddress>(json);
        }

        public string ToString(bool prettyPrint = false)
        {
            //if (this.IsBroken) return "Broken";
            if (this.Type == AddressType.Unknown) return "Unknown";

            if (string.IsNullOrWhiteSpace(this.AssetPath) && string.IsNullOrWhiteSpace(this.AssetGUID))
            {
                return "Invalid";
            }

            return JsonUtility.ToJson(this, prettyPrint);
        }

        public override string ToString()
        {
            return this.ToString(false);
        }


        public bool TryGetObjectReference(bool openSceneIfNeeded, bool autoSaveIfOpenScene, out UnityEngine.Object result, out string errorMessage)
        {
            return this.TryGetObjectReference(openSceneIfNeeded, autoSaveIfOpenScene, out result, out errorMessage, out var _);
        }

        public bool TryGetObjectReference(bool openSceneIfNeeded, bool autoSaveIfOpenScene, out UnityEngine.Object result, out string errorMessage, out UnityEngine.Object closestObject)
        {
            var isAsset = this.AssetPath != null || this.AssetGUID != null;
            closestObject = null;

            if (!isAsset)
            {
                result = null;
                errorMessage = $"Invalid asset address. Guid: {this.AssetGUID}, Path: {this.AssetPath}";
                closestObject = null;
                return false;
            }

            result = null;

            var assetPath = this.AssetPath;
            var assetGuid = this.AssetGUID;

            if (assetGuid == null)
                assetGuid = AssetDatabase.AssetPathToGUID(assetPath);

            if (assetPath == null)
                assetPath = AssetDatabase.GUIDToAssetPath(assetGuid);

            if (this.SubAsset.HasData())
            {
                var assets = AssetDatabase.LoadAllAssetsAtPath(assetPath);

                if (assets.Length > 0)
                {
                    closestObject = assets[0];
                }

                if (assetGuid == "0000000000000000e000000000000000"  // Library/unity default resources
                 || assetGuid == "0000000000000000f000000000000000") // Resources/unity_builtin_extra
                {
                    // Check names first in this case
                    foreach (var asset in assets)
                    {
                        var name = asset.name;
                        var type = asset.GetType();

                        if (name == this.Name && object.ReferenceEquals(type, this.SubAsset.AssetType.Type))
                        {
                            result = asset;

                            //#if SIRENIX_INTERNAL
                            //                            Debug.LogError("GOOD CASE: Loaded builtin unity thing properly: " + this.Name + " (" + this.SubAsset.AssetType.Type + ")");
                            //#elif !ODIN_BETA
                            //#error REMOVE THIS DAMN CODE BEFORE YOU RELEASE
                            //#endif
                            goto CHECK_RESULT_VALIDITY;
                        }
                    }
                }

                foreach (var asset in assets)
                {
                    var instanceId = asset.GetInstanceID();
                    if (instanceId == this.SubAsset.InstanceID)
                    {
                        result = asset;
                        goto CHECK_RESULT_VALIDITY;
                    }
                }

                foreach (var asset in assets)
                {
                    var name = asset.name;
                    var type = asset.GetType();

                    if (name == this.Name && object.ReferenceEquals(type, this.SubAsset.AssetType.Type))
                    {
                        result = asset;
                        goto CHECK_RESULT_VALIDITY;
                    }
                }

                result = EditorUtility.InstanceIDToObject(this.SubAsset.InstanceID);

            //#if SIRENIX_INTERNAL

            //                if (result != null && (assetGuid == "0000000000000000e000000000000000"
            //                 || assetGuid == "0000000000000000f000000000000000"))
            //                {
            //                    Debug.LogError("BAD CASE: Loaded builtin unity thing via instance id, this is not good!: " + this.Name + " (" + this.SubAsset.AssetType.Type + ")");
            //                }
            //#elif !ODIN_BETA
            //#error REMOVE THIS DAMN CODE BEFORE YOU RELEASE
            //#endif

            CHECK_RESULT_VALIDITY:

                if (result != null)
                {
                    if (result.GetType() != this.SubAsset.AssetType)
                    {
                        errorMessage = $"Expected asset with instance ID '{this.SubAsset.InstanceID}' to be of type '{this.SubAsset.AssetType.GetNiceName()}', but it was of type '{result.GetType().GetNiceName()}'.";
                        return false;
                    }

                    errorMessage = null;
                    closestObject = result;
                    return true;
                }

                errorMessage = $"Could not find asset with instance ID '{this.SubAsset.InstanceID}' at path '{assetPath}'";
                return false;
            }
            else if (this.Hierarchy.HasData())
            {
                GameObject foundGameobject = null;
                Transform[] rootTransforms;
                bool isScene = false;

                if (assetPath.FastEndsWith(".unity"))
                {
                    isScene = true;

                    if (this.Hierarchy.SubNames.Length == 0)
                    {
                        errorMessage = "No scene hierarchy root was specified in address.";
                        return false;
                    }

                    var sceneRef = new SceneReference(assetGuid);
                    Scene scene;

                    if (!sceneRef.IsLoaded)
                    {
                        if (!openSceneIfNeeded)
                        {
                            errorMessage = "Needed to open scene to find object, but the argument 'openSceneIfNeeded' is false.";
                            return false;
                        }

                        //if (!sceneRef.TryGetScene(out scene))
                        //{
                        //    errorMessage = $"Could not get scene at path '{assetPath}'.";
                        //    return false;
                        //}

                        if (autoSaveIfOpenScene)
                        {
                            EditorSceneManager.SaveOpenScenes();
                        }
                        else
                        {
                            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                            {
                                errorMessage = "User cancelled scene load.";
                                return false;
                            }
                        }

                        if (!sceneRef.TryOpenScene(OpenSceneMode.Single, out scene))
                        {
                            errorMessage = $"Could not load scene at path '{assetPath}'.";
                            return false;
                        }
                    }
                    else if (!sceneRef.TryGetScene(out scene))
                    {
                        errorMessage = $"Could not get scene at path '{assetPath}'.";
                        return false;
                    }

                    rootTransforms = SceneUtilities.GetSceneRoots(scene).Select(n => n.transform).ToArray();
                }
                else if (assetPath.FastEndsWith(".prefab"))
                {
                    var mainAsset = AssetDatabase.LoadMainAssetAtPath(assetPath);

                    if (mainAsset == null)
                    {
                        errorMessage = $"Asset at path '{assetPath}' was null when loaded.";
                        return false;
                    }

                    closestObject = mainAsset;

                    if (!(mainAsset is GameObject))
                    {
                        errorMessage = $"Asset at path '{assetPath}' was not a valid prefab, despite being in a .prefab file.";
                        return false;
                    }

                    var go = mainAsset as GameObject;

                    if (this.Hierarchy.SubNames.Length == 0)
                    {
                        foundGameobject = go;
                        goto FOUND_GO;
                    }

                    var transform = go.transform;

                    rootTransforms = new Transform[transform.childCount];

                    for (int i = 0; i < transform.childCount; i++)
                    {
                        rootTransforms[i] = transform.GetChild(i);
                    }
                }
                else
                {
                    errorMessage = $"Address contained hierarchy info for asset '{assetPath}' which is neither a scene or a prefab.";
                    return false;
                }

                Transform[] currentTransforms = rootTransforms;
                var length = this.Hierarchy.SubNames.Length;

                for (int i = 0; i < length; i++)
                {
                    var index = this.Hierarchy.SubIndices[i];
                    var name = this.Hierarchy.SubNames[i];
                    var nameColissionCount = 0;
                    Transform candidate = null;
                    Transform next = null;

                    if (index >= 0 && index < currentTransforms.Length && currentTransforms[index].name == name)
                    {
                        next = currentTransforms[index];

                        if (i == length - 1)
                        {
                            foundGameobject = next.gameObject;
                            goto FOUND_GO;
                        }

                        goto FOUND_NEXT;
                    }

                    for (int j = 0; j < currentTransforms.Length; j++)
                    {
                        var transform = currentTransforms[j];

                        if (transform.name == name)
                        {
                            nameColissionCount++;
                            candidate = transform;

                            if (nameColissionCount == 2)
                                break;
                        }
                    }

                    if (nameColissionCount == 1)
                    {
                        next = candidate;

                        if (i == length - 1)
                        {
                            foundGameobject = candidate.gameObject;
                            goto FOUND_GO;
                        }

                        goto FOUND_NEXT;
                    }

                    if (index < currentTransforms.Length)
                    {
                        next = currentTransforms[index];

                        if (i == length - 1)
                        {
                            foundGameobject = next.gameObject;
                            goto FOUND_GO;
                        }

                        goto FOUND_NEXT;
                    }

                    if (candidate)
                    {
                        next = candidate;

                        if (i == length - 1)
                        {
                            foundGameobject = candidate.gameObject;
                            goto FOUND_GO;
                        }

                        goto FOUND_NEXT;
                    }

                    errorMessage = $"Could not find GameObject at path '{string.Join("/", this.Hierarchy.SubNames)}' in {(isScene ? "scene" : "prefab")} '{assetPath}'";
                    return false;

                FOUND_NEXT:

                    closestObject = next;
                    var childCount = next.childCount;

                    currentTransforms = new Transform[childCount];

                    for (int n = 0; n < childCount; n++)
                    {
                        currentTransforms[n] = next.GetChild(n);
                    }
                }

                errorMessage = $"Could not find GameObject at path '{string.Join("/", this.Hierarchy.SubNames)}'";
                return false;

            FOUND_GO:
                closestObject = foundGameobject;

                if (this.Component != null && this.Component.ComponentIndex >= 0 && !string.IsNullOrEmpty(this.Component.ComponentType.TypeName))
                {
                    result = foundGameobject;

                    var components = foundGameobject.GetComponents(this.Component.ComponentType);

                    if (this.Component.ComponentIndex < components.Length)
                    {
                        errorMessage = null;
                        result = components[this.Component.ComponentIndex];
                        return true;
                    }

                    errorMessage = $"Expected at least {this.Component.ComponentIndex + 1} components " +
                        $"of type '{this.Component.ComponentType.GetNiceName()}' on " +
                        $"GameObject '{string.Join("/", this.Hierarchy.SubNames)}' in " +
                        $"{(isScene ? "scene" : "prefab")} '{assetPath}', but there were {components.Length} components of that type.";
                    return false;
                }
                else
                {
                    errorMessage = null;
                    result = foundGameobject;
                    return true;
                }
            }
            else
            {
                var asset = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(assetPath);

                if (asset)
                {
                    result = asset;
                    closestObject = result;
                    errorMessage = null;
                    return true;
                }
                else
                {
                    result = asset;
                    errorMessage = "Broken asset reference";
                    return false;
                }
            }
        }

        public override bool Equals(object obj)
        {
            if (obj is ObjectAddress)
            {
                return this == (ObjectAddress)obj;
            }

            return false;
        }

        public bool Equals(ObjectAddress other)
        {
            return this == other;
        }

        public static bool operator ==(ObjectAddress a, ObjectAddress b)
        {
            if (object.ReferenceEquals(a, b)) return true;
            if (object.ReferenceEquals(a, null) != object.ReferenceEquals(b, null)) return false;
            if (a.Type != b.Type) return false;
            if (a.Type == AddressType.Unknown) return true;
            if (a.IsBroken != b.IsBroken) return false;

            var aGuid = a.AssetGUID ?? AssetDatabase.AssetPathToGUID(a.AssetPath);
            var bGuid = b.AssetGUID ?? AssetDatabase.AssetPathToGUID(b.AssetPath);

            if (aGuid != bGuid) return false;

            switch (a.Type)
            {
                case AddressType.Asset:
                    if (a.SubAsset != b.SubAsset)
                    {
                        return false;
                    }
                    break;
                case AddressType.PrefabGameObject:
                case AddressType.SceneGameObject:
                    if (a.Hierarchy != b.Hierarchy)
                    {
                        return false;
                    }
                    break;
                case AddressType.PrefabComponent:
                case AddressType.SceneComponent:
                    if (a.Hierarchy != b.Hierarchy || a.Component != b.Component)
                    {
                        return false;
                    }
                    break;
                case AddressType.Unknown:
                default:
                    throw new NotImplementedException(a.Type.ToString());
            }

            return true;
        }

        public static bool operator !=(ObjectAddress a, ObjectAddress b)
        {
            return !(a == b);
        }

        public override int GetHashCode()
        {
            if (this.Type == AddressType.Unknown) return 0;

            int hash = 2998421;

            unchecked
            {
                var guid = this.AssetGUID ?? AssetDatabase.AssetPathToGUID(this.AssetPath);

                hash = guid.GetHashCode() * 17;

                if (this.IsBroken)
                {
                    hash *= 49339;
                }

                switch (this.Type)
                {
                    case AddressType.Asset:
                        if (this.SubAsset != null)
                        {
                            hash ^= this.SubAsset.GetHashCode() * 19;
                        }
                        break;
                    case AddressType.PrefabGameObject:
                    case AddressType.SceneGameObject:
                        hash ^= this.Hierarchy.GetHashCode() * 19;
                        break;
                    case AddressType.PrefabComponent:
                    case AddressType.SceneComponent:
                        hash ^= this.Hierarchy.GetHashCode() * 19;
                        hash ^= this.Component.GetHashCode() * 23;
                        break;
                    case AddressType.Unknown:
                    default:
                        throw new NotImplementedException(this.Type.ToString());
                }
            }

            return hash;
        }

        [Serializable]
        public struct SubAssetAddress : IEquatable<SubAssetAddress>
        {
            public UnitySerializableType AssetType;
            public int InstanceID;
            public int Index;

            public SubAssetAddress(Type assetType, int instanceID, int index)
            {
                this.AssetType = assetType;
                this.InstanceID = instanceID;
                this.Index = index;
            }

            public override bool Equals(object obj)
            {
                if (obj is SubAssetAddress)
                {
                    return this == (SubAssetAddress)obj;
                }

                return false;
            }

            public bool Equals(SubAssetAddress other)
            {
                return this == other;
            }

            public override int GetHashCode()
            {
                return this.AssetType.GetHashCode() ^ this.InstanceID;
            }

            public static bool operator ==(SubAssetAddress a, SubAssetAddress b)
            {
                if (object.ReferenceEquals(a, b)) return true;
                if (object.ReferenceEquals(a, null) != object.ReferenceEquals(b, null)) return false;

                return a.InstanceID == b.InstanceID &&
                    FastTypeComparer.Instance.Equals(a.AssetType, b.AssetType);
            }

            public static bool operator !=(SubAssetAddress a, SubAssetAddress b)
            {
                return !(a == b);
            }

            public bool HasData()
            {
                return this.InstanceID != 0 && !object.ReferenceEquals(this.AssetType.Type, null);
            }
        }

        [Serializable]
        public struct HierarchyAddress : IEquatable<HierarchyAddress>
        {
            public string[] SubNames;
            public int[] SubIndices;

            public HierarchyAddress(string[] subNames, int[] subIndices)
            {
                if (subNames.Length != subIndices.Length) throw new Exception($"Length of {nameof(subNames)} and {nameof(subIndices)} must be the same!");

                this.SubNames = subNames;
                this.SubIndices = subIndices;
            }

            public override int GetHashCode()
            {
                int hash = 2998421;

                unchecked
                {
                    if (this.SubNames != null)
                    {
                        for (int i = 0; i < this.SubNames.Length; i++)
                        {
                            hash ^= this.SubNames[i].GetHashCode();
                            hash ^= this.SubIndices[i].GetHashCode();
                        }
                    }
                }

                return hash;
            }

            public override bool Equals(object obj)
            {
                if (obj is HierarchyAddress)
                {
                    return this == (HierarchyAddress)obj;
                }

                return false;
            }

            public bool Equals(HierarchyAddress other)
            {
                return this == other;
            }

            public static bool operator ==(HierarchyAddress a, HierarchyAddress b)
            {
                if (object.ReferenceEquals(a.SubNames, b.SubNames)) return true;
                if (object.ReferenceEquals(a.SubNames, null) != object.ReferenceEquals(b.SubNames, null)) return false;

                if (a.SubNames.Length != b.SubNames.Length || a.SubIndices.Length != b.SubIndices.Length) return false;

                for (int i = 0; i < a.SubNames.Length; i++)
                {
                    if (a.SubNames[i] != b.SubNames[i]) return false;
                }

                for (int i = 0; i < a.SubIndices.Length; i++)
                {
                    if (a.SubIndices[i] != b.SubIndices[i]) return false;
                }

                return true;
            }

            public static bool operator !=(HierarchyAddress a, HierarchyAddress b)
            {
                return !(a == b);
            }

            public override string ToString()
            {
                if (this.SubNames == null || this.SubNames.Length == 0)
                {
                    return string.Empty;
                }

                return string.Join("/", this.SubNames);
            }

            public bool HasData()
            {
                return this.SubNames != null && this.SubNames.Length > 0 && this.SubIndices != null && this.SubIndices.Length > 0;
            }
        }

        [Serializable]
        public struct ComponentAddress : IEquatable<ComponentAddress>
        {
            public int ComponentIndex;
            public UnitySerializableType ComponentType;

            public ComponentAddress(int componentIndex, Type componentType)
            {
                this.ComponentIndex = componentIndex;
                this.ComponentType = componentType;
            }

            public override bool Equals(object obj)
            {
                if (obj is ComponentAddress)
                {
                    return this == (ComponentAddress)obj;
                }

                return false;
            }

            public bool Equals(ComponentAddress other)
            {
                return this == other;
            }

            public override int GetHashCode()
            {
                return this.ComponentType.GetHashCode() ^ this.ComponentIndex;
            }

            public static bool operator ==(ComponentAddress a, ComponentAddress b)
            {
                if (object.ReferenceEquals(a, b)) return true;
                if (object.ReferenceEquals(a, null) != object.ReferenceEquals(b, null)) return false;

                return a.ComponentIndex == b.ComponentIndex &&
                    FastTypeComparer.Instance.Equals(a.ComponentType, b.ComponentType);
            }

            public static bool operator !=(ComponentAddress a, ComponentAddress b)
            {
                return !(a == b);
            }

            public bool HasData()
            {
                return this.ComponentIndex != 0 && !object.ReferenceEquals(this.ComponentType.Type, null);
            }
        }

        public enum AddressType
        {
            Unknown,
            Asset,
            PrefabGameObject,
            PrefabComponent,
            SceneGameObject,
            SceneComponent,
        }
    }
}
#endif