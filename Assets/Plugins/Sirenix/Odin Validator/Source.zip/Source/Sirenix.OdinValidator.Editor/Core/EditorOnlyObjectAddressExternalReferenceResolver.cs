//-----------------------------------------------------------------------
// <copyright file="EditorOnlyObjectAddressExternalReferenceResolver.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector;
    using Sirenix.OdinInspector.Editor;
    using Sirenix.Serialization;
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;

    public class EditorOnlyObjectAddressExternalReferenceResolver : IExternalStringReferenceResolver
    {
        public static readonly EditorOnlyObjectAddressExternalReferenceResolver Instance = new EditorOnlyObjectAddressExternalReferenceResolver();

        public IExternalStringReferenceResolver NextResolver
        {
            get
            {
                return null;
            }

            set
            {
            }
        }

        public bool CanReference(object value, out string id)
        {
            var unityObj = value as UnityEngine.Object;

            if (object.ReferenceEquals(null, unityObj))
            {
                id = null;
                return false;
            }

            if (unityObj == null)
            {
                id = "NULL";
                return true;
            }

            if (!AssetDatabase.Contains(unityObj))
            {
                id = "NON-ASSET";
                return true;
            }

            ObjectAddress address;
            string error;

            if (!ObjectAddress.TryCreateObjectAddress(unityObj, out address, out error))
            {
                Debug.LogWarning("Could not create object address for AssetDatabase object, error was: " + error);
                id = "INVALID";
                return true;
            }

            id = address.ToString(false);
            return true;
        }

        public bool TryResolveReference(string id, out object value)
        {
            //Debug.Log("Parsing address: " + id);
            var address = ObjectAddress.Parse(id);

            if (address.IsBroken || address.Type == ObjectAddress.AddressType.Unknown)
            {
                value = null;
                return true;
            }

            UnityEngine.Object result;
            string error;

            if (!address.TryGetObjectReference(false, false, out result, out error))
            {
                Debug.LogWarning("Failed to resolve editor-time object address '" + id + "' during deserialization with error: " + error);
                value = null;
                return true;
            }

            value = result;
            return true;
        }
    }
}
#endif