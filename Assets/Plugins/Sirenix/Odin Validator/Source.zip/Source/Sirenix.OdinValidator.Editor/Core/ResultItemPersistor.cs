//-----------------------------------------------------------------------
// <copyright file="ResultItemPersistor.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor;
    using Sirenix.OdinInspector.Editor.Internal;
    using Sirenix.OdinInspector.Editor.Validation;
    using Sirenix.Serialization;
    using Sirenix.Utilities;
    using System;
    using System.Collections.Generic;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using UnityEngine;

    public static class ResultItemPersistor
    {
        private static readonly FieldInfo Delegate_target_Field = 
            typeof(Delegate).GetField("m_target", Flags.InstanceAnyVisibility) ?? 
            typeof(Delegate).GetField("_target", Flags.InstanceAnyVisibility);

        private static PersistenceData.Entry[] internalResultBuffer = new PersistenceData.Entry[16];
        private static readonly HashSet<object> seenReferences_Cached = new HashSet<object>(ReferenceEqualityComparer<object>.Default);

        public static PersistentResultItem[] CreatePersistentResultItems(ValidationResult result)
        {
            var results = new PersistentResultItem[result.Count];
            CreatePersistentResultItems(result, ref results);
            return results;
        }

        public static PersistenceContext CreateContextFromValidator(IValidator validator)
        {
            if (validator == null) throw new ArgumentNullException("validator");

            var context = new PersistenceContext(); 
            context.Validator = validator;

            if (validator is Validator val)
            {
                context.Property = val.Property;
                context.ValueEntry = context.Property.ValueEntry;
                context.BaseValueEntry = context.Property.BaseValueEntry;
                context.Tree = context.Property.Tree;
                context.Root = context.Tree.WeakTargets[0];

                if (context.ValueEntry != null)
                {
                    context.Value = context.ValueEntry.WeakSmartValue;
                }
            }

            return context;
        }

        public static void CreatePersistentResultItems(ValidationResult result, ref PersistentResultItem[] results)
        {
            bool hasDataToPersist = false;

            if (results == null || results.Length < result.Count)
            {
                results = new PersistentResultItem[result.Count];
            }

            for (int i = 0; i < result.Count; i++)
            {
                ref var r = ref result[i];
                results[i] = new PersistentResultItem(r.Message, r.ResultType);

                if (r.MetaData != null || r.Fix != null)
                {
                    hasDataToPersist = true;
                }
            }

            if (!hasDataToPersist)
            {
                return;
            }

            if (result.Setup.Validator == null)
            {
                Debug.LogError("Result contains data to persist, but has no validator.");
                return;
            }

            // Things to replace
            var context = CreateContextFromValidator(result.Setup.Validator);

            for (int i = 0; i < result.Count; i++)
            {
                ref var r = ref result[i];
                int id = 0;
                int count = 0;

                if (r.MetaData != null)
                {
                    object obj = r.MetaData;
                    BuildPersistenceData(ref obj, ref id, ref internalResultBuffer, ref count, ref context, seenReferences_Cached);
                }

                if (r.Fix != null)
                {
                    object obj = r.Fix;
                    BuildPersistenceData(ref obj, ref id, ref internalResultBuffer, ref count, ref context, seenReferences_Cached);
                }

                ref var data = ref results[i].Data;
                data.MangledFix = r.Fix;
                data.MangledMetaData = r.MetaData;

                if (count > 0)
                {
                    data.RestoreEntries = new PersistenceData.Entry[count];

                    for (int j = 0; j < count; j++)
                    {
                        data.RestoreEntries[j] = internalResultBuffer[j];
                    }
                }
            }

            seenReferences_Cached.Clear();
        }

        public static ResultItem[] RebuildResultItems(PersistentResultItem[] items, ref PersistenceContext context, bool openSceneIfNeeded)
        {
            var results = new ResultItem[items.Length];

            bool hasDataToRestore = false;

            for (int i = 0; i < items.Length; i++)
            {
                ref var r = ref items[i];
                ref var newResult = ref results[i];

                newResult = new ResultItem(r.Message, r.ResultType, null);

                if (r.Data.RestoreEntries != null)
                {
                    hasDataToRestore = true;
                }
                else
                {
                    newResult.Fix = r.Data.MangledFix == null ? null : FastDeepCopier.DeepCopy(r.Data.MangledFix);
                    newResult.MetaData = r.Data.MangledMetaData == null ? null : FastDeepCopier.DeepCopy(r.Data.MangledMetaData);
                }
            }

            if (!hasDataToRestore)
            {
                return results;
            }

            for (int i = 0; i < items.Length; i++)
            {
                ref var item = ref items[i];
                ref var result = ref results[i];

                if (item.Data.RestoreEntries == null) continue;

                int id = 0;
                int count = 0;
                int currentEntry = 0;

                if (item.Data.MangledMetaData != null)
                {
                    object obj = FastDeepCopier.DeepCopy(item.Data.MangledMetaData);
                    RebuildFromPersistenceData(ref obj, ref id, item.Data.RestoreEntries, ref currentEntry, ref count, ref context, openSceneIfNeeded, seenReferences_Cached);
                    result.MetaData = (ResultItemMetaData[])obj;
                }

                if (item.Data.MangledFix != null && currentEntry < item.Data.RestoreEntries.Length)
                {
                    object obj = FastDeepCopier.DeepCopy(item.Data.MangledFix);
                    RebuildFromPersistenceData(ref obj, ref id, item.Data.RestoreEntries, ref currentEntry, ref count, ref context, openSceneIfNeeded, seenReferences_Cached);
                    result.Fix = (Fix)obj;
                }
            }

            seenReferences_Cached.Clear();

            return results;
        }

        public struct PersistenceContext
        {
            public IValidator Validator;
            public InspectorProperty Property;
            public IPropertyValueEntry ValueEntry;
            public IPropertyValueEntry BaseValueEntry;
            public PropertyTree Tree;
            public object Root;
            public object Value;
        }

        private static void RebuildFromPersistenceData(ref object value, ref int id, PersistenceData.Entry[] entries, ref int currentEntry, ref int count, ref PersistenceContext context, bool openSceneIfNeeded, HashSet<object> seenReferences)
        {
            id++;

            if (currentEntry >= entries.Length) return;

            ref var entry = ref entries[currentEntry];

            if (!object.ReferenceEquals(value, null))
            {
                if (value.GetType().IsPrimitive) return;
            }

            if (id == entry.Id)
            {
                currentEntry++;

                switch (entry.Type)
                {
                    case PersistenceDataType.Validator:
                        if (context.Validator == null)
                        {
                            Debug.LogError("ValidationResult data contained reference to a Validator, but no Validator instance was provided in the rebuild context.");
                        }
                        value = context.Validator;
                        break;
                    case PersistenceDataType.InspectorProperty:
                        if (context.Property == null)
                        {
                            Debug.LogError("ValidationResult data contained reference to an InspectorProperty, but no InspectorProperty instance was provided in the rebuild context.");
                        }
                        value = context.Property;
                        break;
                    case PersistenceDataType.ValueEntry:
                        if (context.ValueEntry == null)
                        {
                            Debug.LogError("ValidationResult data contained reference to a ValueEntry, but no ValueEntry instance was provided in the rebuild context.");
                        }
                        value = context.ValueEntry;
                        break;
                    case PersistenceDataType.BaseValueEntry:
                        if (context.BaseValueEntry == null)
                        {
                            Debug.LogError("ValidationResult data contained reference to a BaseValueEntry, but no BaseValueEntry instance was provided in the rebuild context.");
                        }
                        value = context.BaseValueEntry; 
                        break;
                    case PersistenceDataType.PropertyTree:
                        if (context.Tree == null)
                        {
                            Debug.LogError("ValidationResult data contained reference to a PropertyTree, but no PropertyTree instance was provided in the rebuild context.");
                        }
                        value = context.Tree;
                        break;
                    case PersistenceDataType.Root:
                        if (context.Root == null)
                        {
                            Debug.LogError("ValidationResult data contained reference to the validation Root, but no Root instance was provided in the rebuild context.");
                        }
                        value = context.Root;
                        break;
                    case PersistenceDataType.Value:
                        if (context.Value == null)
                        {
                            Debug.LogError("ValidationResult data contained reference to the validation Value, but no Value instance was provided in the rebuild context.");
                        }
                        break;
                    case PersistenceDataType.UnityObjectReference:
                        // No need to go get the object instance again if it is still loaded
                        if (value is UnityEngine.Object obj && (obj == null || obj.GetInstanceID() != entry.UnityObjectReferenceAddress.LatestInstanceID))
                        {
                            if (entry.UnityObjectReferenceAddress.TryGetObjectReference(openSceneIfNeeded, false, out obj, out var error))
                            {
                                value = obj;
                            }
                            else
                            {
#if !SIRENIX_INTERNAL && !ODIN_BETA
#error provide error message somehow;
#endif
                                // Debug.LogError(
                                //     $"Failed to resolve ValidationResult data reference to Unity object address with " +
                                //     $"error '{error}'. The address was: {entry.UnityObjectReferenceAddress.LatestAddress?.ToString(true)}");
                            }
                        }
                        break;
                    default:
                        throw new NotImplementedException(entry.Type.ToString());
                }

                return;
            }

            if (value is ResultItemMetaData[] metaData)
            {
                if (seenReferences.Contains(value))
                {
                    return;
                }
                
                seenReferences.Add(value);

                for (int i = 0; i < metaData.Length; i++)
                {
                    RebuildFromPersistenceData(ref metaData[i].Value, ref id, entries, ref currentEntry, ref count, ref context, openSceneIfNeeded, seenReferences);
                    if (currentEntry >= entries.Length) return;
                }
            }
            else if (value is Array array)
            {
                if (seenReferences.Contains(value))
                {
                    return;
                }

                seenReferences.Add(value);

                var length = array.Length;

                for (int i = 0; i < length; i++)
                {
                    var element = array.GetValue(i);
                    RebuildFromPersistenceData(ref element, ref id, entries, ref currentEntry, ref count, ref context, openSceneIfNeeded, seenReferences);

#if !SIRENIX_INTERNAL && !ODIN_BETA
#error Do stronger type safety checking
#endif

                    array.SetValue(element, i);
                    if (currentEntry >= entries.Length) return;
                }
            }
            else if (value is Delegate del)
            {
                if (seenReferences.Contains(value))
                {
                    return;
                }

                seenReferences.Add(value);

                var target = del.Target;
                RebuildFromPersistenceData(ref target, ref id, entries, ref currentEntry, ref count, ref context, openSceneIfNeeded, seenReferences);

#if !SIRENIX_INTERNAL && !ODIN_BETA
#error Do stronger type safety checking
#endif

                if (!object.ReferenceEquals(target, del.Target))
                {
                    Delegate_target_Field.SetValue(del, target);
                }
            }
            else if (object.ReferenceEquals(value, null) || value is MemberInfo || value is Assembly || value is Module || value is string)
            {
                // Do nothing
            }
            else
            {
                if (seenReferences.Contains(value))
                {
                    return;
                }

                seenReferences.Add(value);

                var type = value.GetType();
                var fields = FormatterUtilities.GetSerializableMembers(value.GetType(), SerializationPolicies.Everything);

                for (int i = 0; i < fields.Length; i++)
                {
                    var field = fields[i] as FieldInfo;

                    if (field == null)
                    {
                        throw new Exception("SerializationPolicies.Everything is serializing a non-field member '" + fields[i].Name + "' on type '" + type.GetNiceName() + "'");
                    }

                    var fieldValue = field.GetValue(value);
                    RebuildFromPersistenceData(ref fieldValue, ref id, entries, ref currentEntry, ref count, ref context, openSceneIfNeeded, seenReferences);

                    if (fieldValue == null && field.FieldType.IsValueType)
                    {
                        Debug.LogError($"Data restore mismatch, cannot assign null to a value type field {field.Name} of type {field.FieldType.GetNiceName()}");
                        continue;
                    }
                    else if (fieldValue != null && !field.FieldType.IsAssignableFrom(fieldValue.GetType()))
                    {
                        Debug.LogError($"Data restore mismatch, cannot assign type {fieldValue.GetType()} to a value type field {field.Name} of type {field.FieldType.GetNiceName()}");
                        continue;
                    }

                    field.SetValue(value, fieldValue);
                    if (currentEntry >= entries.Length) return;
                }
            }
        }

        private static void BuildPersistenceData(ref object value, ref int id, ref PersistenceData.Entry[] buffer, ref int count, ref PersistenceContext context, HashSet<object> seenReferences)
        {
            id++;

            if (object.ReferenceEquals(value, null) || value.GetType().IsPrimitive) return;

            if (value is ResultItemMetaData[] metaData)
            {
                if (seenReferences.Contains(value))
                {
                    return;
                }

                seenReferences.Add(value);

                for (int i = 0; i < metaData.Length; i++)
                {
                    BuildPersistenceData(ref metaData[i].Value, ref id, ref buffer, ref count, ref context, seenReferences);
                }
            }
            else if (value is Array array)
            {
                if (seenReferences.Contains(value))
                {
                    return;
                }

                seenReferences.Add(value);

                var length = array.Length;

                for (int i = 0; i < length; i++)
                {
                    var element = array.GetValue(i);
                    BuildPersistenceData(ref element, ref id, ref buffer, ref count, ref context, seenReferences);
                    array.SetValue(element, i);
                }
            }
            else if (value is Delegate del)
            {
                if (seenReferences.Contains(value))
                {
                    return;
                }

                seenReferences.Add(value);

                var target = del.Target;
                BuildPersistenceData(ref target, ref id, ref buffer, ref count, ref context, seenReferences);
                if (!object.ReferenceEquals(target, del.Target))
                {
                    Delegate_target_Field.SetValue(del, target);
                }
            }
            else if (value is MemberInfo || value is Assembly || value is Module || value is string)
            {
                // Do nothing
            }
            else
            {
                if (value is IValidator validator)
                {
                    if (!object.ReferenceEquals(value, context.Validator))
                    {
                        Debug.LogError($"Validator '{context.Validator.GetType().GetNiceName()}'s result data contained invalid reference to a validator; only references to the originating validator '{context.Validator.GetType().GetNiceName()}' are allowed, but got a reference to validator {validator.GetType().GetNiceName()}.");
                    }
                    else
                    {
                        ExpandBufferIfNeeded(ref buffer, count);

                        buffer[count++] = new PersistenceData.Entry()
                        {
                            Id = id,
                            Type = PersistenceDataType.Validator
                        };
                    }

                    value = null;
                }
                else if (value is InspectorProperty property)
                {
                    if (!object.ReferenceEquals(value, context.Property))
                    {
                        Debug.LogError($"Validator '{context.Validator.GetType().GetNiceName()}'s result data contained invalid reference to an InspectorProperty; only references to the validator's own InspectorProperty '{context.Property?.GetType().GetNiceName() ?? "null"}' are allowed.");
                    }
                    else
                    {
                        ExpandBufferIfNeeded(ref buffer, count);

                        buffer[count++] = new PersistenceData.Entry()
                        {
                            Id = id,
                            Type = PersistenceDataType.InspectorProperty
                        };
                    }

                    value = null;
                }
                else if (value is IPropertyValueEntry entry)
                {
                    if (object.ReferenceEquals(value, context.ValueEntry))
                    {
                        ExpandBufferIfNeeded(ref buffer, count);

                        buffer[count++] = new PersistenceData.Entry()
                        {
                            Id = id,
                            Type = PersistenceDataType.ValueEntry
                        };
                    }
                    else if (object.ReferenceEquals(value, context.BaseValueEntry))
                    {
                        ExpandBufferIfNeeded(ref buffer, count);

                        buffer[count++] = new PersistenceData.Entry()
                        {
                            Id = id,
                            Type = PersistenceDataType.BaseValueEntry
                        };
                    }
                    else
                    {
                        Debug.LogError($"Validator '{context.Validator.GetType().GetNiceName()}'s result data contained invalid reference to a ValueEntry; only references to the validator's InspectorProperty's ValueEntry and BaseValueEntry are allowed.");
                    }

                    value = null;
                }
                else if (value is PropertyTree tree)
                {
                    if (!object.ReferenceEquals(value, context.Tree))
                    {
                        Debug.LogError($"Validator '{context.Validator.GetType().GetNiceName()}'s result data contained invalid reference to a PropertyTree; only references to the validator's own InspectorProperty's PropertyTree '{context.Property?.GetType().GetNiceName() ?? "null"}' are allowed.");
                    }
                    else
                    {
                        ExpandBufferIfNeeded(ref buffer, count);

                        buffer[count++] = new PersistenceData.Entry()
                        {
                            Id = id,
                            Type = PersistenceDataType.PropertyTree
                        };
                    }

                    value = null;
                }
                else if (object.ReferenceEquals(value, context.Root))
                {
                    ExpandBufferIfNeeded(ref buffer, count);

                    buffer[count++] = new PersistenceData.Entry()
                    {
                        Id = id,
                        Type = PersistenceDataType.Root
                    };

                    value = null;
                }
                else if (object.ReferenceEquals(value, context.Value))
                {
                    ExpandBufferIfNeeded(ref buffer, count);

                    buffer[count++] = new PersistenceData.Entry()
                    {
                        Id = id,
                        Type = PersistenceDataType.Value
                    };

                    value = null;
                }
                else if (value is UnityEngine.Object obj)
                {
                    if (obj != null)
                    {
                        if (ObjectAddress.TryCreateObjectAddress(obj, out var address, out var error))
                        {
                            var dynamicAddress = DynamicObjectAddress.GetOrCreate(obj, address);

                            ExpandBufferIfNeeded(ref buffer, count);

                            buffer[count++] = new PersistenceData.Entry()
                            {
                                Id = id,
                                Type = PersistenceDataType.UnityObjectReference,
                                UnityObjectReferenceAddress = dynamicAddress
                            };
                        }
                        else
                        {
                            Debug.LogError($"Validator '{context.Validator.GetType().GetNiceName()}'s result data contained invalid reference to a UnityEngine.Object instance which could not be converted into an ObjectAddress; the conversion failed with the following error: " + error);
                        }
                    }
                }
                else
                {
                    if (seenReferences.Contains(value))
                    {
                        return;
                    }

                    seenReferences.Add(value);

                    var type = value.GetType();
                    var fields = FormatterUtilities.GetSerializableMembers(value.GetType(), SerializationPolicies.Everything);

                    for (int i = 0; i < fields.Length; i++)
                    {
                        var field = fields[i] as FieldInfo;

                        if (field == null)
                        {
                            throw new Exception("SerializationPolicies.Everything is serializing a non-field member '" + fields[i].Name + "' on type '" + type.GetNiceName() + "'");
                        }

                        var fieldValue = field.GetValue(value);
                        BuildPersistenceData(ref fieldValue, ref id, ref buffer, ref count, ref context, seenReferences);
                        field.SetValue(value, fieldValue);
                    }
                }
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static void ExpandBufferIfNeeded(ref PersistenceData.Entry[] buffer, int count)
        {
            if (count == buffer.Length)
            {
                var newBuffer = new PersistenceData.Entry[buffer.Length * 2];
                Array.Copy(newBuffer, 0, buffer, 0, count);
                buffer = newBuffer;
            }
        }
    }
}
#endif