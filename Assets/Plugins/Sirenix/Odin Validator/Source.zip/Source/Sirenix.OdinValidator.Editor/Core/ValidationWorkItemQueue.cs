//-----------------------------------------------------------------------
// <copyright file="ValidationSession.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor.Validation;
    using System;
    using System.Collections.Generic;
    using Debug = UnityEngine.Debug;

    public class ValidationWorkItemQueue
    {
        private ulong[] entrySpace = new ulong[1];
        private ValidationWorkItemEntry[] entries = new ValidationWorkItemEntry[64];
        private Dictionary<ValidationWorkItem, ItemRef> keyToItem = new Dictionary<ValidationWorkItem, ItemRef>(new ValidationWorkItem.Comparer());
        private HashSet<SceneReference> queuedSceneReferences = new HashSet<SceneReference>();
        private CircularBufferQueue itemQueue = new CircularBufferQueue(256);

        private int available = 64;
        private int count;

        public uint TotalResultsEstimate;

        private struct CircularBufferQueue
        {
            public int Count;
            public int CurrentIndex;
            public ItemRef[] Items;

            public CircularBufferQueue(int capacity)
            {
                this.Count = 0;
                this.CurrentIndex = 0;
                this.Items = new ItemRef[capacity];
            }

            public void Clear()
            {
                this.Count = 0;
                this.CurrentIndex = 0;
            }

            public ItemRef Peek()
            {
                if (this.Count == 0) throw new InvalidOperationException("Can't peek when there are no items.");
                return this.Items[this.CurrentIndex];
            }

            public ItemRef Dequeue()
            {
                if (this.Count == 0) throw new InvalidOperationException("Can't dequeue when there are no items.");

                var index = this.CurrentIndex;
                if (++this.CurrentIndex >= this.Items.Length)
                {
                    this.CurrentIndex = 0;
                }
                this.Count--;
                return this.Items[index];
            }

            public void InsertFirst(ItemRef itemRef)
            {
                // Resize if necessary
                this.EnsureSpaceForOneMoreItem();

                this.Count++;

                if (this.CurrentIndex == 0)
                {
                    this.CurrentIndex = this.Items.Length - 1;
                }
                else
                {
                    this.CurrentIndex--;
                }

                this.Items[this.CurrentIndex] = itemRef;
            }

            public void Enqueue(ItemRef itemRef)
            {
                // Resize if necessary
                this.EnsureSpaceForOneMoreItem();
                var current = (this.CurrentIndex + this.Count++) % this.Items.Length;
                this.Items[current] = itemRef;
            }

            private void EnsureSpaceForOneMoreItem()
            {
                if (this.Count + 1 == this.Items.Length)
                {
                    if (this.CurrentIndex == 0)
                    {
                        Array.Resize(ref this.Items, this.Items.Length * 2);
                    }
                    else
                    {
                        var newItems = new ItemRef[this.Items.Length * 2];
                        int newI = 0;

                        for (int i = this.CurrentIndex; i < this.Items.Length; i++)
                        {
                            newItems[newI++] = this.Items[i];
                        }

                        for (int i = 0; i < this.CurrentIndex; i++)
                        {
                            newItems[newI++] = this.Items[i];
                        }

                        this.CurrentIndex = 0;
                        this.Items = newItems;
                    }
                }
            }
        }

        public int Count { get { return this.count; } }

        public bool Contains(ValidationWorkItem key)
        {
            return this.keyToItem.ContainsKey(key);
        }

        public ICollection<SceneReference> AllQueuedSceneReferences => this.queuedSceneReferences;

        public bool Remove(ValidationWorkItem key)
        {
            ItemRef itemRef;

            if (this.keyToItem.TryGetValue(key, out itemRef))
            {
                var entry = this.entries[itemRef.Index];

                this.entrySpace[itemRef.Index >> 6] &= ~(1ul << (itemRef.Index & 63));
                this.count--;
                this.keyToItem.Remove(entry.Item);
                this.TotalResultsEstimate -= entry.Item.ResultCountEstimate;

                if (key.SceneContent.HasValue)
                {
                    var removed = this.queuedSceneReferences.Remove(entry.Item.SceneContent.Value);
                    Debug.Assert(removed, "Scene work item should have been removed!");
                }

                // We cannot remove from the queue here, because it is too slow
                // Instead the queue checks against the slot being empty, and the
                // version of the ref matches the entry.

                // Next time this emptied slot is filled, the version is incremented,
                // so the queue will know it is no longer a valid ref.

                return true;

            }
            return false;
        }

        public void Clear()
        {
            var space = this.entrySpace;
            var entries = this.entries;

            for (int i = 0; i < space.Length; i++)
            {
                space[i] = 0;
            }

            var defaultEntry = default(ValidationWorkItemEntry);

            for (int i = 0; i < entries.Length; i++)
            {
                entries[i] = defaultEntry;
            }

            this.itemQueue.Clear();
            this.keyToItem.Clear();
            this.queuedSceneReferences.Clear();

            this.count = 0;
            this.TotalResultsEstimate = 0;
            this.available = this.entries.Length;
        }

        public ValidationWorkItem PeekMaybeInvalid()
        {
            if (this.count == 0) throw new InvalidOperationException("Queue is empty.");
            var itemRef = this.itemQueue.Peek();
            var entry = this.entries[itemRef.Index];
            return entry.Item;
        }

        public ValidationWorkItem Dequeue()
        {
            if (this.count == 0) throw new InvalidOperationException("Queue is empty.");

            while (this.itemQueue.Count > 0)
            {
                var itemRef = this.itemQueue.Dequeue();

                var entry = this.entries[itemRef.Index];

                if (entry.Version == itemRef.Version && (this.entrySpace[(itemRef.Index >> 6)] & (1ul << (itemRef.Index & 63))) != 0ul)
                {
                    this.entrySpace[itemRef.Index >> 6] &= ~(1ul << (itemRef.Index & 63));
                    this.count--;
                    this.available++;
                    this.keyToItem.Remove(entry.Item);

                    if (entry.Item.SceneContent.HasValue)
                    {
                        this.queuedSceneReferences.Remove(entry.Item.SceneContent.Value);
                    }

                    this.TotalResultsEstimate -= entry.Item.ResultCountEstimate;
                    //UnityEngine.Debug.Log("Dequeue: " + entry.Item.Guid + " - " + count + " left");

                    return entry.Item;
                }
            }

            throw new InvalidOperationException("Count said there were valid work items to dequeue, but there weren't.");
        }

        public bool Enqueue(ValidationWorkItem item)
        {
            return this.Add(item, false);
        }

        public bool InsertFirst(ValidationWorkItem item)
        {
            return this.Add(item, true);
        }

        private bool Add(ValidationWorkItem item, bool insertFirst)
        {
#if SIRENIX_INTERNAL
            if (item.SceneContent.HasValue && string.IsNullOrEmpty(item.SceneContent.Value.Name))
            {
                throw new Exception("Bad scene!");
            }
#endif

            ValidationWorkItemEntry entry;
            ItemRef itemRef;

            if (this.keyToItem.TryGetValue(item, out itemRef))
            {
                if (insertFirst)
                {
                    this.Remove(item);
                    this.Add(item, insertFirst);
                    return false;
                }
                else
                {
                    this.entries[itemRef.Index].Item = item;
                    return false;
                }
            }

            this.TotalResultsEstimate += item.ResultCountEstimate;

            if (this.available == 0)
            {
                entry = new ValidationWorkItemEntry();
                entry.Item = item;
                itemRef.Index = this.entries.Length;
                var entrySpaceIndex = this.entrySpace.Length;
                this.available = this.entries.Length - 1;
                Array.Resize(ref this.entries, this.entries.Length * 2);
                Array.Resize(ref this.entrySpace, this.entries.Length / 64);
                this.entries[itemRef.Index] = entry;
                this.entrySpace[entrySpaceIndex] = 1;
                if (insertFirst)
                {
                    this.itemQueue.InsertFirst(itemRef);
                }
                else
                {
                    this.itemQueue.Enqueue(itemRef);
                }

                this.keyToItem.Add(item, itemRef);
                if (item.SceneContent.HasValue)
                {
                    this.queuedSceneReferences.Add(item.SceneContent.Value);
                }
                this.count++;
                //UnityEngine.Debug.Log(item.Guid + " added at index " + itemRef.Index + " and buckets expanded to " + this.entries.Length + ", count = " + count);
                return true;
            }
            else
            {
                // Find available item slot
                var space = this.entrySpace;

                for (int i = 0; i < space.Length; i++)
                {
                    var bits = space[i];

                    if (bits != ~0ul)
                    {
                        // Evil bit math to get index of available space
                        var availableIndex = MultiplyDeBruijnBitPosition[((~bits & (bits + 1)) * DeBruijnSequence) >> 58];

                        // Set item and increment version
                        itemRef.Index = i * 64 + availableIndex;
                        itemRef.Version = ++this.entries[itemRef.Index].Version;
                        this.entries[itemRef.Index].Item = item;

                        // Add item refs to collections
                        if (insertFirst)
                        {
                            this.itemQueue.InsertFirst(itemRef);
                        }
                        else
                        {
                            this.itemQueue.Enqueue(itemRef);
                        }

                        this.keyToItem.Add(item, itemRef);
                        if (item.SceneContent.HasValue)
                        {
                            this.queuedSceneReferences.Add(item.SceneContent.Value);
                        }

                        // Mark slot as filled
                        space[i] |= 1ul << availableIndex;
                        this.available--;
                        this.count++;
                        //UnityEngine.Debug.Log(item.Guid + " added at index " + itemRef.Index + ", count = " + count);
                        return true;
                    }
                }

                throw new Exception("Queue bucket was supposed to have available space but no space was marked available.");
            }
        }

        private struct ItemRef
        {
            public int Version;
            public int Index;
        }

        private struct ValidationWorkItemEntry
        {
            public int Version;
            public ValidationWorkItem Item;
        }

        private const ulong DeBruijnSequence = 0x37E84A99DAE458F;

        private static readonly int[] MultiplyDeBruijnBitPosition =
        {
                0, 1, 17, 2, 18, 50, 3, 57,
                47, 19, 22, 51, 29, 4, 33, 58,
                15, 48, 20, 27, 25, 23, 52, 41,
                54, 30, 38, 5, 43, 34, 59, 8,
                63, 16, 49, 56, 46, 21, 28, 32,
                14, 26, 24, 40, 53, 37, 42, 7,
                62, 55, 45, 31, 13, 39, 36, 6,
                61, 44, 12, 35, 60, 11, 10, 9,
            };
    }
}
#endif