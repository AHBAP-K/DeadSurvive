//-----------------------------------------------------------------------
// <copyright file="ConfigSourceType.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.Utilities;
    using System;

    [Flags]
    public enum ConfigSourceType
    {
        None = 0,
        Default = 1 << 0,
        Project = 1 << 1,
        Local = 1 << 2,
        All = Default | Project | Local
    }
}
#endif