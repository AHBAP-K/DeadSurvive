//-----------------------------------------------------------------------
// <copyright file="RegisterValidationRuleAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor.Validation
{
    using Sirenix.OdinValidator.Editor;
    using Sirenix.Serialization.Utilities;
    using Sirenix.Utilities;
    using System;

    public class RegisterValidationRuleAttribute : RegisterValidatorAttribute
    {
        public string Name;
        public string Description;
        public bool EnabledByDefault;

        public RegisterValidationRuleAttribute(Type validatorType, string name = null, string description = null, bool enabledByDefault = true)
            : base(validatorType, typeof(RuleConfig))
        {
            if (name == null)
            {
                this.Name = validatorType.GetNiceName();

                if (this.Name.FastEndsWith("Validator"))
                    this.Name = this.Name.Substring(0, this.Name.Length - "Validator".Length).Trim();

                this.Name = UnityEditor.ObjectNames.NicifyVariableName(this.Name);
            }
            else
            {
                this.Name = name;
            }

            this.Description = description;
            this.EnabledByDefault = enabledByDefault;
        }
    }
}
#endif