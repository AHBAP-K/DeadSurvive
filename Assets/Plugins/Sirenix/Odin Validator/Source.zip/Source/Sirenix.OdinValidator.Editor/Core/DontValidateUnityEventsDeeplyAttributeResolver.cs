//-----------------------------------------------------------------------
// <copyright file="DontValidateUnityEventsDeeplyAttributeResolver.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor;
    using System;

    public class DontValidateUnityEventsDeeplyAttributeResolver<T> : BaseMemberPropertyResolver<T>
        where T : UnityEngine.Events.UnityEventBase
    {
        public override bool CanResolveForPropertyFilter(InspectorProperty property)
        {
            // Only apply this resolver for trees that are not set up for drawing, IE, are validation only.
            // This way we don't break fx custom drawers for UnityEvent that people have made.
            return !property.Tree.TreeIsSetupForIMGUIDrawing_TEMP_INTERNAL;
        }

        protected override InspectorPropertyInfo[] GetPropertyInfos()
        {
            return Array.Empty<InspectorPropertyInfo>();
        }
    }
}
#endif