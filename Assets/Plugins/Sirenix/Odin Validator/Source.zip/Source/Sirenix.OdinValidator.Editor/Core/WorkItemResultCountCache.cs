//-----------------------------------------------------------------------
// <copyright file="WorkItemResultCountCache.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor;
    using Sirenix.Utilities;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Threading;

    [UnityEditor.InitializeOnLoad]
    public static class WorkItemResultCountCache
    {
        private static readonly object lookup_LOCK = new object();
        private static bool isDirty = false;
        private static Dictionary<Guid, uint> lookup;
        private static Thread loadingThread;
        private static readonly string cacheFilePath;
        private static EditorPrefString lastCleanedDateTimePref_backing;
        private static BackgroundTaskHandle backgroundCleaningTask;

        private static EditorPrefString LastCleanedDateTimePref
        {
            get
            {
                if (lastCleanedDateTimePref_backing == null)
                {
                    lastCleanedDateTimePref_backing = new EditorPrefString("OdinValidator_WorkItemResultCountCache_LastCleanedDateTime", GetDateTimeNowAsBinaryString());
                }

                return lastCleanedDateTimePref_backing;
            }
        }

        private static DateTime GetLastCleanedDateTime()
        {
            var binaryString = LastCleanedDateTimePref.Value;

            if (long.TryParse(binaryString, out long binary))
            {
                return DateTime.FromBinary(binary);

            }

            return DateTime.MinValue;
        }

        private static string GetDateTimeNowAsBinaryString()
        {
            var now = DateTime.Now.ToBinary();
            return now.ToString("D", CultureInfo.InvariantCulture);
        }

        static WorkItemResultCountCache()
        {
            cacheFilePath = UnityEngine.Application.persistentDataPath.TrimEnd('/', '\\') + "/Odin Validator/WorkItemResultCountCache.data";

            loadingThread = new Thread(LoadCacheThread);

            loadingThread.Name = "WorkItemResultCountCache loader";
            loadingThread.IsBackground = true;
            loadingThread.Priority = ThreadPriority.BelowNormal;
            loadingThread.Start();

            UnityEditor.AssemblyReloadEvents.beforeAssemblyReload += OnReload;
        }

        private static void OnReload()
        {
            try
            {
                if (loadingThread != null)
                {
                    loadingThread.Abort();
                    loadingThread = null;
                }
            }
            catch (Exception) { }

            SaveCacheIfDirty();
        }

        public static unsafe void SaveCacheIfDirty()
        {
            EnsureLoaded();

            lock (lookup_LOCK)
            {
                if (isDirty)
                {
                    if (lookup != null)
                    {
                        var bytes = new byte[lookup.Count * 20];

                        fixed (byte* ptrBase = bytes)
                        {
                            ItemWorkEntryCount* ptr = (ItemWorkEntryCount*)ptrBase;

                            foreach (var item in lookup.GFIterator())
                            {
                                *ptr++ = new ItemWorkEntryCount(item.Key, item.Value);
                            }
                        }

                        var dir = Path.GetDirectoryName(cacheFilePath);
                        Directory.CreateDirectory(dir);
                        File.WriteAllBytes(cacheFilePath, bytes);
                    }

                    isDirty = false;
                }
            }
        }

        private static unsafe void LoadCacheThread()
        {
            try
            {
                if (!File.Exists(cacheFilePath))
                {
                    return;
                }

                var bytes = File.ReadAllBytes(cacheFilePath);

                if (bytes.Length % 20 != 0)
                {
                    UnityEngine.Debug.LogWarning($"WorkItemResultCountCache data file '{cacheFilePath}' was corrupted/had the wrong number of bytes '{bytes.Length}' on load (not divisible by 20). Cache data will be reset.");
                    File.Delete(cacheFilePath);
                    return;
                }

                int count = bytes.Length / 20;
                var tempLookup = new Dictionary<Guid, uint>();

                fixed (byte* ptrBase = bytes)
                {
                    ItemWorkEntryCount* ptr = (ItemWorkEntryCount*)ptrBase;

                    for (int i = 0; i < count; i++)
                    {
                        tempLookup.Add(ptr->Guid, ptr->Count);
                        ptr++;
                    }
                }

                lookup = tempLookup;
            }
            finally
            {
                loadingThread = null;

                var saveSometimesThread = new Thread(SaveCacheSometimesThread);

                saveSometimesThread.Name = "WorkItemResultCountCache background saver";
                saveSometimesThread.IsBackground = true;
                saveSometimesThread.Priority = ThreadPriority.Lowest;

                saveSometimesThread.Start();
            }
        }

        private static void SaveCacheSometimesThread()
        {
            while (true)
            {
                Thread.Sleep(30000);
                SaveCacheIfDirty();
            }
        }

        private static void EnsureLoaded()
        {
            try
            {
                if (loadingThread != null)
                {
                    loadingThread.Join();
                }
            }
            catch (NullReferenceException) { }
        }

        public static bool TryGetLastWorkItemResultCount(string guid, out uint count)
        {
            try
            {
                return TryGetLastWorkItemResultCount(new Guid(guid), out count);
            }
            catch (System.Exception ex)
            {
                UnityEngine.Debug.LogException(ex);
            }

            count = 0;
            return false;
        }

        public static bool TryGetLastWorkItemResultCount(Guid guid, out uint count)
        {
            EnsureLoaded();

            lock (lookup_LOCK)
            {
                count = 0;
                return lookup != null && lookup.TryGetValue(guid, out count);
            }
        }

        public static void RegisterWorkItemResultCount(string guid, uint count)
        {
            RegisterWorkItemResultCount(new Guid(guid), count);
        }

        public static void RegisterWorkItemResultCount(Guid guid, uint count)
        {
            EnsureLoaded();

            lock (lookup_LOCK)
            {
                if (lookup == null)
                {
                    lookup = new Dictionary<Guid, uint>();
                }

                if (!lookup.TryGetValue(guid, out var oldCount) || count != oldCount)
                {
                    lookup[guid] = count;
                    isDirty = true;
                }
            }

            if (backgroundCleaningTask == null && (DateTime.Now - GetLastCleanedDateTime()).TotalHours >= 24)
            {
                backgroundCleaningTask = BackgroundTaskRunner.StartTask("Cleaning WorkItemResultCountCache", BackgroundCleaningTask());
            }
        }

#if SIRENIX_INTERNAL
        [UnityEditor.MenuItem("Internal/WorkItemResultCountCache -> ForceStartBackgroundCleaningTask")]
#endif
        public static void ForceStartBackgroundCleaningTask()
        {
            if (backgroundCleaningTask != null)
            {
                backgroundCleaningTask.Kill();
            }

            backgroundCleaningTask = BackgroundTaskRunner.StartTask("Cleaning WorkItemResultCountCache", BackgroundCleaningTask());
        }

        private static IEnumerator BackgroundCleaningTask()
        {
            EnsureLoaded();
            if (lookup == null) yield break;

            Guid[] guidsToCheck;

            lock (lookup_LOCK)
            {
                guidsToCheck = lookup.Keys.ToArray();
            }

            for (int i = 0; i < guidsToCheck.Length; i++)
            {
                var guid = guidsToCheck[i];
                var guidStr = guid.ToString("N").ToLower();
                var assetPath = UnityEditor.AssetDatabase.GUIDToAssetPath(guidStr);

                if (string.IsNullOrEmpty(assetPath))
                {
                    lock (lookup_LOCK)
                    {
#if SIRENIX_INTERNAL
                        UnityEngine.Debug.Log("Removed " + guidStr + " from cache because it was no longer in the asset database");
#endif
                        lookup.Remove(guid);
                        isDirty = true;
                    }
                }

                yield return null;
            }

            LastCleanedDateTimePref.Value = GetDateTimeNowAsBinaryString();
            backgroundCleaningTask = null;
        }

        [StructLayout(LayoutKind.Explicit)]
        public unsafe struct ItemWorkEntryCount
        {
            [FieldOffset(0)]
            public Guid Guid;
            [FieldOffset(16)]
            public uint Count;

            public ItemWorkEntryCount(Guid guid, uint count)
            {
                this.Guid = guid;
                this.Count = count;
            }
        }
    }
}
#endif