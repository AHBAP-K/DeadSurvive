//-----------------------------------------------------------------------
// <copyright file="DynamicObjectAddress.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using System;
    using System.Collections.Generic;
    using UnityEditor;
    using UnityEngine;

    public class DynamicObjectAddress : ISerializationCallbackReceiver, IEquatable<DynamicObjectAddress>
    {
        private static object LOCK = new object();
        private static Dictionary<int, WeakReference<DynamicObjectAddress>> lookupByID = new Dictionary<int, WeakReference<DynamicObjectAddress>>();
        private static Dictionary<ObjectAddress, WeakReference<DynamicObjectAddress>> lookupByAddress = new Dictionary<ObjectAddress, WeakReference<DynamicObjectAddress>>();

        [NonSerialized]
        public static readonly DynamicObjectAddress Unknown = new DynamicObjectAddress()
        {
            address = ObjectAddress.Unknown,
        };

        [NonSerialized]
        private int instanceID;

        [NonSerialized]
        private ObjectAddress address;

        [NonSerialized]
        private UnityEngine.Object obj;

        [NonSerialized]
        private bool isBroken;

        public int LatestInstanceID => this.instanceID;
        public ObjectAddress LatestAddress => this.address;
        public bool IsBroken => this.isBroken;
        public bool IsUnloaded => this.obj == null && !this.IsBroken && this != Unknown;

        private DynamicObjectAddress()
        {
        }

        ~DynamicObjectAddress()
        {
            if (this == Unknown || this.isBroken) return;

            lock (LOCK)
            {
                DynamicObjectAddress current;
                WeakReference<DynamicObjectAddress> currentRef;

                if (lookupByID.TryGetValue(this.instanceID, out currentRef)
                    && currentRef.TryGetTarget(out current))
                {
                    // This address has been recreated before this destructor ran, and should not
                    // clean up after itself.
                    //Debug.Log("Address semi-resurrection event for " + this.address + "!");
                    return;
                }

                if (lookupByAddress.TryGetValue(this.address, out currentRef)
                    && currentRef.TryGetTarget(out current))
                {
                    // This address has been recreated before this destructor ran, and should not
                    // clean up after itself.
                    //Debug.Log("Address semi-resurrection event for " + this.address + "!");
                    return;
                }

                //Debug.Log("Address cleanup event for " + this.address + "!");
                lookupByID.Remove(this.instanceID);
                lookupByAddress.Remove(this.address);
            }
        }

        public void Refresh()
        {
            if (!IsUnloaded) return;

            UnityEngine.Object discard;
            string error;
            this.TryGetObjectReference(false, false, out discard, out error);
        }

        public static bool TryGet(int instanceID, out DynamicObjectAddress address)
        {
            lock (LOCK)
            {
                address = null;
                WeakReference<DynamicObjectAddress> reference;
                return lookupByID.TryGetValue(instanceID, out reference) && reference.TryGetTarget(out address);
            }
        }

        public static bool TryGet(ObjectAddress objectAddress, out DynamicObjectAddress address)
        {
            lock (LOCK)
            {
                address = null;
                WeakReference<DynamicObjectAddress> reference;
                return lookupByAddress.TryGetValue(objectAddress, out reference) && reference.TryGetTarget(out address);
            }
        }

        public static DynamicObjectAddress CreateBroken(ObjectAddress address)
        {
            if (!address.IsBroken)
            {
                throw new ArgumentException("You must pass a broken ObjectAddress to this method.");
            }

            return new DynamicObjectAddress()
            {
                address = address,
                instanceID = -1,
                isBroken = true
            };
        }

        public static DynamicObjectAddress GetOrCreate(int instanceID, ObjectAddress address)
        {
            if (address.IsBroken)
            {
                throw new ArgumentException("You cannot pass a broken ObjectAddress to this method.");
            }

            var obj = EditorUtility.InstanceIDToObject(instanceID);

            if (obj == null)
            {
                throw new Exception("Given Instance ID is not currently alive and gettable via EditorUtility.InstanceIDToObject.");
            }

            return GetOrCreate(obj, address);
        }

        public static DynamicObjectAddress GetOrCreate(UnityEngine.Object obj, ObjectAddress address)
        {
            if (obj == null)
            {
                throw new Exception("Given object to create dynamic address for is not currently alive. An object needs to be alive to create a dynamic address for it, even if it is destroyed later.");
            }

            if (address.IsBroken)
            {
                throw new ArgumentException("You cannot pass a broken ObjectAddress to this method.");
            }

            var instanceID = obj.GetInstanceID();

            WeakReference<DynamicObjectAddress> reference;
            DynamicObjectAddress result;

            lock (LOCK)
            {
                if (lookupByID.TryGetValue(instanceID, out reference))
                {
                    if (!reference.TryGetTarget(out result))
                    {
                        lookupByID.Remove(instanceID);
                        lookupByAddress.Remove(address);
                        goto CREATE_NEW;
                    }
                    else
                    {
                        if (result.address != address)
                        {
                            lookupByAddress.Remove(result.address);
                            lookupByAddress[address] = reference;
                            result.address = address;
                        }

                        result.obj = obj;
                        return result;
                    }
                }

                if (lookupByAddress.TryGetValue(address, out reference))
                {
                    if (!reference.TryGetTarget(out result))
                    {
                        lookupByID.Remove(instanceID);
                        lookupByAddress.Remove(address);
                        goto CREATE_NEW;
                    }
                    else
                    {
                        if (result.instanceID != instanceID)
                        {
                            lookupByID.Remove(result.instanceID);
                            lookupByID[instanceID] = reference;
                            result.instanceID = instanceID;
                        }

                        result.obj = obj;
                        return result;
                    }
                }

            CREATE_NEW:

                result = new DynamicObjectAddress()
                {
                    obj = obj,
                    instanceID = instanceID,
                    address = address,
                };

                if (reference == null)
                {
                    reference = new WeakReference<DynamicObjectAddress>(result, false);
                }
                else
                {
                    reference.SetTarget(result);
                }

                lookupByID[instanceID] = reference;
                lookupByAddress[address] = reference;

                return result;
            }
        }

        public void OnAfterDeserialize()
        {
            throw new NotSupportedException("It is not allowed to serialize DynamicObjectAddress.");
        }

        public void OnBeforeSerialize()
        {
            throw new NotSupportedException("It is not allowed to serialize DynamicObjectAddress.");
        }

        public bool TryGetObjectReference(bool openSceneIfNeeded, bool autoSaveIfOpenScene, out UnityEngine.Object result, out string errorMessage, out UnityEngine.Object closestObject)
        {
            return this.TryGetObjectReference(openSceneIfNeeded, autoSaveIfOpenScene, out result, out errorMessage, out closestObject, true);
        }

        public bool TryGetObjectReference(bool openSceneIfNeeded, bool autoSaveIfOpenScene, out UnityEngine.Object result, out string errorMessage)
        {
            return this.TryGetObjectReference(openSceneIfNeeded, autoSaveIfOpenScene, out result, out errorMessage, out var _, false);
        }

        private bool TryGetObjectReference(bool openSceneIfNeeded, bool autoSaveIfOpenScene, out UnityEngine.Object result, out string errorMessage, out UnityEngine.Object closestObject, bool findClosest)
        {
            closestObject = null;

            if (this == Unknown || (this.isBroken && !findClosest))
            {
                result = null;
                errorMessage = null;
                return false;
            }

            errorMessage = null;

            lock (LOCK)
            {
                if (this.obj == null)
                {
                    this.obj = EditorUtility.InstanceIDToObject(this.instanceID);

                    if (this.obj == null)
                    {
                        if (findClosest)
                        {
                            this.address.TryGetObjectReference(openSceneIfNeeded, autoSaveIfOpenScene, out this.obj, out errorMessage, out closestObject);
                        }
                        else
                        {
                            this.address.TryGetObjectReference(openSceneIfNeeded, autoSaveIfOpenScene, out this.obj, out errorMessage);
                        }
                    }

                    if (this.obj != null)
                    {
                        var newId = this.obj.GetInstanceID();

                        if (newId != this.instanceID)
                        {
                            var oldID = this.instanceID;
                            this.instanceID = newId;
                            WeakReference<DynamicObjectAddress> reference;

                            if (lookupByID.TryGetValue(oldID, out reference))
                            {
                                lookupByID.Remove(oldID);
                                lookupByID[this.instanceID] = reference;
                            }
                            else if (!lookupByAddress.TryGetValue(this.address, out reference))
                            {
                                reference = new WeakReference<DynamicObjectAddress>(this, false);
                                lookupByID[this.instanceID] = reference;
                                lookupByAddress[this.address] = reference;
                            }
                            else
                            {
                                lookupByID[this.instanceID] = reference;
                            }
                        }
                    }
                }
            }

            if (findClosest && this.obj)
            {
                closestObject = this.obj;
            }

            result = this.obj;
            return this.obj != null;
        }

        public override bool Equals(object obj)
        {
            return obj is DynamicObjectAddress other && this == other;
        }

        public bool Equals(DynamicObjectAddress other)
        {
            return this == other;
        }

        public static bool operator ==(DynamicObjectAddress a, DynamicObjectAddress b)
        {
            if (object.ReferenceEquals(a, b)) return true;
            if (object.ReferenceEquals(a, null) != object.ReferenceEquals(b, null)) return false;

            lock (LOCK)
            {
                return a.IsBroken == b.IsBroken
                    && a.LatestInstanceID == b.LatestInstanceID
                    && a.LatestAddress == b.LatestAddress;
            }
        }

        public static bool operator !=(DynamicObjectAddress a, DynamicObjectAddress b)
        {
            return !(a == b);
        }

        public override int GetHashCode()
        {
            return this.LatestAddress?.GetHashCode() ?? 0;
        }
    }
}
#endif