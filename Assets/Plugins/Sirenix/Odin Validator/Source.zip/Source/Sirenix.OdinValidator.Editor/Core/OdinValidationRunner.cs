//-----------------------------------------------------------------------
// <copyright file="OdinValidationRunner.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector;
    using Sirenix.OdinInspector.Editor;
    using Sirenix.OdinInspector.Editor.Internal;
    using Sirenix.OdinInspector.Editor.Validation;
    using Sirenix.Utilities;
    using System;
    using System.Collections.Generic;
    using UnityEditor;
    using UnityEngine;


    public class OdinValidationPolicy
    {
        public static OdinValidationPolicy Default = new OdinValidationPolicy();
        private static HashSet<Type> typesDrawnByOdin;

        static OdinValidationPolicy()
        {
            typesDrawnByOdin = InspectorTypeDrawingConfigDrawer.GetAllTypesDrawnByOdin();
        }

        public virtual bool ShouldValidate(OdinValidationRunner runner, object value)
        {
            return true;
        }

        public virtual bool ShouldDeeplyValidate(OdinValidationRunner runner, object value)
        {
            var shouldValidate = true;
            var type = value.GetType();

            if (!runner.Config.DeepValidation)
            {
                shouldValidate = typesDrawnByOdin.Contains(type);

                if (!shouldValidate)
                {
                    // TODO: There are more cases where Odin might be drawing the value.
                    // What other ways could we detect those cases?
                    var editorType = InspectorConfig.Instance.DrawingConfig
                        .GetEditorType(type);

                    if (editorType != null)
                    {
                        shouldValidate = editorType.InheritsFrom(typeof(OdinEditor));
                    }
                }
            }

            return shouldValidate;
        }

        public virtual bool CustomValidatorFilter(OdinValidationRunner runner, Type type)
        {
            return true;
        }
    }

    public class ValidationRunnerConfig
    {
        public static ValidationRunnerConfig Default = new ValidationRunnerConfig()
        {
            DeepValidation = GlobalValidationConfig.DeepValidation
        };

        public bool DeepValidation;
    }

    public sealed class OdinValidationRunner : IDisposable
    {
        private static WeakReferenceEventListener<OdinValidationRunner> unloadEventListener;

        static OdinValidationRunner()
        {
            unloadEventListener = new WeakReferenceEventListener<OdinValidationRunner>((runner, args) =>
            {
                runner.OnUnload();
            });
            AssemblyReloadEvents.beforeAssemblyReload += () =>
            {
                unloadEventListener.InvokeEvent(null);
            };
        }

        public static readonly EditorPrefBool EnableLeakDetection = new EditorPrefBool("Odin_Validator_ValidationRunner_" + nameof(EnableLeakDetection), true);

        private bool isDisposed;
        private Dictionary<Type, PropertyTree> cachedPropertyTrees;
        private System.Diagnostics.StackTrace allocationTrace;

        public OdinValidationPolicy Policy;
        public ValidationRunnerConfig Config;

        public OdinValidationRunner(OdinValidationPolicy policy = null, ValidationRunnerConfig config = null)
        {
            this.Policy = policy ?? OdinValidationPolicy.Default;
            this.Config = config ?? ValidationRunnerConfig.Default;

            unloadEventListener.SubscribeListener(this);

            if (EnableLeakDetection)
            {
                this.allocationTrace = new System.Diagnostics.StackTrace();
            }
        }

        ~OdinValidationRunner()
        {
            if (!this.isDisposed)
            {
                this.Dispose(true);
            }
        }

        private void OnUnload()
        {
            if (!isDisposed)
            {
                this.Dispose(false);
            }
        }

        public void Dispose()
        {
            this.Dispose(false);
        }

        private void Dispose(bool isLeaking)
        {
            if (this.isDisposed)
            {
                // Trying multiple times is fine; sometimes it's hard not to, when the thing is already disposing itself at unload.
                return;
            }

            if (isLeaking)
            {
                if (this.allocationTrace != null)
                {

#if SIRENIX_INTERNAL
                    Debug.LogError(
#else
                    Debug.LogWarning(
#endif
                        "An Odin ValidationRunner instance is being garbage collected without first having been disposed. ValidationRunner instances must be disposed once they are no longer needed. This instance was allocated at the following location: \n\n" + this.allocationTrace.ToString());
                }

                UnityEditorEventUtility.DelayActionThreadSafe(this.ActuallyDispose);
            }
            else
            {
                this.ActuallyDispose();
            }
        }

        private void ActuallyDispose()
        {
            if (this.cachedPropertyTrees != null)
            {
                foreach (var tree in this.cachedPropertyTrees.Values)
                {
                    tree.Dispose();
                }

                this.cachedPropertyTrees = null;
            }

            this.isDisposed = true;

            unloadEventListener.DesubscribeListener(this);
        }

        public IEnumerable<PersistentValidationResult> ValidateAllAssetsAtPath(string path)
        {
#if ODIN_TRIAL
            if (ValidatorTrialUtility.IsReallyExpired)
            {
                yield return PersistentValidationResult.Ignore;
                yield break;
            }
#endif

            var assetsAtPath = this.LoadAllAssetsAtPathProperly(path);

            int i = 0;
            foreach (var loadInfo in assetsAtPath)
            {
                i++;
                var j = 0;
                var hadResults = false;

                foreach (var r in this.ValidateAsset(loadInfo))
                {
                    hadResults = true;
                    j++;
                    yield return r;
                }

                if (!hadResults)
                {
                    yield return PersistentValidationResult.Ignore;
                }
            }
        }

        private IEnumerable<LoadedAssetInfo> LoadAllAssetsAtPathProperly(string path)
        {
            var guid = AssetDatabase.AssetPathToGUID(path);
            IEnumerable<LoadedAssetInfo> result;

            if (path.FastEndsWith(".prefab"))
            {
                // It's a prefab; we need to get fancy with it, since AssetDatabase.LoadAllAssetsAtPath
                // often loads broken null values for prefabs instead of loading them properly
                var mainAsset = AssetDatabase.LoadMainAssetAtPath(path) as GameObject;

                if (mainAsset == null)
                {
                    var objectType = typeof(GameObject);
                    var niceObjectName = path.GetObjectNameFromAssetPath();

                    result = new LoadedAssetInfo[] {
                        new LoadedAssetInfo(LoadedAssetInfo.AssetType.BrokenAsset,
                        mainAsset,
                        path,
                        new ObjectAddress(
                            ObjectAddress.AddressType.PrefabGameObject,
                            guid,
                            path,
                            default(ObjectAddress.SubAssetAddress),
                            default(ObjectAddress.HierarchyAddress),
                            default(ObjectAddress.ComponentAddress),
                            niceObjectName,
                            objectType,
                            true),
                        true,
                        0)
                    };
                }
                else
                {
                    result = this.RecurseThroughPrefab(mainAsset, guid, path, -1, null, null, true);
                }
            }
            else if (path.FastEndsWith(".unity"))
            {
                // Unity gives an error if you call AssetDatabase.LoadAllAssetsAtPath(path) on a scene asset.
                // Does it though?

                var sceneAsset = AssetDatabase.LoadAssetAtPath<SceneAsset>(path);
                var isBroken = sceneAsset == null;
                var infoType = isBroken ? LoadedAssetInfo.AssetType.BrokenAsset : LoadedAssetInfo.AssetType.Normal;
                var niceObjectName = path.GetObjectNameFromAssetPath();
                var objectType = typeof(SceneAsset);

                var recoveryData = new ObjectAddress(
                    ObjectAddress.AddressType.Asset,
                    guid,
                    path,
                    default(ObjectAddress.SubAssetAddress),
                    default(ObjectAddress.HierarchyAddress),
                    default(ObjectAddress.ComponentAddress),
                    niceObjectName,
                    objectType,
                    isBroken);

                result = new LoadedAssetInfo[] { new LoadedAssetInfo(
                    infoType, sceneAsset, path, recoveryData, true, 0)
                };
            }
            else
            {
                // Not any of the special cases, we can just do it the normal way
                var assets = AssetDatabase.LoadAllAssetsAtPath(path);
                var mainAsset = AssetDatabase.LoadMainAssetAtPath(path);
                var resultArr = new LoadedAssetInfo[assets.Length];

                for (int i = 0; i < assets.Length; i++)
                {
                    bool isMainAsset;

                    if (mainAsset == null)
                        isMainAsset = i == 0;
                    else
                        isMainAsset = mainAsset == assets[i];

                    var isBroken = assets[i] == null;
                    var type = ObjectAddress.AddressType.Asset;
                    Type objectType;
                    string niceObjectName;
                    if (isBroken)
                    {
                        objectType = typeof(UnityEngine.Object);
                        niceObjectName = path.GetObjectNameFromAssetPath();

                        if (!isMainAsset)
                        {
                            niceObjectName += $" [{i}]";
                        }
                    }
                    else
                    {
                        objectType = assets[i].GetType();
                        niceObjectName = assets[i].name; // TODO: Could also display mainAsset name if is sub-asset.

                        if (!isMainAsset)
                        {
                            niceObjectName += $" [{i}]";
                        }
                    }

                    var obj = (object)assets[i];
                    Type objType = null;
                    int hashCode = 0;

                    if (obj != null)
                    {
                        objType = obj.GetType();
                        hashCode = assets[i].GetInstanceID();
                    }

                    var subAddress = isMainAsset ? default(ObjectAddress.SubAssetAddress) : new ObjectAddress.SubAssetAddress(objType, hashCode, i);
                    var objectAddress = new ObjectAddress(type, guid, path, subAddress, default(ObjectAddress.HierarchyAddress), default(ObjectAddress.ComponentAddress), niceObjectName, objectType, isBroken);
                    var infoType = isBroken ? LoadedAssetInfo.AssetType.BrokenAsset : LoadedAssetInfo.AssetType.Normal;

                    resultArr[i] = new LoadedAssetInfo(infoType, assets[i], path, objectAddress, isMainAsset, i);

                }

                result = resultArr;
            }

            return result;
        }

        private IEnumerable<LoadedAssetInfo> RecurseThroughPrefab(GameObject go, string guid, string path, int gameObjectIndex, string[] names, int[] indices, bool isMainAsset)
        {
            bool isBroken = go == null;
            ObjectAddress.AddressType type = ObjectAddress.AddressType.PrefabGameObject;
            ObjectAddress.HierarchyAddress hierarchyAddress = default(ObjectAddress.HierarchyAddress);

            if (!isBroken && !isMainAsset)
            {
                //Debug.Assert(gameObjectIndex == go.transform.GetSiblingIndex());
                hierarchyAddress = new ObjectAddress.HierarchyAddress(
                    ArrayUtilities.CreateNewArrayWithAddedElement(names ?? new string[0], go.name),
                    ArrayUtilities.CreateNewArrayWithAddedElement(indices ?? new int[0], gameObjectIndex)
                );
            }
            else if (isBroken)
            {
                hierarchyAddress = new ObjectAddress.HierarchyAddress(
                    ArrayUtilities.CreateNewArrayWithAddedElement(names ?? new string[0], "|BROKEN|"),
                    ArrayUtilities.CreateNewArrayWithAddedElement(indices ?? new int[0], gameObjectIndex)
                );
            }

            string niceObjectName;
            Type objectType;

            if (isBroken)
            {
                objectType = typeof(GameObject);
                niceObjectName = "";
            }
            else
            {
                objectType = typeof(GameObject);
                niceObjectName = go.name;
            }

            yield return new LoadedAssetInfo(isBroken ? LoadedAssetInfo.AssetType.BrokenAsset : LoadedAssetInfo.AssetType.Normal, go, path, new ObjectAddress(type, guid, path, default(ObjectAddress.SubAssetAddress), hierarchyAddress, default(ObjectAddress.ComponentAddress), niceObjectName, objectType, isBroken), isMainAsset, gameObjectIndex);

            if (go == null) yield break;

            if (!isBroken)
            {
                Component[] components = go.GetComponents(typeof(Component));

                var goName = go.name;

                for (int i = 0; i < components.Length; i++)
                {
                    var component = components[i];
                    var isCmpBroken = component == null;

                    Type cmpType;

                    if (isCmpBroken)
                        cmpType = typeof(Component);
                    else
                        cmpType = component.GetType();

                    var componentAddress = new ObjectAddress(
                        ObjectAddress.AddressType.PrefabComponent,
                        guid,
                        path,
                        default(ObjectAddress.SubAssetAddress),
                        hierarchyAddress,
                        new ObjectAddress.ComponentAddress(i, component?.GetType()),
                        goName,
                        cmpType,
                        isCmpBroken
                    );

                    componentAddress.IsBroken = component == null;

                    if (component != null)
                    {
                        yield return new LoadedAssetInfo(LoadedAssetInfo.AssetType.Normal, component, path, componentAddress, false, componentAddress.Component.ComponentIndex);
                    }
                    else
                    {
                        yield return new LoadedAssetInfo(go, component, i, path, componentAddress);
                    }

                    if (go == null) yield break;
                }

                var transform = go.transform;

                for (int i = 0; i < transform.childCount; i++)
                {
                    foreach (var childResult in this.RecurseThroughPrefab(
                        transform.GetChild(i).gameObject,
                        guid,
                        path,
                        i,
                        hierarchyAddress.SubNames,
                        hierarchyAddress.SubIndices,
                        false))
                    {
                        yield return childResult;
                        if (go == null) yield break;
                    }
                }
            }
        }

        public class AssetUnloadedWhileValidatingException : Exception
        {
            public AssetUnloadedWhileValidatingException(string message) : base(message)
            {

            }
        }

        private IEnumerable<PersistentValidationResult> ValidateAsset(LoadedAssetInfo loadInfo)
        {
            if (loadInfo.Type == LoadedAssetInfo.AssetType.Normal)
            {
                if (loadInfo.Asset == null)
                {
                    // TODO: Trigger this case and provide good user feedback.-
                    //Debug.LogError("Asset at path '" + loadInfo.AssetPath + "' was unloaded during validation.");
                    return Array.Empty<PersistentValidationResult>();
                }
                else
                {
                    return this.ValidateObject(loadInfo.Asset);
                }
            }
            else if (loadInfo.Type == LoadedAssetInfo.AssetType.BrokenAsset)
            {
                //ValidationAction[] actions;
                string message;

                if (loadInfo.AssetPath.EndsWith(".prefab"))
                {
                    message = $"Broken Prefab: a prefab at path '{loadInfo.AssetPath}' was null when loaded.";
                    //actions = new ValidationAction[]
                    //{
                    //    CommonFixes.ReimportAssetFix,
                    //};
                }
                else
                {
                    var path = loadInfo.AssetPath;

                    if (!loadInfo.IsMainAsset)
                    {
                        path += $" [{loadInfo.SubAssetIndex}]";
                    }

                    message = object.ReferenceEquals(loadInfo.Asset, null) ?
                            $"Broken Asset: {(loadInfo.IsMainAsset ? "an asset" : "a subasset")} of unknown type at path '{path}' was null when loaded." :
                            $"Broken Asset: {(loadInfo.IsMainAsset ? "an asset" : "a subasset")} of type '{loadInfo.Asset.GetType()}' at path '{path}' was null when loaded.";
                    //actions = new ValidationAction[]
                    //{
                    //    CommonFixes.ReimportAssetFix,
                    //};
                }



                if (!loadInfo.IsMainAsset)
                {
#if !SIRENIX_INTERNAL && !ODIN_BETA
#error Find a better solution for broken sub asset validation and fixing
#endif
                    return Array.Empty<PersistentValidationResult>();
                }
                else
                {
                    var result = new PersistentValidationResult(loadInfo.AssetPath, message, null, 0, ValidationResultType.Error, DynamicObjectAddress.CreateBroken(loadInfo.Address));
                    //result[0].ValidationActions = actions;

                    return new PersistentValidationResult[]
                    {
                        result
                    };
                }
            }
            else if (loadInfo.Type == LoadedAssetInfo.AssetType.BrokenComponent)
            {
                if (loadInfo.OwningGO == null)
                {
                    return Array.Empty<PersistentValidationResult>();
                }

                var message = object.ReferenceEquals(loadInfo.BrokenComponent, null) ?
                            "Broken Component: a component at index '" + loadInfo.ComponentIndex + "' is null on the GameObject '" + loadInfo.OwningGO.name + "'! A script reference is likely broken." :
                            "Broken Component: a component of type '" + loadInfo.BrokenComponent.GetType().GetNiceName() + "' at index '" + loadInfo.ComponentIndex + "' is null on the GameObject '" + loadInfo.OwningGO.name + "'! A script reference is likely broken.";

                return new PersistentValidationResult[]
                {
                    new PersistentValidationResult(loadInfo.AssetPath, message, null, 0, ValidationResultType.Error, DynamicObjectAddress.CreateBroken(loadInfo.Address))
                };
            }
            else
            {
                throw new NotImplementedException(loadInfo.Type.ToString());
            }
        }

        public IEnumerable<PersistentValidationResult> ValidateSceneValidators(SceneReference scene)
        {
            if (!scene.IsValid) throw new Exception("Scene not valid: " + scene);
            if (!scene.IsLoaded) throw new Exception("Scene not loaded: " + scene);

#if ODIN_TRIAL
            if (ValidatorTrialUtility.IsReallyExpired)
            {
                yield return PersistentValidationResult.Ignore;
                yield break;
            }
#endif

            var validators = DefaultValidatorLocator.Instance.GetSceneValidators(scene);

            foreach (var validator in validators)
            {
                var result = new ValidationResult();
                validator.RunValidation(ref result);
                if (result.ResultType == ValidationResultType.IgnoreResult)  continue;
                yield return new PersistentValidationResult(result, null);
            }

            //if (!string.IsNullOrEmpty(scene.Path))
            //{
            //    foreach (var result in ValidateAllAssetsAtPath(scene.Path))
            //    {
            //        yield return result;
            //    }
            //}
        }

        public IEnumerable<PersistentValidationResult> ValidateSceneContent(SceneReference scene)
        {
            if (!scene.IsValid) throw new Exception("Scene not valid: " + scene);
            if (!scene.IsLoaded) throw new Exception("Scene not loaded: " + scene);

#if ODIN_TRIAL
            if (ValidatorTrialUtility.IsReallyExpired)
            {
                yield return PersistentValidationResult.Ignore;
                yield break;
            }
#endif

            if (!scene.TryGetScene(out var unityScene))
                throw new Exception("Scene not loaded");

            bool foundResult1, foundResult2, foundResult3;

            foreach (var root in SceneUtilities.GetSceneRoots(unityScene))
            {
                if (!root) continue;

                foundResult1 = false;
                foreach (var t in IterateHierarchy(root.transform, true))
                {
                    foundResult1 = true;
                    foundResult2 = false;

                    if (!t) continue;

                    var go = t.gameObject;

                    if (go == null)
                        continue;

                    foreach (var result in ValidateObject(go))
                    {
                        foundResult2 = true;
                        yield return result;
                    }

                    if (go == null)
                        continue;

                    foreach (var component in go.GetComponents<Component>())
                    {
                        foundResult3 = false;

                        if (go == null)
                            break;

                        if (component)
                        {
                            foreach (var result in ValidateObject(component, go))
                            {
                                foundResult2 = true;
                                foundResult3 = true;
                                yield return result;
                            }
                        }

                        if (!foundResult3) yield return PersistentValidationResult.Ignore;
                    }

                    if (!foundResult2) yield return PersistentValidationResult.Ignore;
                }

                if (!foundResult1) yield return PersistentValidationResult.Ignore;
            }


        }

        public IEnumerable<PersistentValidationResult> ValidateScene(SceneReference scene)
        {
            if (!scene.IsValid) throw new Exception("Scene not valid: " + scene);
            if (!scene.IsLoaded) throw new Exception("Scene not loaded: " + scene);

            foreach (var result in ValidateSceneValidators(scene))
                yield return result;

            foreach (var result in ValidateSceneContent(scene))
                yield return result;
        }

        private IEnumerable<Transform> IterateHierarchy(Transform transform, bool returnSelf)
        {
            if (returnSelf) yield return transform;

            if (transform)
            {
                for (int i = 0; i < ((transform == null) ? 0 : transform.childCount); i++)
                {
                    if (!transform)
                        break;

                    var child = transform.GetChild(i);

                    if (child)
                    {
                        yield return child;

                        foreach (var result in IterateHierarchy(child, false))
                        {
                            yield return result;
                        }
                    }
                }
            }
        }

        private MiniPool<List<ValidationResult>> validationResultListPool = new MiniPool<List<ValidationResult>>(() => new List<ValidationResult>());
        private Func<Type, bool> customValidationFilter;

        public IEnumerable<PersistentValidationResult> ValidateObject(object value) => ValidateObject(value, null);
        public IEnumerable<PersistentValidationResult> ValidateObject(object value, object parentContext) => ValidateObject(value, parentContext, null);
        public IEnumerable<PersistentValidationResult> ValidateObject(object value, ObjectAddress objectAddress) => ValidateObject(value, null, objectAddress);

        public IEnumerable<PersistentValidationResult> ValidateObject(object value, object parentContext, ObjectAddress objectAddress)
        {
#if ODIN_TRIAL
            if (ValidatorTrialUtility.IsReallyExpired)
            {
                yield return PersistentValidationResult.Ignore;
                yield break;
            }
#endif

            if (object.ReferenceEquals(value, null))
            {
#if SIRENIX_INTERNAL
                if (objectAddress != null)
                {
                    Debug.LogError("This information should be added to the result.");
                }
#endif
                if (parentContext is GameObject)
                {
                    var go = parentContext as GameObject;

                    // TODO: Make dynamic object address for broken component.
                    DynamicObjectAddress.TryGet(go.GetInstanceID(), out var dynAddress);

                    yield return new PersistentValidationResult(
                        null,
                        "Missing Component, the associated script can not be loaded.",
                        null, 0,
                        ValidationResultType.Error, dynAddress);

                }
                else
                {

                    yield return new PersistentValidationResult(
                        null,
                        "Root object to scan is null; this could indicate a corrupted asset or a component/asset with a missing script file",
                        null, 0,
                        ValidationResultType.Error);
                }

                yield break;
            }

            if (!this.Policy.ShouldValidate(this, value))
            {
                yield break;
            }

            bool isUnityObj = value is UnityEngine.Object;
            UnityEngine.Object unityObj = isUnityObj ? value as UnityEngine.Object : null;

            if (isUnityObj)
            {
                if (unityObj == null)
                {
                    // Asset to scan is null; we should check if it has a missing script.
                    MonoScript script = null;
                    string typeOfThing;

                    if (unityObj is MonoBehaviour)
                    {
                        script = MonoScript.FromMonoBehaviour(unityObj as MonoBehaviour);
                        typeOfThing = "MonoBehaviour";
                    }
                    else if (unityObj is ScriptableObject)
                    {
                        script = MonoScript.FromScriptableObject(unityObj as ScriptableObject);
                        typeOfThing = "ScriptableObject";
                    }
                    else if (unityObj is Component)
                    {
                        // It's a component but not a MonoBehaviour; MonoScript apparently doesn't handle that, so, uh...
                        //  this is just a general error case, I suppose?
                        typeOfThing = "Component";
                        script = null;
                    }
                    else
                    {
                        typeOfThing = "UnityEngine.Object";
                        script = null;
                    }

                    if (script == null)
                    {
                        yield return new PersistentValidationResult(null, typeOfThing + " of type '" + unityObj.GetType() + "' appears to have a missing script", null, 0, ValidationResultType.Error);
                    }
                    else
                    {
                        yield return new PersistentValidationResult(null, typeOfThing + " of type '" + unityObj.GetType() + "' was in a destroyed state while being scanned", null, 0, ValidationResultType.Error);
                    }

                    yield break;
                }
            }

            PropertyTree tree;

            if (this.cachedPropertyTrees == null)
            {
                this.cachedPropertyTrees = new Dictionary<Type, PropertyTree>(FastTypeComparer.Instance);
            }

            if (!this.cachedPropertyTrees.TryGetValue(value.GetType(), out tree))
            {
                PersistentValidationResult exceptionResult = null;

                try
                {
                    tree = PropertyTree.Create(value).SetUpForValidation();
                }
                catch (Exception ex)
                {
                    if (tree != null)
                    {
                        tree.Dispose();
                    }

                    if (isUnityObj)
                    {
                        DynamicObjectAddress dynObjectAddress;

                        if (objectAddress == null || unityObj == null)
                            dynObjectAddress = DynamicObjectAddress.Unknown;
                        else
                            dynObjectAddress = DynamicObjectAddress.GetOrCreate(unityObj, objectAddress);

                        exceptionResult = new PersistentValidationResult(
                            null,
                            //$"Exception was thrown during validation of Unity object '{objStr}': {ex}",
                            ex.UnwrapException().ToString(),
                            null, 0,
                            ValidationResultType.Error, dynObjectAddress);
                    }
                    else
                    {
                        DynamicObjectAddress dynObjectAddress;

                        if (objectAddress == null || unityObj == null)
                            dynObjectAddress = DynamicObjectAddress.Unknown;
                        else
                            dynObjectAddress = DynamicObjectAddress.GetOrCreate(unityObj, objectAddress);

                        Exception _tmp = ex;

                        ex.GetBaseException();

                        exceptionResult = new PersistentValidationResult(
                            null,
                            //$"Exception was thrown during validation of value of type '{value.GetType().GetNiceName()}': {ex}",
                            ex.UnwrapException().ToString(),
                            null, 0,
                            ValidationResultType.Error, dynObjectAddress);
                    }
                }

                if (exceptionResult != null)
                {
                    yield return exceptionResult;
                    yield break;
                }
            }
            else
            {
                this.cachedPropertyTrees.Remove(value.GetType());
                tree.SetTargets(value);
                tree.SetUpForValidation();
            }

            ValidationComponentProvider validationComponentProvider = null;

            foreach (var item in tree.ComponentProviders)
            {
                if (item is ValidationComponentProvider provider)
                {
                    validationComponentProvider = provider;
                    break;
                }
            }

            if (validationComponentProvider == null)
            {
                throw new Exception("Property had no ValidationComponentProvider");
            }

            this.customValidationFilter = this.customValidationFilter ?? ((type) =>
            {
                return this.Policy.CustomValidatorFilter(this, type);
            });

            validationComponentProvider.ValidatorLocator.CustomValidatorFilter = this.customValidationFilter;

            var resultBuffer = validationResultListPool.Get();
            resultBuffer.Clear();

            try
            {
                try
                {
                    DynamicObjectAddress dynamicObjectAddress = null;

                    if (isUnityObj)
                    {
                        if (objectAddress == null)
                        {
                            string errorMessage;
                            ObjectAddress.TryCreateObjectAddress(unityObj, out objectAddress, out errorMessage);
                        }

                        if (objectAddress != null)
                        {
                            dynamicObjectAddress = DynamicObjectAddress.GetOrCreate(unityObj, objectAddress);
                        }
                    }

                    if (dynamicObjectAddress == null)
                    {
                        dynamicObjectAddress = DynamicObjectAddress.Unknown;
                    }

                    {
                        var root = tree.RootProperty;
                        var validationComponent = root.GetComponent<ValidationComponent>();

                        if (validationComponent != null && root.GetAttribute<DontValidateAttribute>() == null && validationComponent.ValidatorLocator.PotentiallyHasValidatorsFor(root))
                        {
                            var from = resultBuffer.Count;

                            validationComponent.ValidateProperty(ref resultBuffer);

                            if (from == resultBuffer.Count)
                            {
                                yield return PersistentValidationResult.Ignore;
                                if (isUnityObj && unityObj == null) yield break;
                            }
                            else
                            {
                                for (int i = from; i < resultBuffer.Count; i++)
                                {
                                    yield return new PersistentValidationResult(resultBuffer[i], dynamicObjectAddress);
                                    if (isUnityObj && unityObj == null) yield break;
                                }
                            }

                        }
                    }

                    var shouldValidate = this.Policy.ShouldDeeplyValidate(this, value);

                    if (shouldValidate)
                    {
                        //foreach (var property in tree.EnumerateTree(true, true))

                        var current = tree.RootProperty;

                        while (true)
                        {
                            tree.UpdateTree();

                            while (current != null && !current.IsReachableFromRoot())
                            {
                                current = current.Parent;
                            }

                            if (current == null) break;
                            current = current.NextProperty(true, true);
                            if (current == null) break;

                            var validationComponent = current.GetComponent<ValidationComponent>();

                            if (validationComponent == null) continue;
                            if (current.GetAttribute<DontValidateAttribute>() != null) continue;
                            if (!validationComponent.ValidatorLocator.PotentiallyHasValidatorsFor(current)) continue;

                            var from = resultBuffer.Count;

                            validationComponent.ValidateProperty(ref resultBuffer);

                            if (from == resultBuffer.Count)
                            {
                                yield return PersistentValidationResult.Ignore;
                                if (isUnityObj && unityObj == null) yield break;
                            }
                            else
                            {
                                for (int i = from; i < resultBuffer.Count; i++)
                                {
                                    yield return new PersistentValidationResult(resultBuffer[i], dynamicObjectAddress);
                                    if (isUnityObj && unityObj == null) yield break;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    if (this.cachedPropertyTrees.ContainsKey(value.GetType()))
                    {
                        tree.Dispose();
                    }
                    else
                    {
                        tree.CleanForCachedReuse();
                        this.cachedPropertyTrees.Add(value.GetType(), tree);
                    }
                }
            }
            finally
            {
                resultBuffer.Clear();
                validationResultListPool.Return(resultBuffer);
            }
        }

#if SIRENIX_INTERNAL
        [Obsolete("Use ValidateObjectRecursively instead", true)]
#else
        [Obsolete("Use ValidateObjectRecursively instead", false)]
#endif
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public IEnumerable<PersistentValidationResult> ValidateUnityObjectRecursively(UnityEngine.Object value)
        {
            return this.ValidateObject(value);
        }

        private struct LoadedAssetInfo
        {
            public enum AssetType
            {
                BrokenAsset,
                Normal,
                BrokenComponent,
            }

            public AssetType Type;
            public UnityEngine.Object Asset;
            public GameObject OwningGO;
            public Component BrokenComponent;
            public int ComponentIndex;
            public string AssetPath;
            public ObjectAddress Address;
            public bool IsValid;
            public bool IsMainAsset;
            public int SubAssetIndex;

            public LoadedAssetInfo(AssetType type, UnityEngine.Object asset, string assetPath, ObjectAddress address, bool isMainAsset, int subAssetIndex)
            {
                this.Type = type;
                this.Asset = asset;
                this.OwningGO = null;
                this.BrokenComponent = null;
                this.ComponentIndex = -1;
                this.AssetPath = assetPath;
                this.Address = address;
                this.IsValid = true;
                this.IsMainAsset = isMainAsset;
                this.SubAssetIndex = subAssetIndex;
            }

            public LoadedAssetInfo(GameObject owningGo, Component brokenComponent, int componentIndex, string assetPath, ObjectAddress data)
            {
                this.Type = AssetType.BrokenComponent;
                this.Asset = null;
                this.OwningGO = owningGo;
                this.BrokenComponent = brokenComponent;
                this.ComponentIndex = componentIndex;
                this.AssetPath = assetPath;
                this.Address = data;
                this.IsValid = true;
                this.IsMainAsset = false;
                this.SubAssetIndex = 0;
            }
        }
    }

    internal class MiniPool<T>
    {
        private object LOCK = new object();
        private Func<T> createNew;

        private readonly Queue<T> pool = new Queue<T>();

        public MiniPool(Func<T> createNew)
        {
            this.createNew = createNew;
        }

        public void Return(T item)
        {
            lock (LOCK)
            {
                pool.Enqueue(item);
            }
        }

        public T Get()
        {
            lock (LOCK)
            {
                if (this.pool.Count > 0)
                {
                    return this.pool.Dequeue();
                }

                return this.createNew();
            }
        }
    }
}



//internal class DebugLogHandler : ILogHandler
//{
//    public List<LogMessage> Messages = new List<LogMessage>();

//    public void LogException(Exception exception, UnityEngine.Object context)
//    {
//        this.Messages.Add(new LogMessage()
//        {
//            Context = context,
//            Message = exception.ToString(),
//            LogType = LogType.Exception,
//        });
//    }

//    public void LogFormat(LogType logType, UnityEngine.Object context, string format, params object[] args)
//    {
//        if (logType == LogType.Assert || logType == LogType.Log)
//        {
//            logType = LogType.Warning;
//        }

//        //if (logType == LogType.Warning || logType == LogType.Error)
//        {
//            this.Messages.Add(new LogMessage()
//            {
//                Context = context,
//                Message = string.Format(format, args),
//                LogType = logType,
//            });
//        }
//    }

//    public struct LogMessage
//    {
//        public LogType LogType;
//        public string Message;
//        public UnityEngine.Object Context;
//    }
//}


//private void BeginCaptureLogEvents()
//{
//    this.prevHandler = Debug.unityLogger.logHandler;
//    Debug.unityLogger.logHandler = this.logHandler;
//}

//private void EndCaptureLogEvents()
//{
//    this.logHandler.Messages.Clear();
//    Debug.unityLogger.logHandler = this.prevHandler;
//    this.prevHandler = null;
//}

//internal IEnumerable<PersistentValidationResult> ConsumeCapturedLogEvents(string path, ObjectAddress fallbackObjAddress)
//{
//    DynamicObjectAddress fallbackDynamicObject = null;

//    if (this.logHandler.Messages.Count > 0)
//    {
//        foreach (var msg in this.logHandler.Messages)
//        {
//            DynamicObjectAddress objectAddress = null;

//            if (msg.Context != null)
//            {
//                if (ObjectAddress.TryCreateObjectAddress(msg.Context, out var address, out var error))
//                {
//                    if (address.IsBroken)
//                    {
//                        objectAddress = DynamicObjectAddress.CreateBroken(address);
//                    }
//                    else
//                    {
//                        objectAddress = DynamicObjectAddress.GetOrCreate(msg.Context, address);
//                    }
//                }
//            }
//            else
//            {
//                if (fallbackDynamicObject == null)
//                {
//                    if (fallbackObjAddress == null)
//                    {
//                        var asset = AssetDatabase.LoadMainAssetAtPath(path);
//                        ObjectAddress.TryCreateObjectAddress(asset, out fallbackObjAddress, out var error);
//                    }
//                    if (fallbackObjAddress != null)
//                    {
//                        if (fallbackObjAddress.IsBroken)
//                        {
//                            fallbackDynamicObject = DynamicObjectAddress.CreateBroken(fallbackObjAddress);
//                        }
//                        else
//                        {
//                            fallbackDynamicObject = DynamicObjectAddress.GetOrCreate(fallbackObjAddress);
//                        }
//                    }
//                }

//                objectAddress = fallbackDynamicObject;
//            }

//            yield return new PersistentValidationResult(
//                "Debug.Log" + msg.LogType,
//                msg.Message,
//                typeof(DebugLogHandler), 0,
//                msg.LogType == LogType.Warning ? ValidationResultType.Warning : ValidationResultType.Error,
//                objectAddress);
//        }

//        this.logHandler.Messages.Clear();
//    }
//}
#endif