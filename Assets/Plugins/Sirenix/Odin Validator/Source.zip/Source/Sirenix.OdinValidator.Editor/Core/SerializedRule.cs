//-----------------------------------------------------------------------
// <copyright file="SerializedRule.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinValidator.Editor
{
    using Sirenix.OdinInspector.Editor.Internal;
    using Sirenix.OdinInspector.Editor.Validation;
    using Sirenix.Serialization;
    using Sirenix.Serialization.Utilities;
    using Sirenix.Utilities;
    using System;
    using System.Linq;
    using System.Text;
    using UnityEngine;

    [Serializable]
    public class SerializedRule
    {
        public bool Enabled;
        public bool EnabledOverridden;

        [SerializeField] private string Type;
        [SerializeField] private string Override;

        [NonSerialized] public Type ValidatorType;
        [NonSerialized] public Validator DataOverride;
        [NonSerialized] public RegisterValidationRuleAttribute Attr;

        private SerializedRule()
        {

        }

        public SerializedRule(Type validatorType, RegisterValidationRuleAttribute attr)
        {
            this.ValidatorType = validatorType;
            this.Attr = attr;
        }

        private Type isConfigurableRuleType;
        private bool? isConfigurable;
        public bool IsConfigurable
        {
            get
            {
                var updateIsConfigurable = !isConfigurable.HasValue || this.isConfigurableRuleType != this.ValidatorType;

                if (updateIsConfigurable)
                {
                    this.isConfigurableRuleType = this.ValidatorType;

                    if (this.ValidatorType == null)
                    {
                        this.isConfigurable = false;
                    }
                    else
                    {
                        this.isConfigurable = this.ValidatorType
                            .GetFields(Flags.InstanceAnyVisibility)
                            .Any(x => SerializationPolicies.Strict.ShouldSerializeMember(x));
                    }
                }

                return this.isConfigurable.Value;
            }
        }

        public void Save()
        {
            if (this.ValidatorType == null)
            {
                this.Type = "";
            }
            else
            {
                this.Type = TwoWaySerializationBinder.Default.BindToName(this.ValidatorType);
            }

            if (this.DataOverride == null)
            {
                this.Override = "";
            }
            else
            {
                using (var ctx = Cache<SerializationContext>.Claim())
                {
                    ctx.Value.StringReferenceResolver = EditorOnlyObjectAddressExternalReferenceResolver.Instance;
                    var bytes = SerializationUtility.SerializeValue(this.DataOverride, DataFormat.JSON, ctx);
                    this.Override = Encoding.UTF8.GetString(bytes);
                    //Debug.Log("Serialized rule: " + this.Override);
                }
            }
        }

        public void Load()
        {
            if (string.IsNullOrWhiteSpace(this.Type))
            {
                this.ValidatorType = null;
            }
            else
            {
                this.ValidatorType = TwoWaySerializationBinder.Default.BindToType(this.Type);
            }

            if (string.IsNullOrWhiteSpace(this.Override))
            {
                this.DataOverride = null;
            }
            else
            {
                using (var ctx = Cache<DeserializationContext>.Claim())
                {
                    ctx.Value.StringReferenceResolver = EditorOnlyObjectAddressExternalReferenceResolver.Instance;
                    var bytes = Encoding.UTF8.GetBytes(this.Override);
                    this.DataOverride = Serialization.SerializationUtility.DeserializeValue<Validator>(bytes, DataFormat.JSON, ctx);
                }
            }
        }

        public SerializedRule CreateCopy()
        {
            this.Save();
            var copy = FastDeepCopier.DeepCopy(this); //(SerializedRule)Serialization.SerializationUtility.CreateCopy(this);
            copy.Load();
            return copy;
        }
    }
}
#endif